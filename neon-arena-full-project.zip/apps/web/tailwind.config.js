/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        obsidian: {
          950: '#07080c',
          900: '#0a0b10',
          800: '#12141e',
          700: '#181b2a',
          600: '#23273c'
        },
        neon: {
          cyan: '#00f0ff',
          violet: '#9d4edd',
          magenta: '#f43f5e',
          blue: '#3b82f6',
          gold: '#fbbf24',
          emerald: '#10b981'
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Orbitron', 'Rajdhani', 'sans-serif']
      },
      boxShadow: {
        'neon-cyan': '0 0 15px rgba(0, 240, 255, 0.45)',
        'neon-violet': '0 0 15px rgba(157, 78, 221, 0.45)',
        'neon-magenta': '0 0 15px rgba(244, 63, 94, 0.45)',
        'neon-gold': '0 0 15px rgba(251, 191, 36, 0.45)',
        'glass': '0 8px 32px 0 rgba(0, 0, 0, 0.37)'
      },
      animation: {
        'pulse-glow': 'pulseGlow 2.5s infinite ease-in-out',
        'float': 'float 4s ease-in-out infinite'
      },
      keyframes: {
        pulseGlow: {
          '0%, 100%': { opacity: '0.4' },
          '50%': { opacity: '0.9' }
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-6px)' }
        }
      }
    }
  },
  plugins: []
};
