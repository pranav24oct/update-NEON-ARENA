import { describe, it, expect, beforeEach } from 'vitest';
import { GAMES_CATALOGUE, AVATAR_PRESETS } from '@neon-arena/config';
import {
  calculateLevelFromXp,
  getXpRequiredForLevel,
  getTierFromRating,
  calculateEloChange,
  CompetitiveTier,
  GameSlug
} from '@neon-arena/shared';
import { soundManager } from '../lib/audio';
import { useAuthStore } from '../stores/authStore';

// Simple polyfill / mock for localStorage in Node test environment
const mockStorage: Record<string, string> = {};
const localStorageMock = {
  getItem: (key: string) => mockStorage[key] || null,
  setItem: (key: string, value: string) => {
    mockStorage[key] = value.toString();
  },
  removeItem: (key: string) => {
    delete mockStorage[key];
  },
  clear: () => {
    for (const key of Object.keys(mockStorage)) {
      delete mockStorage[key];
    }
  }
};
Object.defineProperty(globalThis, 'localStorage', {
  value: localStorageMock,
  writable: true
});

describe('Frontend Catalog & Config Suite', () => {
  it('should include all 6 games in GAMES_CATALOGUE with required metadata', () => {
    expect(GAMES_CATALOGUE.length).toBe(6);
    const expectedSlugs = Object.values(GameSlug);
    for (const slug of expectedSlugs) {
      const game = GAMES_CATALOGUE.find((g) => g.slug === slug);
      expect(game).toBeDefined();
      expect(game?.title).toBeTruthy();
      expect(game?.genre).toBeTruthy();
      expect(game?.instructions).toBeDefined();
      expect(game?.controls).toBeDefined();
      expect(Array.isArray(game?.controls)).toBe(true);
    }
  });

  it('should provide default avatar options', () => {
    expect(AVATAR_PRESETS.length).toBeGreaterThanOrEqual(6);
    for (const avatarUrl of AVATAR_PRESETS) {
      expect(avatarUrl).toContain('https://');
    }
  });
});

describe('SoundManager Audio State Suite', () => {
  beforeEach(() => {
    localStorageMock.clear();
  });

  it('should toggle mute state and persist in localStorage', () => {
    soundManager.setMuted(false);
    expect(soundManager.isMuted()).toBe(false);

    const toggled = soundManager.toggleMute();
    expect(toggled).toBe(true);
    expect(soundManager.isMuted()).toBe(true);
    expect(localStorageMock.getItem('neon_audio_muted')).toBe('true');

    soundManager.toggleMute();
    expect(soundManager.isMuted()).toBe(false);
    expect(localStorageMock.getItem('neon_audio_muted')).toBe('false');
  });

  it('should safely execute sound triggers without throwing in headless environment', () => {
    expect(() => {
      soundManager.playClick();
      soundManager.playMove();
      soundManager.playScore();
      soundManager.playSlice();
      soundManager.playFlap();
      soundManager.playVictory();
      soundManager.playGameOver();
    }).not.toThrow();
  });
});

describe('Zustand Auth Store Suite', () => {
  beforeEach(() => {
    useAuthStore.setState({
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false,
      error: null
    });
  });

  it('should set user and update authentication status', () => {
    const mockUser = {
      id: 'usr_test_1',
      username: 'neon_rider',
      email: 'rider@neon.io',
      role: 'PLAYER' as const,
      statistics: {
        totalXp: 1500,
        level: 4,
        totalGamesPlayed: 10,
        totalWins: 7,
        totalLosses: 3,
        currentStreak: 2,
        bestStreak: 4,
        multiplayerWins: 5
      }
    };

    useAuthStore.getState().setUser(mockUser);
    const state = useAuthStore.getState();
    expect(state.user).toEqual(mockUser);
    expect(state.isAuthenticated).toBe(true);
  });

  it('should update user stats when XP is awarded', () => {
    const mockUser = {
      id: 'usr_test_2',
      username: 'cyber_phoenix',
      email: 'phoenix@neon.io',
      role: 'PLAYER' as const,
      statistics: {
        totalXp: 100,
        level: 1,
        totalGamesPlayed: 1,
        totalWins: 1,
        totalLosses: 0,
        currentStreak: 1,
        bestStreak: 1,
        multiplayerWins: 0
      }
    };

    useAuthStore.getState().setUser(mockUser);
    useAuthStore.getState().updateUserStats(150, 250, 2);

    const updated = useAuthStore.getState().user;
    expect(updated?.statistics?.totalXp).toBe(250);
    expect(updated?.statistics?.level).toBe(2);
  });
});

describe('Progression & Shared Logic Consistency', () => {
  it('should compute matching level tiers and Elo thresholds', () => {
    const lvl1 = calculateLevelFromXp(0);
    expect(lvl1.level).toBe(1);

    const lvl2 = calculateLevelFromXp(100);
    expect(lvl2.level).toBe(2);

    expect(getXpRequiredForLevel(1)).toBe(100);

    expect(getTierFromRating(1000)).toBe(CompetitiveTier.BRONZE);
    expect(getTierFromRating(1250)).toBe(CompetitiveTier.SILVER);
    expect(getTierFromRating(1450)).toBe(CompetitiveTier.GOLD);
    expect(getTierFromRating(1650)).toBe(CompetitiveTier.PLATINUM);
    expect(getTierFromRating(1850)).toBe(CompetitiveTier.DIAMOND);
    expect(getTierFromRating(2050)).toBe(CompetitiveTier.MASTER);
    expect(getTierFromRating(2350)).toBe(CompetitiveTier.CHAMPION);

    const eloWin = calculateEloChange(1200, 1200, 1);
    expect(eloWin.change).toBeGreaterThan(0);
    expect(eloWin.newRating).toBe(1200 + eloWin.change);
  });
});
