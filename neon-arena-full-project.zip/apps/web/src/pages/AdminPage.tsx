import React, { useState, useEffect } from 'react';
import {
  Shield,
  Users,
  Trophy,
  Activity,
  AlertTriangle,
  History,
  CheckCircle2,
  Ban,
  UserCheck,
  Plus
} from 'lucide-react';
import { api } from '../lib/api.js';
import { useAuthStore } from '../stores/authStore.js';
import { NeonButton } from '../components/ui/NeonButton.js';
import { Badge } from '../components/ui/Badge.js';
import { Modal } from '../components/ui/Modal.js';

export const AdminPage: React.FC = () => {
  const { user } = useAuthStore();
  const [overview, setOverview] = useState<any | null>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [reports, setReports] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'USERS' | 'REPORTS' | 'TOURNAMENTS'>('OVERVIEW');
  const [loading, setLoading] = useState(true);

  // Tournament Create Modal
  const [createTourneyOpen, setCreateTourneyOpen] = useState(false);
  const [tourneyTitle, setTourneyTitle] = useState('');
  const [tourneyDesc, setTourneyDesc] = useState('');
  const [tourneyGame, setTourneyGame] = useState('tic-tac-toe');
  const [tourneyMax, setTourneyMax] = useState(8);
  const [tourneyXp, setTourneyXp] = useState(2500);

  const loadAdminData = () => {
    Promise.all([
      api.admin.getOverview(),
      api.admin.getUsers(1, 20),
      api.admin.getReports()
    ])
      .then(([ovRes, usRes, repRes]) => {
        setOverview(ovRes);
        setUsers(usRes.users || []);
        setReports(repRes.reports || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Failed to load admin data:', err);
        setLoading(false);
      });
  };

  useEffect(() => {
    loadAdminData();
  }, []);

  const handleUpdateRole = async (userId: string, currentRole: string) => {
    const newRole = currentRole === 'ADMIN' ? 'PLAYER' : 'ADMIN';
    if (!confirm(`Change role of user to ${newRole}?`)) return;

    try {
      await api.admin.updateRole(userId, newRole);
      loadAdminData();
    } catch (err: any) {
      alert(err.message || 'Failed to update role');
    }
  };

  const handleBanToggle = async (userId: string, isBanned: boolean) => {
    if (isBanned) {
      if (!confirm('Unban this user?')) return;
      try {
        await api.admin.unbanUser(userId);
        loadAdminData();
      } catch (err: any) {
        alert(err.message || 'Failed to unban');
      }
    } else {
      const reason = prompt('Enter ban reason:') || 'Terms of service violation';
      try {
        await api.admin.banUser({ userId, reason, durationDays: 30 });
        loadAdminData();
      } catch (err: any) {
        alert(err.message || 'Failed to ban');
      }
    }
  };

  const handleResolveReport = async (reportId: string, action: 'ACTIONED' | 'DISMISSED') => {
    try {
      await api.admin.resolveReport(reportId, action);
      loadAdminData();
    } catch (err: any) {
      alert(err.message || 'Failed to resolve report');
    }
  };

  const handleCreateTournament = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const startDate = new Date(Date.now() + 86400000 * 2).toISOString();
      const registrationDeadline = new Date(Date.now() + 86400000).toISOString();

      await api.admin.createTournament({
        title: tourneyTitle,
        description: tourneyDesc,
        gameSlug: tourneyGame,
        maxParticipants: tourneyMax,
        startDate,
        registrationDeadline,
        xpReward: tourneyXp
      });

      alert('Tournament initialized successfully!');
      setCreateTourneyOpen(false);
      setTourneyTitle('');
      setTourneyDesc('');
    } catch (err: any) {
      alert(err.message || 'Failed to create tournament');
    }
  };

  if (user?.role !== 'ADMIN') {
    return (
      <div className="text-center py-20 space-y-3">
        <Shield className="w-12 h-12 text-rose-500 mx-auto" />
        <h2 className="text-2xl font-bold text-white">Access Forbidden</h2>
        <p className="text-xs text-slate-400">Only authorized administrators may access this console.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-black font-display text-white flex items-center gap-2.5">
            <Shield className="w-8 h-8 text-neon-magenta" />
            ADMINISTRATOR CONSOLE
          </h1>
          <p className="text-sm text-slate-400">
            Platform governance, player moderation, tournament generation, and system health oversight.
          </p>
        </div>

        <NeonButton variant="magenta" size="sm" onClick={() => setCreateTourneyOpen(true)}>
          <Plus className="w-4 h-4" />
          Create Tournament
        </NeonButton>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 p-1 rounded-xl bg-obsidian-900 border border-white/10 w-fit">
        {(['OVERVIEW', 'USERS', 'REPORTS'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              activeTab === tab
                ? 'bg-neon-magenta text-white shadow-neon-magenta'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* 1. OVERVIEW TAB */}
      {activeTab === 'OVERVIEW' && overview && (
        <div className="space-y-6">
          {/* Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 rounded-2xl glass-panel border border-white/10 space-y-1 text-center">
              <span className="text-[10px] text-slate-400 font-bold uppercase">REGISTERED GLADIATORS</span>
              <p className="text-3xl font-black font-display text-white">{overview.metrics.totalUsers}</p>
            </div>

            <div className="p-4 rounded-2xl glass-panel border border-white/10 space-y-1 text-center">
              <span className="text-[10px] text-slate-400 font-bold uppercase">MATCHES PLAYED</span>
              <p className="text-3xl font-black font-display text-neon-cyan">{overview.metrics.totalMatches}</p>
            </div>

            <div className="p-4 rounded-2xl glass-panel border border-white/10 space-y-1 text-center">
              <span className="text-[10px] text-slate-400 font-bold uppercase">GAME SESSIONS</span>
              <p className="text-3xl font-black font-display text-neon-violet">{overview.metrics.totalGameSessions}</p>
            </div>

            <div className="p-4 rounded-2xl glass-panel border border-white/10 space-y-1 text-center">
              <span className="text-[10px] text-slate-400 font-bold uppercase">PENDING REPORTS</span>
              <p className="text-3xl font-black font-display text-rose-400">{overview.metrics.pendingReportsCount}</p>
            </div>
          </div>

          {/* System Health */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="glass-panel border border-white/10 rounded-2xl p-6 space-y-3">
              <h3 className="text-base font-bold font-display text-white flex items-center gap-2">
                <Activity className="w-5 h-5 text-emerald-400" />
                System Health & Resources
              </h3>
              <div className="space-y-2 text-xs text-slate-300">
                <div className="flex justify-between p-2 rounded bg-obsidian-900">
                  <span className="text-slate-400">Node Runtime:</span>
                  <span className="font-mono text-white">{overview.systemHealth.nodeVersion}</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-obsidian-900">
                  <span className="text-slate-400">Process Uptime:</span>
                  <span className="font-mono text-emerald-400">{overview.systemHealth.uptimeSeconds}s</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-obsidian-900">
                  <span className="text-slate-400">Heap Memory Used:</span>
                  <span className="font-mono text-neon-cyan">{overview.systemHealth.memoryUsageMb.heapUsed} MB</span>
                </div>
                <div className="flex justify-between p-2 rounded bg-obsidian-900">
                  <span className="text-slate-400">Database Engine:</span>
                  <span className="font-mono text-emerald-400 font-bold">Connected (Prisma ORM)</span>
                </div>
              </div>
            </div>

            {/* Audit Logs */}
            <div className="glass-panel border border-white/10 rounded-2xl p-6 space-y-3">
              <h3 className="text-base font-bold font-display text-white flex items-center gap-2">
                <History className="w-5 h-5 text-neon-gold" />
                Recent Audit Trail
              </h3>
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {overview.recentAuditLogs.length === 0 ? (
                  <p className="text-xs text-slate-500 py-4 text-center">No audit records.</p>
                ) : (
                  overview.recentAuditLogs.map((log: any) => (
                    <div key={log.id} className="p-2.5 rounded-xl bg-obsidian-900 text-xs space-y-0.5">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white">{log.action}</span>
                        <span className="text-[10px] text-slate-500">
                          {new Date(log.createdAt).toLocaleTimeString()}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400">By @{log.admin.username}</p>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. USERS TAB */}
      {activeTab === 'USERS' && (
        <div className="glass-panel border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-obsidian-900/90 border-b border-white/10 text-slate-400 font-bold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">User</th>
                  <th className="py-3 px-4">Email</th>
                  <th className="py-3 px-4">Role</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-white/5">
                    <td className="py-3 px-4 font-bold text-white">{u.username}</td>
                    <td className="py-3 px-4 text-slate-400">{u.email}</td>
                    <td className="py-3 px-4">
                      <Badge variant={u.role === 'ADMIN' ? 'magenta' : 'cyan'} size="sm">
                        {u.role}
                      </Badge>
                    </td>
                    <td className="py-3 px-4">
                      {u.isBanned ? (
                        <span className="text-rose-400 font-bold">Banned</span>
                      ) : (
                        <span className="text-emerald-400 font-bold">Active</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right space-x-2">
                      <button
                        onClick={() => handleUpdateRole(u.id, u.role)}
                        className="text-[11px] text-neon-cyan hover:underline font-semibold"
                      >
                        Toggle Role
                      </button>
                      <button
                        onClick={() => handleBanToggle(u.id, u.isBanned)}
                        className={`text-[11px] font-semibold hover:underline ${
                          u.isBanned ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {u.isBanned ? 'Unban' : 'Ban'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. REPORTS TAB */}
      {activeTab === 'REPORTS' && (
        <div className="space-y-3">
          {reports.length === 0 ? (
            <div className="text-center py-16 glass-panel rounded-2xl border border-white/10 text-slate-400 text-xs">
              No pending abuse or moderation reports.
            </div>
          ) : (
            reports.map((rep) => (
              <div
                key={rep.id}
                className="p-5 rounded-2xl glass-panel border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <Badge variant="magenta" size="sm">
                      {rep.status}
                    </Badge>
                    <span className="text-xs text-slate-400">
                      Reported by @{rep.reporter.username} against @{rep.reportedUser.username}
                    </span>
                  </div>
                  <p className="text-sm font-semibold text-white">"{rep.reason}"</p>
                </div>

                <div className="flex items-center gap-2">
                  <NeonButton
                    variant="cyan"
                    size="sm"
                    onClick={() => handleResolveReport(rep.id, 'ACTIONED')}
                  >
                    Resolve & Action
                  </NeonButton>
                  <NeonButton
                    variant="ghost"
                    size="sm"
                    onClick={() => handleResolveReport(rep.id, 'DISMISSED')}
                  >
                    Dismiss
                  </NeonButton>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Create Tournament Modal */}
      <Modal isOpen={createTourneyOpen} onClose={() => setCreateTourneyOpen(false)} title="Create Tournament">
        <form onSubmit={handleCreateTournament} className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">Tournament Title</label>
            <input
              type="text"
              required
              value={tourneyTitle}
              onChange={(e) => setTourneyTitle(e.target.value)}
              placeholder="e.g. Neon Blitz Showdown"
              className="w-full px-3 py-2 bg-obsidian-900 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-neon-magenta"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">Description</label>
            <textarea
              required
              value={tourneyDesc}
              onChange={(e) => setTourneyDesc(e.target.value)}
              rows={3}
              placeholder="Bracket rules and tournament overview..."
              className="w-full p-3 bg-obsidian-900 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-neon-magenta"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Game</label>
              <select
                value={tourneyGame}
                onChange={(e) => setTourneyGame(e.target.value)}
                className="w-full px-3 py-2 bg-obsidian-900 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-neon-magenta"
              >
                <option value="tic-tac-toe">Tic-Tac-Toe Neon</option>
                <option value="snake">Neon Snake</option>
                <option value="cyber-slice">Cyber Slice</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">Bracket Size</label>
              <select
                value={tourneyMax}
                onChange={(e) => setTourneyMax(Number(e.target.value))}
                className="w-full px-3 py-2 bg-obsidian-900 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-neon-magenta"
              >
                <option value={4}>4 Players</option>
                <option value={8}>8 Players</option>
                <option value={16}>16 Players</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3">
            <NeonButton variant="ghost" size="sm" type="button" onClick={() => setCreateTourneyOpen(false)}>
              Cancel
            </NeonButton>
            <NeonButton variant="magenta" size="sm" type="submit">
              Publish Tournament
            </NeonButton>
          </div>
        </form>
      </Modal>
    </div>
  );
};
