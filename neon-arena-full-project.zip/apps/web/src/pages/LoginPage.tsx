import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Zap, Lock, User, AlertCircle } from 'lucide-react';
import { useAuthStore } from '../stores/authStore.js';
import { NeonButton } from '../components/ui/NeonButton.js';

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuthStore();

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      await login(identifier.trim(), password);
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Login failed');
      setLoading(false);
    }
  };

  const handleDemoLogin = async (asAdmin: boolean = false) => {
    setError(null);
    setLoading(true);
    try {
      if (asAdmin) {
        await login('admin', 'Admin2026!');
      } else {
        await login('cyber_ninja', 'NeonArena2026!');
      }
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Demo login failed');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[70vh] flex items-center justify-center p-4">
      <div className="w-full max-w-md glass-panel border border-neon-cyan/40 rounded-3xl p-8 shadow-2xl space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-neon-cyan/20 border border-neon-cyan/50 flex items-center justify-center mx-auto shadow-neon-cyan">
            <Zap className="w-7 h-7 text-neon-cyan" />
          </div>
          <h1 className="text-2xl font-black font-display text-white">GLADIATOR SIGN IN</h1>
          <p className="text-xs text-slate-400">Authenticate to enter the arena and track match records.</p>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center gap-2 text-rose-400 text-xs">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300">Username or Email</label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                required
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="cyber_ninja or ninja@neonarena.com"
                className="w-full pl-10 pr-4 py-2.5 bg-obsidian-900 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-neon-cyan"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300">Password</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-2.5 bg-obsidian-900 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-neon-cyan"
              />
            </div>
          </div>

          <NeonButton variant="cyan" size="lg" type="submit" disabled={loading} className="w-full">
            {loading ? 'Authenticating...' : 'Sign In to Arena'}
          </NeonButton>
        </form>

        {/* Demo Login Quick Buttons */}
        <div className="pt-2 border-t border-white/10 space-y-2">
          <p className="text-[11px] text-slate-400 text-center font-semibold uppercase tracking-wider">
            Quick Demo Accounts
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => handleDemoLogin(false)}
              className="py-2 px-3 rounded-xl bg-obsidian-900 border border-white/10 hover:border-neon-cyan text-xs font-semibold text-neon-cyan transition-colors"
            >
              Player (Ninja)
            </button>
            <button
              onClick={() => handleDemoLogin(true)}
              className="py-2 px-3 rounded-xl bg-obsidian-900 border border-white/10 hover:border-neon-magenta text-xs font-semibold text-neon-magenta transition-colors"
            >
              Admin (Admin)
            </button>
          </div>
        </div>

        <p className="text-center text-xs text-slate-400">
          New to the arena?{' '}
          <Link to="/register" className="text-neon-cyan hover:underline font-bold">
            Create an account
          </Link>
        </p>
      </div>
    </div>
  );
};
