import React, { useState, useEffect } from 'react';
import { Award, Trophy, Swords, Users, Search, Flame } from 'lucide-react';
import { api } from '../lib/api.js';
import { useAuthStore } from '../stores/authStore.js';
import { Badge } from '../components/ui/Badge.js';

export const LeaderboardsPage: React.FC = () => {
  const { user } = useAuthStore();
  const [boardType, setBoardType] = useState<'GLOBAL' | 'COMPETITIVE' | 'GAME' | 'FRIENDS'>('GLOBAL');
  const [gameSlug, setGameSlug] = useState('snake');
  const [entries, setEntries] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  const games = [
    { slug: 'snake', label: 'Neon Snake' },
    { slug: '2048', label: 'Cyber 2048' },
    { slug: 'neon-flap', label: 'Neon Cyber Flap' },
    { slug: 'cyber-slice', label: 'Cyber Slice' },
    { slug: 'orbit-strike', label: 'Orbit Strike' },
    { slug: 'tic-tac-toe', label: 'Tic-Tac-Toe Neon' }
  ];

  const fetchLeaderboard = () => {
    setLoading(true);
    let promise: Promise<any>;

    if (boardType === 'GLOBAL') {
      promise = api.leaderboards.getGlobal();
    } else if (boardType === 'COMPETITIVE') {
      promise = api.leaderboards.getCompetitive();
    } else if (boardType === 'FRIENDS') {
      promise = api.leaderboards.getFriends();
    } else {
      promise = api.leaderboards.getGame(gameSlug);
    }

    promise
      .then((res) => {
        setEntries(res.entries || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Error fetching leaderboard:', err);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchLeaderboard();
  }, [boardType, gameSlug]);

  const filtered = entries.filter((e) =>
    (e.displayName || e.username || '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-3xl font-black font-display text-white flex items-center gap-2.5">
          <Award className="w-8 h-8 text-neon-cyan" />
          ARENA LEADERBOARDS
        </h1>
        <p className="text-sm text-slate-400">
          Global rankings verified by server-authoritative score calculation. Ascend tiers and etch your name into platform history.
        </p>
      </div>

      {/* Tabs & Game Picker */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2 p-1 rounded-xl bg-obsidian-900 border border-white/10 w-fit">
          <button
            onClick={() => setBoardType('GLOBAL')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              boardType === 'GLOBAL'
                ? 'bg-neon-cyan text-obsidian-950 shadow-neon-cyan'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Global XP
          </button>
          <button
            onClick={() => setBoardType('COMPETITIVE')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              boardType === 'COMPETITIVE'
                ? 'bg-neon-violet text-white shadow-neon-violet'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Competitive Elo
          </button>
          <button
            onClick={() => setBoardType('GAME')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              boardType === 'GAME'
                ? 'bg-neon-magenta text-white shadow-neon-magenta'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Arcade Scores
          </button>
          <button
            onClick={() => setBoardType('FRIENDS')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              boardType === 'FRIENDS'
                ? 'bg-neon-gold text-obsidian-950 shadow-neon-gold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Friends
          </button>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search gladiator..."
            className="w-full pl-10 pr-4 py-2 bg-obsidian-900 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-neon-cyan"
          />
        </div>
      </div>

      {/* Game Selector Sub-bar when Arcade Scores selected */}
      {boardType === 'GAME' && (
        <div className="flex flex-wrap items-center gap-2 pt-1">
          {games.map((g) => (
            <button
              key={g.slug}
              onClick={() => setGameSlug(g.slug)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                gameSlug === g.slug
                  ? 'bg-neon-magenta/20 border-neon-magenta text-neon-magenta shadow-neon-magenta'
                  : 'bg-obsidian-900 border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              {g.label}
            </button>
          ))}
        </div>
      )}

      {/* Table Container */}
      <div className="glass-panel border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-obsidian-900/90 border-b border-white/10 text-slate-400 font-bold uppercase tracking-wider">
              <tr>
                <th className="py-3.5 px-4 w-16">Rank</th>
                <th className="py-3.5 px-4">Gladiator</th>
                {boardType === 'COMPETITIVE' ? (
                  <>
                    <th className="py-3.5 px-4">Rating</th>
                    <th className="py-3.5 px-4">Division Tier</th>
                    <th className="py-3.5 px-4 text-right">Duels</th>
                  </>
                ) : boardType === 'GAME' ? (
                  <>
                    <th className="py-3.5 px-4">High Score</th>
                    <th className="py-3.5 px-4 text-right">Achieved Date</th>
                  </>
                ) : (
                  <>
                    <th className="py-3.5 px-4">Level</th>
                    <th className="py-3.5 px-4">Total XP</th>
                    <th className="py-3.5 px-4 text-right">Victories</th>
                  </>
                )}
              </tr>
            </thead>

            <tbody className="divide-y divide-white/5">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-slate-500 font-medium">
                    No leaderboard records found.
                  </td>
                </tr>
              ) : (
                filtered.map((entry, idx) => {
                  const isCurrent = user && (entry.userId === user.id || entry.username === user.username);
                  return (
                    <tr
                      key={entry.userId || idx}
                      className={`transition-colors ${
                        isCurrent
                          ? 'bg-neon-cyan/10 border-l-2 border-neon-cyan'
                          : 'hover:bg-white/5'
                      }`}
                    >
                      <td className="py-3.5 px-4">
                        <span
                          className={`font-display font-black text-sm ${
                            entry.rank === 1
                              ? 'text-neon-gold'
                              : entry.rank === 2
                              ? 'text-slate-200'
                              : entry.rank === 3
                              ? 'text-amber-600'
                              : 'text-slate-500'
                          }`}
                        >
                          #{entry.rank}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={
                              entry.avatar ||
                              'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80'
                            }
                            alt={entry.username}
                            className="w-8 h-8 rounded-full object-cover border border-white/10"
                          />
                          <div>
                            <span className="font-bold text-white block">
                              {entry.displayName || entry.username}
                              {isCurrent && (
                                <span className="ml-2 text-[10px] text-neon-cyan font-semibold">
                                  (YOU)
                                </span>
                              )}
                            </span>
                            <span className="text-[11px] text-slate-500">
                              @{entry.username}
                            </span>
                          </div>
                        </div>
                      </td>

                      {boardType === 'COMPETITIVE' ? (
                        <>
                          <td className="py-3.5 px-4 font-mono font-bold text-neon-violet">
                            {entry.rating} Elo
                          </td>
                          <td className="py-3.5 px-4">
                            <span
                              className="px-2.5 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider"
                              style={{ color: entry.tierColor, backgroundColor: `${entry.tierColor}20` }}
                            >
                              {entry.tierLabel || entry.tier}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-right text-slate-300 font-semibold">
                            {entry.matchesCount}
                          </td>
                        </>
                      ) : boardType === 'GAME' ? (
                        <>
                          <td className="py-3.5 px-4 font-display font-black text-neon-cyan text-sm">
                            {entry.score}
                          </td>
                          <td className="py-3.5 px-4 text-right text-slate-400 text-[11px]">
                            {new Date(entry.achievedAt).toLocaleDateString()}
                          </td>
                        </>
                      ) : (
                        <>
                          <td className="py-3.5 px-4">
                            <Badge variant="cyan" size="sm">
                              LVL {entry.level || 1}
                            </Badge>
                          </td>
                          <td className="py-3.5 px-4 font-display font-black text-neon-cyan text-sm">
                            {entry.totalXp} XP
                          </td>
                          <td className="py-3.5 px-4 text-right text-slate-300 font-semibold">
                            {entry.wins || 0} Wins
                          </td>
                        </>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
