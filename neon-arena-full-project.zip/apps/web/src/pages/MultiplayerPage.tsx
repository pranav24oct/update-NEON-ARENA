import React, { useState } from 'react';
import { Swords, Users, Key, Play, Shield, RefreshCw } from 'lucide-react';
import { useAuthStore } from '../stores/authStore.js';
import { TicTacToeGame } from '../features/games/components/TicTacToeGame.js';
import { NeonButton } from '../components/ui/NeonButton.js';
import { Badge } from '../components/ui/Badge.js';
import { getTierFromRating, COMPETITIVE_TIERS } from '@neon-arena/shared';

export const MultiplayerPage: React.FC = () => {
  const { user, isAuthenticated } = useAuthStore();
  const [customRoomCode, setCustomRoomCode] = useState('');
  const [createdRoomCode, setCreatedRoomCode] = useState<string | null>(null);

  const rating = 1200;
  const tierEnum = getTierFromRating(rating);
  const tierInfo = COMPETITIVE_TIERS[tierEnum];

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-black font-display text-white flex items-center gap-2.5">
            <Swords className="w-8 h-8 text-neon-violet" />
            MULTIPLAYER ARENA
          </h1>
          <p className="text-sm text-slate-400">
            Real-time server-authoritative duels. Synchronized moves, disconnect grace periods, and Elo rankings.
          </p>
        </div>

        {/* Player Tier Badge */}
        {isAuthenticated && (
          <div className="flex items-center gap-3 p-3 rounded-2xl glass-panel border border-neon-violet/30">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center font-black font-display text-base"
              style={{ backgroundColor: tierInfo.badgeBg, color: tierInfo.color }}
            >
              {tierInfo.label[0]}
            </div>
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase block">COMPETITIVE RANK</span>
              <span className="text-sm font-bold font-display" style={{ color: tierInfo.color }}>
                {tierInfo.label} &bull; {rating} Elo
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Main Duel Interface */}
      <div className="glass-panel border border-neon-violet/30 rounded-3xl p-6 sm:p-8 flex flex-col items-center">
        <TicTacToeGame />
      </div>

      {/* Custom Room Controls & Features */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Create / Join Private Room */}
        <div className="glass-panel border border-white/10 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-bold font-display text-white flex items-center gap-2">
            <Key className="w-5 h-5 text-neon-cyan" />
            Private Room Code
          </h3>
          <p className="text-xs text-slate-400">
            Host a private duel against a friend or join using a 6-character room code.
          </p>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={customRoomCode}
              onChange={(e) => setCustomRoomCode(e.target.value.toUpperCase())}
              placeholder="ENTER ROOM CODE (e.g. CYBER1)"
              maxLength={6}
              className="flex-1 px-4 py-2.5 bg-obsidian-900 border border-white/10 rounded-xl text-sm font-mono tracking-widest text-white uppercase focus:outline-none focus:border-neon-cyan"
            />
            <NeonButton variant="cyan" size="md" onClick={() => alert(`Connecting to room ${customRoomCode}...`)}>
              Join Room
            </NeonButton>
          </div>
        </div>

        {/* Integrity & Rules */}
        <div className="glass-panel border border-white/10 rounded-2xl p-6 space-y-3">
          <h3 className="text-base font-bold font-display text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-neon-gold" />
            Competitive Fair Play
          </h3>
          <ul className="space-y-1.5 text-xs text-slate-300">
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-neon-cyan" />
              Server validates legal moves and turn sequences.
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-neon-cyan" />
              Disconnect grace period allows quick reconnection.
            </li>
            <li className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-neon-cyan" />
              Elo rating changes are saved directly to database history.
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
