import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Zap, Lock, User, Mail, AlertCircle } from 'lucide-react';
import { useAuthStore } from '../stores/authStore.js';
import { NeonButton } from '../components/ui/NeonButton.js';
import { AVATAR_PRESETS } from '@neon-arena/config';

export const RegisterPage: React.FC = () => {
  const navigate = useNavigate();
  const { register } = useAuthStore();

  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [avatar, setAvatar] = useState(AVATAR_PRESETS[0]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password.length < 8) {
      setError('Password must be at least 8 characters with a capital letter and number.');
      return;
    }

    setLoading(true);

    try {
      await register(username.trim(), email.trim(), password, avatar);
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Registration failed');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[70vh] flex items-center justify-center p-4">
      <div className="w-full max-w-md glass-panel border border-neon-cyan/40 rounded-3xl p-8 shadow-2xl space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-neon-cyan/20 border border-neon-cyan/50 flex items-center justify-center mx-auto shadow-neon-cyan">
            <Zap className="w-7 h-7 text-neon-cyan" />
          </div>
          <h1 className="text-2xl font-black font-display text-white">BECOME A GLADIATOR</h1>
          <p className="text-xs text-slate-400">Join Neon Arena. Complete quests, duel players, and climb the tiers.</p>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center gap-2 text-rose-400 text-xs">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300">Username</label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Unique gladiator handle"
                className="w-full pl-10 pr-4 py-2.5 bg-obsidian-900 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-neon-cyan"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your.email@arena.gg"
                className="w-full pl-10 pr-4 py-2.5 bg-obsidian-900 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-neon-cyan"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300">Password</label>
            <div className="relative">
              <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="At least 8 chars (1 uppercase, 1 number)"
                className="w-full pl-10 pr-4 py-2.5 bg-obsidian-900 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-neon-cyan"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-2">Select Avatar</label>
            <div className="flex justify-between gap-1.5">
              {AVATAR_PRESETS.map((av, idx) => (
                <img
                  key={idx}
                  src={av}
                  alt={`Avatar ${idx}`}
                  onClick={() => setAvatar(av)}
                  className={`w-11 h-11 rounded-xl object-cover cursor-pointer border-2 transition-all ${
                    avatar === av
                      ? 'border-neon-cyan scale-110 shadow-neon-cyan'
                      : 'border-white/10 opacity-70 hover:opacity-100'
                  }`}
                />
              ))}
            </div>
          </div>

          <NeonButton variant="cyan" size="lg" type="submit" disabled={loading} className="w-full">
            {loading ? 'Creating Account...' : 'Register Account'}
          </NeonButton>
        </form>

        <p className="text-center text-xs text-slate-400">
          Already have an arena account?{' '}
          <Link to="/login" className="text-neon-cyan hover:underline font-bold">
            Sign In
          </Link>
        </p>
      </div>
    </div>
  );
};
