import React, { useState, useEffect } from 'react';
import { Scroll, Gift, CheckCircle2, Trophy, Sparkles } from 'lucide-react';
import { api } from '../lib/api.js';
import { useAuthStore } from '../stores/authStore.js';
import { NeonButton } from '../components/ui/NeonButton.js';
import { Badge } from '../components/ui/Badge.js';
import { ProgressBar } from '../components/ui/ProgressBar.js';
import confetti from 'canvas-confetti';

export const QuestsPage: React.FC = () => {
  const { user, isAuthenticated, updateUserStats } = useAuthStore();
  const [quests, setQuests] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'ALL' | 'DAILY' | 'WEEKLY' | 'MILESTONE'>('ALL');
  const [loading, setLoading] = useState(true);

  const loadQuests = () => {
    if (isAuthenticated) {
      api.quests
        .getMy()
        .then((res) => {
          setQuests(res.quests || []);
          setLoading(false);
        })
        .catch(() => setLoading(false));
    } else {
      api.quests
        .getAll()
        .then((res) => {
          setQuests(
            res.quests.map((q) => ({
              id: q.id,
              title: q.title,
              description: q.description,
              type: q.type,
              difficulty: q.difficulty,
              targetCount: q.targetCount,
              progress: 0,
              progressPercent: 0,
              xpReward: q.xpReward,
              completed: false,
              claimed: false
            }))
          );
          setLoading(false);
        })
        .catch(() => setLoading(false));
    }
  };

  useEffect(() => {
    loadQuests();
  }, [isAuthenticated]);

  const handleClaim = async (questId: string) => {
    try {
      const resp = await api.quests.claim(questId);
      confetti({ particleCount: 70, spread: 60 });
      updateUserStats(resp.xpAwarded, resp.newTotalXp, resp.level);
      loadQuests();
    } catch (err: any) {
      alert(err.message || 'Failed to claim reward');
    }
  };

  const filtered = quests.filter(
    (q) => activeTab === 'ALL' || q.type === activeTab
  );

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-3xl font-black font-display text-white flex items-center gap-2.5">
          <Scroll className="w-8 h-8 text-neon-cyan" />
          ARENA QUEST ENGINE
        </h1>
        <p className="text-sm text-slate-400">
          Complete daily duels, weekly endurance goals, and milestone achievements to unlock high-tier cosmetic ranks.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 p-1 rounded-xl bg-obsidian-900 border border-white/10 w-fit">
        {(['ALL', 'DAILY', 'WEEKLY', 'MILESTONE'] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              activeTab === tab
                ? 'bg-neon-cyan text-obsidian-950 shadow-neon-cyan'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Quest Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filtered.map((q) => (
          <div
            key={q.id}
            className={`p-5 rounded-2xl glass-panel border transition-all flex flex-col justify-between space-y-4 ${
              q.claimed
                ? 'border-white/5 opacity-60'
                : q.completed
                ? 'border-neon-cyan/50 bg-neon-cyan/5 shadow-[0_0_15px_rgba(0,240,255,0.1)]'
                : 'border-white/10 hover:border-white/20'
            }`}
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Badge variant={q.type === 'DAILY' ? 'cyan' : q.type === 'WEEKLY' ? 'violet' : 'gold'} size="sm">
                    {q.type}
                  </Badge>
                  <span className="text-[11px] font-semibold text-slate-400 uppercase">
                    {q.difficulty}
                  </span>
                </div>

                <span className="text-xs font-bold font-display text-neon-gold flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />+{q.xpReward} XP
                </span>
              </div>

              <h3 className="font-bold text-base text-white">{q.title}</h3>
              <p className="text-xs text-slate-400 leading-relaxed">{q.description}</p>
            </div>

            <div className="space-y-2 pt-2">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span className="text-slate-400">
                  {q.progress} / {q.targetCount}
                </span>
                <span className={q.completed ? 'text-neon-cyan' : 'text-slate-300'}>
                  {q.progressPercent || 0}%
                </span>
              </div>

              <ProgressBar
                value={q.progressPercent || 0}
                color={q.completed ? 'cyan' : 'violet'}
                height="h-2"
              />

              <div className="pt-2 flex items-center justify-end">
                {q.claimed ? (
                  <span className="text-xs text-slate-500 font-semibold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                    Claimed
                  </span>
                ) : q.completed ? (
                  <NeonButton variant="cyan" size="sm" onClick={() => handleClaim(q.id)}>
                    <Gift className="w-4 h-4" />
                    Claim {q.xpReward} XP
                  </NeonButton>
                ) : (
                  <span className="text-xs text-slate-500">In Progress</span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
