import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../lib/api.js';
import { useGameStore } from '../stores/gameStore.js';
import { useAuthStore } from '../stores/authStore.js';
import { TicTacToeGame } from '../features/games/components/TicTacToeGame.js';
import { SnakeGame } from '../features/games/components/SnakeGame.js';
import { Game2048 } from '../features/games/components/Game2048.js';
import { NeonFlapGame } from '../features/games/components/NeonFlapGame.js';
import { CyberSliceGame } from '../features/games/components/CyberSliceGame.js';
import { OrbitStrikeGame } from '../features/games/components/OrbitStrikeGame.js';
import { Badge } from '../components/ui/Badge.js';
import { Heart, Trophy, Keyboard, Info, Award, ArrowLeft, Users } from 'lucide-react';

export const GameDetailPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [game, setGame] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  const { isFavorite, toggleFavorite, recordPlayed } = useGameStore();
  const { user } = useAuthStore();

  const fetchGameDetails = () => {
    if (!slug) return;
    api.games
      .getBySlug(slug)
      .then((res) => {
        setGame(res.game);
        recordPlayed(slug);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Failed to load game:', err);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchGameDetails();
  }, [slug]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20 text-slate-400">
        Loading game arena...
      </div>
    );
  }

  if (!game) {
    return (
      <div className="text-center py-20 space-y-4">
        <h2 className="text-2xl font-bold text-white">Game Not Found</h2>
        <Link to="/games" className="text-neon-cyan hover:underline text-sm font-semibold">
          Return to Game Library
        </Link>
      </div>
    );
  }

  const renderGameComponent = () => {
    switch (game.slug) {
      case 'tic-tac-toe':
        return <TicTacToeGame onScoreSaved={fetchGameDetails} />;
      case 'snake':
        return <SnakeGame onScoreSaved={fetchGameDetails} />;
      case '2048':
        return <Game2048 onScoreSaved={fetchGameDetails} />;
      case 'neon-flap':
        return <NeonFlapGame onScoreSaved={fetchGameDetails} />;
      case 'cyber-slice':
        return <CyberSliceGame onScoreSaved={fetchGameDetails} />;
      case 'orbit-strike':
        return <OrbitStrikeGame onScoreSaved={fetchGameDetails} />;
      default:
        return <div className="text-center text-slate-400 py-12">Coming Soon</div>;
    }
  };

  const isFav = isFavorite(game.slug);

  return (
    <div className="space-y-8 max-w-6xl mx-auto">
      {/* Back button & Header Info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Link
            to="/games"
            className="p-2 rounded-xl glass-panel border border-white/10 text-slate-400 hover:text-white hover:border-neon-cyan transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl sm:text-3xl font-black font-display text-white">
                {game.title}
              </h1>
              <Badge variant="cyan" size="sm">
                {game.genre}
              </Badge>
              {game.isMultiplayer && (
                <Badge variant="violet" size="sm">
                  Multiplayer
                </Badge>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-0.5">{game.shortDescription}</p>
          </div>
        </div>

        {/* Favorite & Personal Best */}
        <div className="flex items-center gap-3">
          <div className="p-2 px-3 rounded-xl bg-obsidian-900 border border-white/10 flex items-center gap-2">
            <Trophy className="w-4 h-4 text-neon-gold" />
            <div className="text-left leading-none">
              <span className="text-[10px] text-slate-400 block font-semibold">YOUR BEST</span>
              <span className="text-sm font-bold text-neon-gold font-display">
                {game.personalBest || 0}
              </span>
            </div>
          </div>

          <button
            onClick={() => toggleFavorite(game.slug)}
            className={`p-2.5 rounded-xl glass-panel border transition-colors ${
              isFav
                ? 'border-neon-magenta text-neon-magenta fill-neon-magenta'
                : 'border-white/10 text-slate-400 hover:text-white hover:border-white/20'
            }`}
            title={isFav ? 'Remove from favorites' : 'Add to favorites'}
          >
            <Heart className={`w-5 h-5 ${isFav ? 'fill-current' : ''}`} />
          </button>
        </div>
      </div>

      {/* Main Playable Game Arena */}
      <div className="glass-panel border border-neon-cyan/20 rounded-3xl p-4 sm:p-8 flex flex-col items-center justify-center relative shadow-2xl">
        {renderGameComponent()}
      </div>

      {/* Instructions, Controls, and High Scores */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Instructions & Overview */}
        <div className="glass-panel border border-white/10 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-bold font-display text-white flex items-center gap-2">
            <Info className="w-5 h-5 text-neon-cyan" />
            How To Play
          </h3>
          <ul className="space-y-2 text-xs text-slate-300 leading-relaxed">
            {game.instructions?.map((inst: string, idx: number) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-neon-cyan mt-1.5 flex-shrink-0" />
                <span>{inst}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Controls */}
        <div className="glass-panel border border-white/10 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-bold font-display text-white flex items-center gap-2">
            <Keyboard className="w-5 h-5 text-neon-violet" />
            Game Controls
          </h3>
          <div className="space-y-2.5">
            {game.controls?.map((ctrl: any, idx: number) => (
              <div
                key={idx}
                className="flex items-center justify-between p-2.5 rounded-xl bg-obsidian-900/60 border border-white/5 text-xs"
              >
                <span className="text-slate-300">{ctrl.action}</span>
                <kbd className="px-2 py-1 rounded bg-obsidian-950 border border-white/20 font-mono text-[11px] text-neon-cyan font-bold">
                  {ctrl.key}
                </kbd>
              </div>
            ))}
          </div>
        </div>

        {/* High Scores Leaderboard */}
        <div className="glass-panel border border-white/10 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-bold font-display text-white flex items-center gap-2">
            <Award className="w-5 h-5 text-neon-gold" />
            Top Scores
          </h3>
          <div className="space-y-2">
            {game.topScores?.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">No scores recorded yet. Be first!</p>
            ) : (
              game.topScores?.map((scoreEntry: any) => (
                <div
                  key={scoreEntry.rank}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-obsidian-900/60 border border-white/5 text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-5 font-bold font-display text-neon-gold">
                      #{scoreEntry.rank}
                    </span>
                    <img
                      src={
                        scoreEntry.avatar ||
                        'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80'
                      }
                      alt={scoreEntry.username}
                      className="w-6 h-6 rounded-full object-cover border border-white/10"
                    />
                    <span className="font-semibold text-white truncate max-w-[100px]">
                      {scoreEntry.displayName}
                    </span>
                  </div>
                  <span className="font-bold text-neon-cyan font-display">
                    {scoreEntry.score}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
