import React, { useState, useEffect } from 'react';
import { Trophy, Calendar, Users, Sparkles, Shield, ArrowRight, CheckCircle2 } from 'lucide-react';
import { api } from '../lib/api.js';
import { useAuthStore } from '../stores/authStore.js';
import { NeonButton } from '../components/ui/NeonButton.js';
import { Badge } from '../components/ui/Badge.js';
import { Modal } from '../components/ui/Modal.js';
import confetti from 'canvas-confetti';

export const TournamentsPage: React.FC = () => {
  const { user, isAuthenticated } = useAuthStore();
  const [tournaments, setTournaments] = useState<any[]>([]);
  const [selectedTournament, setSelectedTournament] = useState<any | null>(null);
  const [bracketData, setBracketData] = useState<any | null>(null);
  const [isBracketOpen, setIsBracketOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const loadTournaments = () => {
    api.tournaments
      .getAll()
      .then((res) => {
        setTournaments(res.tournaments || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };

  useEffect(() => {
    loadTournaments();
  }, []);

  const handleRegister = async (tournamentId: string) => {
    if (!isAuthenticated) {
      alert('Please log in to register for tournaments.');
      return;
    }

    try {
      await api.tournaments.register(tournamentId);
      confetti({ particleCount: 75, spread: 60 });
      alert('Successfully registered for tournament!');
      loadTournaments();
    } catch (err: any) {
      alert(err.message || 'Registration failed');
    }
  };

  const openBracket = async (t: any) => {
    setSelectedTournament(t);
    try {
      const data = await api.tournaments.getBracket(t.id);
      setBracketData(data);
      setIsBracketOpen(true);
    } catch (err) {
      console.error('Failed to load bracket:', err);
    }
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-3xl font-black font-display text-white flex items-center gap-2.5">
          <Trophy className="w-8 h-8 text-neon-gold" />
          SEASONAL TOURNAMENTS
        </h1>
        <p className="text-sm text-slate-400">
          Enter single-elimination brackets. Free registration, verified brackets, and exclusive champion trophies.
        </p>
      </div>

      {/* Tournaments Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {tournaments.map((t) => (
          <div
            key={t.id}
            className="p-6 rounded-2xl glass-panel border border-neon-violet/30 hover:border-neon-violet/60 transition-all flex flex-col justify-between space-y-5"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Badge variant={t.status === 'REGISTRATION' ? 'cyan' : 'gold'} size="sm">
                  {t.status}
                </Badge>
                <span className="text-xs text-neon-gold font-display font-bold flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  {t.xpReward} XP Prize
                </span>
              </div>

              <div>
                <h3 className="text-xl font-bold font-display text-white">{t.title}</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">{t.description}</p>
              </div>

              <div className="pt-2 flex items-center gap-4 text-xs text-slate-300 font-semibold">
                <div className="flex items-center gap-1.5">
                  <Users className="w-4 h-4 text-neon-cyan" />
                  <span>
                    {t.registeredCount} / {t.maxParticipants} Registered
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-neon-violet" />
                  <span>Starts {new Date(t.startDate).toLocaleDateString()}</span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-white/10 flex items-center justify-between">
              <button
                onClick={() => openBracket(t)}
                className="text-xs text-neon-cyan hover:underline font-semibold flex items-center gap-1"
              >
                Inspect Bracket Tree
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              {t.isRegistered ? (
                <span className="text-xs text-emerald-400 font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  Registered
                </span>
              ) : (
                <NeonButton
                  variant="violet"
                  size="sm"
                  onClick={() => handleRegister(t.id)}
                  disabled={t.isFull || t.status !== 'REGISTRATION'}
                >
                  {t.isFull ? 'Tournament Full' : 'Register Free'}
                </NeonButton>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Bracket Tree Modal */}
      <Modal
        isOpen={isBracketOpen}
        onClose={() => setIsBracketOpen(false)}
        title={selectedTournament?.title || 'Tournament Bracket'}
        maxWidth="max-w-4xl"
      >
        <div className="space-y-6 py-2">
          <p className="text-xs text-slate-400">
            Single-elimination bracket progression automatically calculated by server match results.
          </p>

          {bracketData && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 overflow-x-auto pb-4">
              {bracketData.rounds?.map((round: any) => (
                <div key={round.roundNumber} className="space-y-4">
                  <div className="text-center font-display font-bold text-xs text-neon-cyan uppercase tracking-wider py-1.5 px-3 bg-obsidian-900 border border-white/10 rounded-lg">
                    {round.roundName}
                  </div>

                  <div className="space-y-3">
                    {round.matches.map((m: any) => (
                      <div
                        key={m.id}
                        className="p-3 rounded-xl bg-obsidian-900/90 border border-white/10 space-y-2 text-xs"
                      >
                        <div
                          className={`flex items-center justify-between p-1.5 rounded-lg ${
                            m.winnerId && m.winnerId === m.player1?.id
                              ? 'bg-emerald-950/40 text-emerald-300 font-bold'
                              : 'text-slate-300'
                          }`}
                        >
                          <span>{m.player1?.username || 'TBD'}</span>
                          {m.winnerId === m.player1?.id && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          )}
                        </div>

                        <div className="w-full h-px bg-white/5" />

                        <div
                          className={`flex items-center justify-between p-1.5 rounded-lg ${
                            m.winnerId && m.winnerId === m.player2?.id
                              ? 'bg-emerald-950/40 text-emerald-300 font-bold'
                              : 'text-slate-300'
                          }`}
                        >
                          <span>{m.player2?.username || 'TBD'}</span>
                          {m.winnerId === m.player2?.id && (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
};
