import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Play, Gamepad2 } from 'lucide-react';
import { api } from '../lib/api.js';
import { useGameStore } from '../stores/gameStore.js';
import { NeonButton } from '../components/ui/NeonButton.js';
import { Badge } from '../components/ui/Badge.js';

export const FavoritesPage: React.FC = () => {
  const { favorites, toggleFavorite } = useGameStore();
  const [games, setGames] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.games
      .getAll()
      .then((res) => {
        setGames(res.games || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const favGames = games.filter((g) => favorites.includes(g.slug));

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-black font-display text-white flex items-center gap-2.5">
          <Heart className="w-8 h-8 text-neon-magenta fill-neon-magenta/20" />
          FAVORITE GAMES
        </h1>
        <p className="text-sm text-slate-400">
          Your bookmarked arena games for quick access and instant competition.
        </p>
      </div>

      {favGames.length === 0 ? (
        <div className="text-center py-16 glass-panel rounded-2xl border border-white/10 space-y-4">
          <Heart className="w-12 h-12 text-slate-600 mx-auto" />
          <p className="text-base font-bold text-white">No favorites bookmarked yet</p>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Click the heart icon on any game card to add it to your personal favorites.
          </p>
          <Link to="/games">
            <NeonButton variant="cyan" size="md">
              Browse Library
            </NeonButton>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {favGames.map((g) => (
            <div
              key={g.slug}
              className="group relative rounded-2xl overflow-hidden glass-panel-interactive border border-white/10 hover:border-neon-magenta/50 flex flex-col justify-between"
            >
              <div className="relative h-44 overflow-hidden">
                <img
                  src={g.thumbnail}
                  alt={g.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-obsidian-950 via-obsidian-950/40 to-transparent" />
                <div className="absolute top-3 left-3">
                  <Badge variant="magenta" size="sm">
                    {g.genre}
                  </Badge>
                </div>

                <button
                  onClick={() => toggleFavorite(g.slug)}
                  className="absolute top-3 right-3 p-2 rounded-full glass-panel text-neon-magenta fill-neon-magenta hover:scale-110 transition-transform"
                >
                  <Heart className="w-4 h-4 fill-current" />
                </button>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <h3 className="text-lg font-bold font-display text-white">{g.title}</h3>
                  <p className="text-xs text-slate-400 line-clamp-2 mt-1">{g.description}</p>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-white/10">
                  <span className="text-[11px] text-slate-400">{g.isMultiplayer ? 'Multiplayer' : 'Solo'}</span>
                  <Link to={`/games/${g.slug}`}>
                    <NeonButton variant="magenta" size="sm">
                      <Play className="w-4 h-4 fill-current" />
                      Play Now
                    </NeonButton>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
