import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Zap,
  Play,
  Gamepad2,
  Swords,
  Trophy,
  Award,
  ChevronRight,
  Sparkles,
  Flame,
  Star,
  Users,
  Shield,
  Clock,
  ArrowRight
} from 'lucide-react';
import { useAuthStore } from '../stores/authStore.js';
import { useGameStore } from '../stores/gameStore.js';
import { api } from '../lib/api.js';
import { NeonHeroCanvas } from '../components/3d/NeonHeroCanvas.js';
import { NeonButton } from '../components/ui/NeonButton.js';
import { Badge } from '../components/ui/Badge.js';
import { ProgressBar } from '../components/ui/ProgressBar.js';
import { calculateLevelFromXp, COMPETITIVE_TIERS, getTierFromRating } from '@neon-arena/shared';

export const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuthStore();
  const { recentlyPlayed } = useGameStore();

  const [games, setGames] = useState<any[]>([]);
  const [topPlayers, setTopPlayers] = useState<any[]>([]);
  const [tournaments, setTournaments] = useState<any[]>([]);
  const [dailyQuests, setDailyQuests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.games.getAll(),
      api.leaderboards.getGlobal(1, 5),
      api.tournaments.getAll(),
      api.challenges.getDaily()
    ])
      .then(([gamesRes, lbRes, tourneyRes, challengeRes]) => {
        setGames(gamesRes.games || []);
        setTopPlayers(lbRes.entries || []);
        setTournaments(tourneyRes.tournaments || []);
        setDailyQuests(challengeRes.challenges || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Error fetching homepage data:', err);
        setLoading(false);
      });
  }, []);

  const totalXp = user?.statistics?.totalXp || 0;
  const { level, currentLevelXp, nextLevelXp, progressPercent } = calculateLevelFromXp(totalXp);
  const userRating = user ? 1200 : 0;
  const tierEnum = getTierFromRating(userRating);
  const tierInfo = COMPETITIVE_TIERS[tierEnum];

  const featuredGame = games.find((g) => g.slug === 'tic-tac-toe') || games[0];
  const multiplayerGames = games.filter((g) => g.isMultiplayer);
  const categories = ['Arcade', 'Puzzle', 'Action', 'Strategy', 'Physics'];

  return (
    <div className="space-y-12">
      {/* 1. HERO SECTION WITH 3D INTERACTIVE CANVAS */}
      <section className="relative min-h-[460px] md:min-h-[520px] rounded-3xl overflow-hidden glass-panel border border-neon-cyan/30 flex items-center p-6 md:p-12 shadow-2xl">
        <NeonHeroCanvas />

        <div className="relative z-10 max-w-2xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neon-cyan/10 border border-neon-cyan/30 text-neon-cyan text-xs font-bold tracking-wide">
            <span className="w-2 h-2 rounded-full bg-neon-cyan animate-ping" />
            SEASON 1: CYBER GENESIS LIVE
          </div>

          <div className="space-y-2">
            <h1 className="text-4xl sm:text-6xl font-black font-display tracking-tight text-white leading-none">
              ENTER THE <span className="text-neon-cyan text-glow-cyan">ARENA.</span>
            </h1>
            <p className="text-slate-300 text-sm sm:text-lg font-medium leading-relaxed">
              Play verified arcade classics. Level up your player rank. Challenge rivals in real-time competitive duels and seasonal tournaments.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <Link to="/games/tic-tac-toe">
              <NeonButton variant="cyan" size="lg">
                <Play className="w-5 h-5 fill-current" />
                Play Ranked Match
              </NeonButton>
            </Link>

            <Link to="/games">
              <NeonButton variant="outline" size="lg">
                <Gamepad2 className="w-5 h-5" />
                Explore Games
              </NeonButton>
            </Link>
          </div>

          {/* Quick Metrics Ticker */}
          <div className="pt-4 flex items-center gap-6 border-t border-white/10 text-xs text-slate-300 font-semibold">
            <div>
              <span className="text-neon-cyan font-bold font-display text-base block">6/6</span>
              <span>Playable Games</span>
            </div>
            <div className="w-px h-8 bg-white/10" />
            <div>
              <span className="text-neon-violet font-bold font-display text-base block">100%</span>
              <span>Server Authoritative</span>
            </div>
            <div className="w-px h-8 bg-white/10" />
            <div>
              <span className="text-neon-gold font-bold font-display text-base block">Elo</span>
              <span>Competitive System</span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. AUTHENTICATED PLAYER DASHBOARD PREVIEW */}
      {isAuthenticated && user && (
        <section className="glass-panel border border-neon-violet/30 rounded-2xl p-6 relative overflow-hidden">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <img
                src={
                  user.profile?.avatar ||
                  'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80'
                }
                alt={user.username}
                className="w-16 h-16 rounded-2xl object-cover border-2 border-neon-cyan shadow-neon-cyan"
              />
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-bold font-display text-white">
                    {user.profile?.displayName || user.username}
                  </h2>
                  <Badge variant="cyan" size="sm">
                    LVL {level}
                  </Badge>
                  <span
                    className="text-xs px-2 py-0.5 rounded font-bold uppercase tracking-wider"
                    style={{ backgroundColor: tierInfo.badgeBg, color: tierInfo.color }}
                  >
                    {tierInfo.label}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  {user.profile?.selectedTitle || 'Arena Gladiator'} &bull; Joined Arena
                </p>
              </div>
            </div>

            {/* XP Bar */}
            <div className="w-full lg:max-w-md space-y-1.5">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span className="text-slate-300">Level Progression</span>
                <span className="text-neon-cyan">
                  {currentLevelXp} / {nextLevelXp} XP ({progressPercent}%)
                </span>
              </div>
              <ProgressBar value={progressPercent} color="cyan" height="h-2.5" />
            </div>

            {/* Quick Action */}
            <Link to="/profile">
              <NeonButton variant="outline" size="sm">
                View Full Profile
                <ChevronRight className="w-4 h-4" />
              </NeonButton>
            </Link>
          </div>
        </section>
      )}

      {/* 3. RECENTLY PLAYED / CONTINUE PLAYING */}
      {recentlyPlayed.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold font-display text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-neon-cyan" />
              Continue Playing
            </h2>
            <Link to="/recently-played" className="text-xs text-neon-cyan hover:underline flex items-center gap-1 font-semibold">
              View All ({recentlyPlayed.length})
              <ChevronRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
            {recentlyPlayed.slice(0, 6).map((item) => {
              const game = games.find((g) => g.slug === item.slug);
              if (!game) return null;
              return (
                <Link
                  key={game.slug}
                  to={`/games/${game.slug}`}
                  className="group relative rounded-xl overflow-hidden glass-panel-interactive border border-white/10 hover:border-neon-cyan/50 p-2 text-center"
                >
                  <img
                    src={game.thumbnail}
                    alt={game.title}
                    className="w-full h-24 object-cover rounded-lg mb-2 group-hover:scale-105 transition-transform"
                  />
                  <p className="text-xs font-bold text-white truncate">{game.title}</p>
                  <p className="text-[10px] text-neon-cyan font-semibold">{game.genre}</p>
                </Link>
              );
            })}
          </div>
        </section>
      )}

      {/* 4. FEATURED ARCADE GAMES (POKI & BGAMES INSPIRATION) */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-black font-display text-white flex items-center gap-2">
              <Flame className="w-6 h-6 text-neon-magenta animate-pulse" />
              Featured Games
            </h2>
            <p className="text-xs text-slate-400">Handcrafted, verified responsive web arcade games</p>
          </div>

          <Link to="/games" className="text-xs text-neon-cyan hover:underline flex items-center gap-1 font-semibold">
            Explore All Games
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {games.slice(0, 6).map((g) => (
            <div
              key={g.slug}
              className="group relative rounded-2xl overflow-hidden glass-panel-interactive border border-white/10 hover:border-neon-cyan/50 flex flex-col justify-between"
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={g.thumbnail}
                  alt={g.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-obsidian-950 via-obsidian-950/40 to-transparent" />

                <div className="absolute top-3 left-3 flex gap-1.5">
                  <Badge variant="cyan" size="sm">
                    {g.genre}
                  </Badge>
                  {g.isMultiplayer && (
                    <Badge variant="violet" size="sm">
                      Multiplayer
                    </Badge>
                  )}
                </div>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="text-lg font-bold font-display text-white group-hover:text-neon-cyan transition-colors">
                    {g.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {g.description}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-white/10">
                  <span className="text-[11px] text-slate-400">
                    {g.isMultiplayer ? '1 - 2 Players' : 'Single Player'}
                  </span>
                  <Link to={`/games/${g.slug}`}>
                    <NeonButton variant="cyan" size="sm">
                      <Play className="w-4 h-4 fill-current" />
                      Play Now
                    </NeonButton>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. COMPETITIVE & TOURNAMENTS SECTION */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Tournaments Spotlight */}
        <div className="lg:col-span-2 glass-panel border border-neon-violet/30 rounded-2xl p-6 space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold font-display text-white flex items-center gap-2">
              <Trophy className="w-5 h-5 text-neon-gold" />
              Upcoming Tournaments
            </h3>
            <Link to="/tournaments" className="text-xs text-neon-violet hover:underline font-semibold">
              View All Tournaments
            </Link>
          </div>

          {tournaments.length === 0 ? (
            <p className="text-xs text-slate-400 py-6 text-center">No active tournaments right now.</p>
          ) : (
            <div className="space-y-3">
              {tournaments.slice(0, 2).map((t) => (
                <div
                  key={t.id}
                  className="p-4 rounded-xl bg-obsidian-900/80 border border-white/10 hover:border-neon-violet/40 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-white text-sm">{t.title}</h4>
                      <Badge variant="gold" size="sm">
                        {t.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-slate-400">{t.gameTitle} &bull; Max {t.maxParticipants} Duelists</p>
                    <p className="text-[11px] text-neon-gold font-semibold flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5" />
                      Prize Pool: {t.xpReward} XP & Gold Trophy
                    </p>
                  </div>

                  <Link to={`/tournaments`}>
                    <NeonButton variant="violet" size="sm">
                      View Bracket
                    </NeonButton>
                  </Link>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Global Leaderboard Preview */}
        <div className="glass-panel border border-neon-cyan/30 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold font-display text-white flex items-center gap-2">
              <Award className="w-5 h-5 text-neon-cyan" />
              Top Gladiators
            </h3>
            <Link to="/leaderboards" className="text-xs text-neon-cyan hover:underline font-semibold">
              Rankings
            </Link>
          </div>

          <div className="space-y-2.5">
            {topPlayers.slice(0, 5).map((player, idx) => (
              <div
                key={player.userId}
                className="flex items-center justify-between p-2.5 rounded-xl bg-obsidian-900/60 border border-white/5"
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`w-6 text-center font-display font-black text-xs ${
                      idx === 0
                        ? 'text-neon-gold'
                        : idx === 1
                        ? 'text-slate-300'
                        : idx === 2
                        ? 'text-amber-600'
                        : 'text-slate-500'
                    }`}
                  >
                    #{idx + 1}
                  </span>
                  <img
                    src={player.avatar || 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80'}
                    alt={player.username}
                    className="w-7 h-7 rounded-full object-cover border border-white/10"
                  />
                  <div>
                    <span className="text-xs font-bold text-white block">{player.displayName}</span>
                    <span className="text-[10px] text-slate-400">LVL {player.level}</span>
                  </div>
                </div>

                <span className="text-xs font-bold text-neon-cyan font-display">
                  {player.totalXp} XP
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. DAILY CHALLENGES PREVIEW */}
      <section className="glass-panel border border-white/10 rounded-2xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold font-display text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-neon-gold" />
              Daily Challenges
            </h2>
            <p className="text-xs text-slate-400">Complete daily objectives to claim massive XP boosts</p>
          </div>
          <Link to="/challenges">
            <NeonButton variant="outline" size="sm">
              All Challenges
            </NeonButton>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {dailyQuests.slice(0, 3).map((q) => (
            <div key={q.id} className="p-4 rounded-xl bg-obsidian-900/80 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">{q.title}</span>
                <Badge variant="cyan" size="sm">
                  +{q.xpReward} XP
                </Badge>
              </div>
              <p className="text-xs text-slate-400">{q.description}</p>
              <ProgressBar value={q.progressPercent || 0} color="gold" height="h-2" showLabel />
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
