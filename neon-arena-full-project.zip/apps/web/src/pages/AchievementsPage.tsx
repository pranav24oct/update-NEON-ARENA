import React, { useState, useEffect } from 'react';
import { Trophy, Award, Lock, Sparkles, CheckCircle2 } from 'lucide-react';
import { api } from '../lib/api.js';
import { useAuthStore } from '../stores/authStore.js';
import { Badge } from '../components/ui/Badge.js';

export const AchievementsPage: React.FC = () => {
  const { isAuthenticated } = useAuthStore();
  const [achievements, setAchievements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.challenges
      .getAchievements()
      .then((res) => {
        setAchievements(res.achievements || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [isAuthenticated]);

  const unlockedCount = achievements.filter((a) => a.isUnlocked).length;

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-black font-display text-white flex items-center gap-2.5">
            <Trophy className="w-8 h-8 text-neon-gold" />
            TROPHY CABINET
          </h1>
          <p className="text-sm text-slate-400">
            Showcase your platform milestones. Each unlock grants permanent achievement XP and profile flair.
          </p>
        </div>

        {/* Total Unlocked Stats */}
        <div className="p-3 px-5 rounded-2xl glass-panel border border-neon-gold/40 flex items-center gap-3">
          <Award className="w-6 h-6 text-neon-gold" />
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase block">UNLOCKED</span>
            <span className="text-lg font-bold font-display text-white">
              {unlockedCount} / {achievements.length} Trophies
            </span>
          </div>
        </div>
      </div>

      {/* Trophy Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {achievements.map((ach) => {
          const rarityVariant =
            ach.rarity === 'LEGENDARY'
              ? 'gold'
              : ach.rarity === 'EPIC'
              ? 'violet'
              : ach.rarity === 'RARE'
              ? 'cyan'
              : 'gray';

          return (
            <div
              key={ach.id}
              className={`p-6 rounded-2xl glass-panel border transition-all flex flex-col justify-between space-y-4 ${
                ach.isUnlocked
                  ? 'border-neon-gold/50 bg-neon-gold/5 shadow-[0_0_15px_rgba(251,191,36,0.12)]'
                  : 'border-white/10 opacity-70'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Badge variant={rarityVariant} size="sm">
                    {ach.rarity}
                  </Badge>
                  <span className="text-xs font-bold font-display text-neon-gold flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5" />+{ach.xpReward} XP
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center border ${
                      ach.isUnlocked
                        ? 'bg-neon-gold/20 border-neon-gold text-neon-gold shadow-[0_0_10px_rgba(251,191,36,0.5)]'
                        : 'bg-obsidian-900 border-white/10 text-slate-600'
                    }`}
                  >
                    {ach.isUnlocked ? (
                      <Trophy className="w-6 h-6" />
                    ) : (
                      <Lock className="w-6 h-6" />
                    )}
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-white">{ach.name}</h3>
                    <span className="text-[11px] text-slate-400">
                      Requirement: {ach.threshold} {ach.conditionType.toLowerCase().replace('_', ' ')}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">{ach.description}</p>
              </div>

              <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs">
                {ach.isUnlocked ? (
                  <span className="text-emerald-400 font-semibold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    Unlocked {new Date(ach.unlockedAt).toLocaleDateString()}
                  </span>
                ) : (
                  <span className="text-slate-500 font-medium">Locked</span>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
