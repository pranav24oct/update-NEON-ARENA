import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Clock, Play, Gamepad2 } from 'lucide-react';
import { api } from '../lib/api.js';
import { useGameStore } from '../stores/gameStore.js';
import { NeonButton } from '../components/ui/NeonButton.js';
import { Badge } from '../components/ui/Badge.js';

export const RecentlyPlayedPage: React.FC = () => {
  const { recentlyPlayed } = useGameStore();
  const [games, setGames] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.games
      .getAll()
      .then((res) => {
        setGames(res.games || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const recentGames = recentlyPlayed
    .map((item) => {
      const g = games.find((game) => game.slug === item.slug);
      return g ? { ...g, playedAt: item.playedAt } : null;
    })
    .filter(Boolean);

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-black font-display text-white flex items-center gap-2.5">
          <Clock className="w-8 h-8 text-neon-cyan" />
          RECENTLY PLAYED
        </h1>
        <p className="text-sm text-slate-400">
          Jump right back into the arena. Resume matches and beat your personal records.
        </p>
      </div>

      {recentGames.length === 0 ? (
        <div className="text-center py-16 glass-panel rounded-2xl border border-white/10 space-y-4">
          <Gamepad2 className="w-12 h-12 text-slate-600 mx-auto" />
          <p className="text-base font-bold text-white">No game history yet</p>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            You haven't played any games in this session yet. Launch a match from our library!
          </p>
          <Link to="/games">
            <NeonButton variant="cyan" size="md">
              Explore Games
            </NeonButton>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {recentGames.map((g: any) => (
            <div
              key={g.slug}
              className="group relative rounded-2xl overflow-hidden glass-panel-interactive border border-white/10 hover:border-neon-cyan/50 flex flex-col justify-between"
            >
              <div className="relative h-44 overflow-hidden">
                <img
                  src={g.thumbnail}
                  alt={g.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-obsidian-950 via-obsidian-950/40 to-transparent" />
                <div className="absolute top-3 left-3">
                  <Badge variant="cyan" size="sm">
                    {g.genre}
                  </Badge>
                </div>
              </div>

              <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <h3 className="text-lg font-bold font-display text-white">{g.title}</h3>
                  <p className="text-xs text-slate-400 line-clamp-2 mt-1">{g.description}</p>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-white/10">
                  <span className="text-[11px] text-slate-500">
                    Played {new Date(g.playedAt).toLocaleDateString()}
                  </span>
                  <Link to={`/games/${g.slug}`}>
                    <NeonButton variant="cyan" size="sm">
                      <Play className="w-4 h-4 fill-current" />
                      Play Again
                    </NeonButton>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
