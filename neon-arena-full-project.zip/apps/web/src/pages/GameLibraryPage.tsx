import React, { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Gamepad2, Search, Filter, Heart, Play, Users, Trophy } from 'lucide-react';
import { api } from '../lib/api.js';
import { useGameStore } from '../stores/gameStore.js';
import { NeonButton } from '../components/ui/NeonButton.js';
import { Badge } from '../components/ui/Badge.js';

export const GameLibraryPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialSearch = searchParams.get('search') || '';
  const initialGenre = searchParams.get('genre') || 'ALL';

  const [games, setGames] = useState<any[]>([]);
  const [search, setSearch] = useState(initialSearch);
  const [selectedGenre, setSelectedGenre] = useState(initialGenre);
  const [multiplayerOnly, setMultiplayerOnly] = useState(false);
  const [loading, setLoading] = useState(true);

  const { favorites, toggleFavorite, isFavorite } = useGameStore();

  useEffect(() => {
    api.games
      .getAll()
      .then((res) => {
        setGames(res.games || []);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Failed to load games:', err);
        setLoading(false);
      });
  }, []);

  const genres = ['ALL', 'Arcade', 'Puzzle', 'Action', 'Strategy', 'Physics'];

  const filteredGames = games.filter((g) => {
    const matchesSearch =
      g.title.toLowerCase().includes(search.toLowerCase()) ||
      g.description.toLowerCase().includes(search.toLowerCase());
    const matchesGenre = selectedGenre === 'ALL' || g.genre.toLowerCase() === selectedGenre.toLowerCase();
    const matchesMp = !multiplayerOnly || g.isMultiplayer;
    return matchesSearch && matchesGenre && matchesMp;
  });

  return (
    <div className="space-y-8">
      {/* Page Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-black font-display text-white flex items-center gap-2.5">
          <Gamepad2 className="w-8 h-8 text-neon-cyan" />
          GAME LIBRARY
        </h1>
        <p className="text-sm text-slate-400">
          Browse our collection of verified, responsive arcade games. All game scores contribute to your global XP and quest progression.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="glass-panel border border-white/10 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Search */}
        <div className="relative w-full md:max-w-xs">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search game title..."
            className="w-full pl-10 pr-4 py-2 bg-obsidian-900 border border-white/10 rounded-xl text-sm text-slate-200 focus:outline-none focus:border-neon-cyan/50"
          />
        </div>

        {/* Genres Pill Bar */}
        <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
          {genres.map((genre) => (
            <button
              key={genre}
              onClick={() => setSelectedGenre(genre)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                selectedGenre === genre
                  ? 'bg-neon-cyan text-obsidian-950 shadow-neon-cyan'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              {genre}
            </button>
          ))}
        </div>

        {/* Multiplayer Toggle */}
        <button
          onClick={() => setMultiplayerOnly(!multiplayerOnly)}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
            multiplayerOnly
              ? 'bg-neon-violet/20 border-neon-violet text-neon-violet shadow-neon-violet'
              : 'border-white/10 text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          <Users className="w-4 h-4" />
          Multiplayer Only
        </button>
      </div>

      {/* Game Cards Grid */}
      {filteredGames.length === 0 ? (
        <div className="text-center py-16 glass-panel rounded-2xl border border-white/10 space-y-3">
          <Gamepad2 className="w-12 h-12 text-slate-600 mx-auto" />
          <p className="text-base font-bold text-white">No games match your search criteria</p>
          <p className="text-xs text-slate-400">Try adjusting your filters or search terms.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredGames.map((g) => {
            const isFav = isFavorite(g.slug);
            return (
              <div
                key={g.slug}
                className="group relative rounded-2xl overflow-hidden glass-panel-interactive border border-white/10 hover:border-neon-cyan/50 flex flex-col justify-between"
              >
                {/* Thumbnail */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={g.thumbnail}
                    alt={g.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-obsidian-950 via-obsidian-950/30 to-transparent" />

                  {/* Badges */}
                  <div className="absolute top-3 left-3 flex gap-1.5">
                    <Badge variant="cyan" size="sm">
                      {g.genre}
                    </Badge>
                    {g.isMultiplayer && (
                      <Badge variant="violet" size="sm">
                        Multiplayer
                      </Badge>
                    )}
                  </div>

                  {/* Favorite Button */}
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      toggleFavorite(g.slug);
                    }}
                    className={`absolute top-3 right-3 p-2 rounded-full glass-panel transition-colors ${
                      isFav ? 'text-neon-magenta fill-neon-magenta' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`} />
                  </button>
                </div>

                {/* Content */}
                <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    <h3 className="text-lg font-bold font-display text-white group-hover:text-neon-cyan transition-colors">
                      {g.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {g.description}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-white/10">
                    <div className="flex items-center gap-1.5 text-xs text-slate-400">
                      <Users className="w-3.5 h-3.5" />
                      <span>{g.isMultiplayer ? '1 - 2 Players' : 'Solo'}</span>
                    </div>

                    <Link to={`/games/${g.slug}`}>
                      <NeonButton variant="cyan" size="sm">
                        <Play className="w-4 h-4 fill-current" />
                        Play Now
                      </NeonButton>
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
