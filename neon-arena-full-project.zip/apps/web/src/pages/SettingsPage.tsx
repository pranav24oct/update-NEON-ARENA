import React, { useState } from 'react';
import { Settings, Volume2, VolumeX, Eye, Shield, Lock, Bell, Check } from 'lucide-react';
import { useGameStore } from '../stores/gameStore.js';
import { useAuthStore } from '../stores/authStore.js';
import { NeonButton } from '../components/ui/NeonButton.js';

export const SettingsPage: React.FC = () => {
  const { isMuted, toggleSound } = useGameStore();
  const { user, isAuthenticated, logout } = useAuthStore();

  const [reducedMotion, setReducedMotion] = useState(false);
  const [allowFriendRequests, setAllowFriendRequests] = useState(true);
  const [publicProfile, setPublicProfile] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-8 max-w-3xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-3xl font-black font-display text-white flex items-center gap-2.5">
          <Settings className="w-8 h-8 text-neon-cyan" />
          PLATFORM SETTINGS
        </h1>
        <p className="text-sm text-slate-400">
          Customize your arena audio, graphic preferences, and player account privacy.
        </p>
      </div>

      <div className="space-y-6">
        {/* Audio Preferences */}
        <div className="glass-panel border border-white/10 rounded-2xl p-6 space-y-4">
          <h2 className="text-base font-bold font-display text-white flex items-center gap-2">
            <Volume2 className="w-5 h-5 text-neon-cyan" />
            Audio & Sound Synthesizer
          </h2>

          <div className="flex items-center justify-between p-3 rounded-xl bg-obsidian-900 border border-white/5">
            <div>
              <span className="text-xs font-bold text-white block">Sound Effects</span>
              <span className="text-[11px] text-slate-400">
                Web Audio procedural chimes, blade slices, and move pulses
              </span>
            </div>

            <button
              onClick={toggleSound}
              className={`p-2.5 rounded-xl border transition-colors ${
                !isMuted
                  ? 'bg-neon-cyan/20 border-neon-cyan text-neon-cyan shadow-neon-cyan'
                  : 'bg-obsidian-950 border-white/10 text-slate-500'
              }`}
            >
              {!isMuted ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Graphics & Accessibility */}
        <div className="glass-panel border border-white/10 rounded-2xl p-6 space-y-4">
          <h2 className="text-base font-bold font-display text-white flex items-center gap-2">
            <Eye className="w-5 h-5 text-neon-violet" />
            Display & Accessibility
          </h2>

          <div className="flex items-center justify-between p-3 rounded-xl bg-obsidian-900 border border-white/5">
            <div>
              <span className="text-xs font-bold text-white block">Reduced Motion Mode</span>
              <span className="text-[11px] text-slate-400">
                Minimizes 3D parallax and high-frequency animations
              </span>
            </div>

            <input
              type="checkbox"
              checked={reducedMotion}
              onChange={(e) => setReducedMotion(e.target.checked)}
              className="w-5 h-5 accent-neon-violet rounded cursor-pointer"
            />
          </div>
        </div>

        {/* Social & Privacy */}
        <div className="glass-panel border border-white/10 rounded-2xl p-6 space-y-4">
          <h2 className="text-base font-bold font-display text-white flex items-center gap-2">
            <Shield className="w-5 h-5 text-neon-gold" />
            Social & Privacy Controls
          </h2>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 rounded-xl bg-obsidian-900 border border-white/5">
              <div>
                <span className="text-xs font-bold text-white block">Public Profile</span>
                <span className="text-[11px] text-slate-400">
                  Allow other gladiators to view your level, stats, and achievements
                </span>
              </div>
              <input
                type="checkbox"
                checked={publicProfile}
                onChange={(e) => setPublicProfile(e.target.checked)}
                className="w-5 h-5 accent-neon-gold rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl bg-obsidian-900 border border-white/5">
              <div>
                <span className="text-xs font-bold text-white block">Allow Friend Requests</span>
                <span className="text-[11px] text-slate-400">
                  Permit other players to send you friendship and duel invitations
                </span>
              </div>
              <input
                type="checkbox"
                checked={allowFriendRequests}
                onChange={(e) => setAllowFriendRequests(e.target.checked)}
                className="w-5 h-5 accent-neon-gold rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Save Bar */}
        <div className="flex items-center justify-between pt-2">
          {savedSuccess && (
            <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5 animate-fadeIn">
              <Check className="w-4 h-4" />
              Settings saved successfully!
            </span>
          )}
          <div className="ml-auto">
            <NeonButton variant="cyan" size="md" onClick={handleSave}>
              Save Preferences
            </NeonButton>
          </div>
        </div>
      </div>
    </div>
  );
};
