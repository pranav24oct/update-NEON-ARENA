import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Sparkles, CheckCircle2, Gift, Flame, Trophy } from 'lucide-react';
import { api } from '../lib/api.js';
import { useAuthStore } from '../stores/authStore.js';
import { NeonButton } from '../components/ui/NeonButton.js';
import { Badge } from '../components/ui/Badge.js';
import { ProgressBar } from '../components/ui/ProgressBar.js';
import confetti from 'canvas-confetti';

export const ChallengesPage: React.FC = () => {
  const { user, isAuthenticated, updateUserStats } = useAuthStore();
  const [challenges, setChallenges] = useState<any[]>([]);
  const [secondsRemaining, setSecondsRemaining] = useState<number>(86400);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.challenges
      .getDaily()
      .then((res) => {
        setChallenges(res.challenges || []);
        setSecondsRemaining(res.resetInSeconds || 86400);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  // Countdown timer
  useEffect(() => {
    const interval = setInterval(() => {
      setSecondsRemaining((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatCountdown = (totalSeconds: number) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${hours.toString().padStart(2, '0')}h ${minutes
      .toString()
      .padStart(2, '0')}m ${seconds.toString().padStart(2, '0')}s`;
  };

  const handleClaim = async (questId: string) => {
    try {
      const resp = await api.quests.claim(questId);
      confetti({ particleCount: 70, spread: 60 });
      updateUserStats(resp.xpAwarded, resp.newTotalXp, resp.level);

      // Update state locally
      setChallenges((prev) =>
        prev.map((c) => (c.id === questId ? { ...c, claimed: true } : c))
      );
    } catch (err: any) {
      alert(err.message || 'Failed to claim reward');
    }
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header & Reset Countdown */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-black font-display text-white flex items-center gap-2.5">
            <Calendar className="w-8 h-8 text-neon-gold" />
            DAILY CHALLENGES
          </h1>
          <p className="text-sm text-slate-400">
            Complete daily missions before reset to earn bonus XP and maintain your activity streak.
          </p>
        </div>

        {/* Countdown Box */}
        <div className="p-3 px-4 rounded-2xl glass-panel border border-neon-gold/40 flex items-center gap-3">
          <Clock className="w-5 h-5 text-neon-gold animate-pulse" />
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase block">RESET IN</span>
            <span className="text-sm font-mono font-bold text-neon-gold">
              {formatCountdown(secondsRemaining)}
            </span>
          </div>
        </div>
      </div>

      {/* Streak & Seasonal Banner */}
      <div className="glass-panel border border-neon-cyan/30 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center">
            <Flame className="w-8 h-8 text-amber-400 animate-bounce" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold font-display text-white">Daily Login Streak</h3>
              <Badge variant="gold" size="sm">
                Active
              </Badge>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Current Streak: <span className="text-white font-bold">{user?.statistics?.currentStreak || 1} Days</span> &bull; Best: {user?.statistics?.bestStreak || 1} Days
            </p>
          </div>
        </div>

        <div className="text-xs text-slate-300 max-w-sm text-right hidden md:block">
          Season 1: Cyber Genesis event active. All daily challenges yield +25% bonus experience points.
        </div>
      </div>

      {/* Challenges List */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold font-display text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-neon-cyan" />
          Today's Missions
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {challenges.map((c) => (
            <div
              key={c.id}
              className={`p-5 rounded-2xl glass-panel border transition-all flex flex-col justify-between space-y-4 ${
                c.claimed
                  ? 'border-white/5 opacity-60'
                  : c.completed
                  ? 'border-emerald-500/50 bg-emerald-950/15'
                  : 'border-white/10 hover:border-white/20'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-sm text-white">{c.title}</h3>
                  <Badge variant={c.completed ? 'emerald' : 'gold'} size="sm">
                    +{c.xpReward} XP
                  </Badge>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">{c.description}</p>
              </div>

              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-slate-400">
                    Progress: {c.progress} / {c.targetCount}
                  </span>
                  <span className={c.completed ? 'text-emerald-400' : 'text-slate-300'}>
                    {c.progressPercent || 0}%
                  </span>
                </div>
                <ProgressBar
                  value={c.progressPercent || 0}
                  color={c.completed ? 'emerald' : 'gold'}
                  height="h-2"
                />

                <div className="pt-2 flex items-center justify-end">
                  {c.claimed ? (
                    <span className="text-xs text-slate-500 font-semibold flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      Reward Claimed
                    </span>
                  ) : c.completed ? (
                    <NeonButton variant="cyan" size="sm" onClick={() => handleClaim(c.id)}>
                      <Gift className="w-4 h-4" />
                      Claim {c.xpReward} XP
                    </NeonButton>
                  ) : (
                    <span className="text-xs text-slate-500 font-medium">In Progress</span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
