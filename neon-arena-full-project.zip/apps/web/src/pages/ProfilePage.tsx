import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
  User as UserIcon,
  Trophy,
  Award,
  Swords,
  Flame,
  Calendar,
  Edit3,
  CheckCircle2,
  Shield,
  Gamepad2
} from 'lucide-react';
import { api } from '../lib/api.js';
import { useAuthStore } from '../stores/authStore.js';
import { NeonButton } from '../components/ui/NeonButton.js';
import { Badge } from '../components/ui/Badge.js';
import { Modal } from '../components/ui/Modal.js';
import { ProgressBar } from '../components/ui/ProgressBar.js';
import { calculateLevelFromXp, COMPETITIVE_TIERS, getTierFromRating } from '@neon-arena/shared';
import { AVATAR_PRESETS } from '@neon-arena/config';

export const ProfilePage: React.FC = () => {
  const { username } = useParams<{ username?: string }>();
  const { user: currentUser, isAuthenticated } = useAuthStore();

  const isMyProfile = !username || (currentUser && currentUser.username === username);
  const targetUsername = isMyProfile ? currentUser?.username : username;

  const [profileData, setProfileData] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);

  // Edit Profile Modal
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editDisplayName, setEditDisplayName] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editAvatar, setEditAvatar] = useState('');

  const loadProfile = () => {
    if (!targetUsername) {
      setLoading(false);
      return;
    }

    api.players
      .getProfile(targetUsername)
      .then((res) => {
        setProfileData(res.player);
        setEditDisplayName(res.player.profile?.displayName || res.player.username);
        setEditBio(res.player.profile?.bio || '');
        setEditAvatar(res.player.profile?.avatar || '');
        setLoading(false);
      })
      .catch((err) => {
        console.error('Error loading profile:', err);
        setLoading(false);
      });
  };

  useEffect(() => {
    loadProfile();
  }, [targetUsername]);

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.players.updateMyProfile({
        displayName: editDisplayName,
        bio: editBio,
        avatar: editAvatar
      });
      setIsEditOpen(false);
      loadProfile();
    } catch (err: any) {
      alert(err.message || 'Failed to update profile');
    }
  };

  if (loading) {
    return <div className="text-center py-20 text-slate-400">Loading gladiator profile...</div>;
  }

  if (!profileData) {
    return (
      <div className="text-center py-20 space-y-3">
        <h2 className="text-2xl font-bold text-white">Player Not Found</h2>
        <p className="text-xs text-slate-400">The requested profile does not exist or has been removed.</p>
      </div>
    );
  }

  const stats = profileData.statistics || {};
  const totalGames = stats.totalGamesPlayed || 0;
  const totalWins = stats.totalWins || 0;
  const winRate = totalGames > 0 ? Math.round((totalWins / totalGames) * 100) : 0;
  const totalXp = stats.totalXp || 0;
  const { level, currentLevelXp, nextLevelXp, progressPercent } = calculateLevelFromXp(totalXp);

  const rating = 1200;
  const tierEnum = getTierFromRating(rating);
  const tierInfo = COMPETITIVE_TIERS[tierEnum];

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Profile Header Banner */}
      <div className="relative rounded-3xl overflow-hidden glass-panel border border-neon-cyan/30 p-6 md:p-8 shadow-2xl">
        <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left">
            <img
              src={
                profileData.profile?.avatar ||
                'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80'
              }
              alt={profileData.username}
              className="w-24 h-24 rounded-2xl object-cover border-2 border-neon-cyan shadow-neon-cyan"
            />
            <div className="space-y-2">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <h1 className="text-2xl sm:text-3xl font-black font-display text-white">
                  {profileData.profile?.displayName || profileData.username}
                </h1>
                <Badge variant="cyan" size="sm">
                  LVL {level}
                </Badge>
                {profileData.role === 'ADMIN' && (
                  <Badge variant="magenta" size="sm">
                    Admin
                  </Badge>
                )}
              </div>

              <p className="text-xs text-slate-400">
                @{profileData.username} &bull; Member since{' '}
                {new Date(profileData.joinDate).toLocaleDateString()}
              </p>

              {profileData.profile?.bio && (
                <p className="text-xs text-slate-300 max-w-lg leading-relaxed">
                  {profileData.profile.bio}
                </p>
              )}
            </div>
          </div>

          {/* Edit Profile Button if My Profile */}
          {isMyProfile && (
            <NeonButton variant="outline" size="sm" onClick={() => setIsEditOpen(true)}>
              <Edit3 className="w-4 h-4" />
              Edit Profile
            </NeonButton>
          )}
        </div>

        {/* Level XP Bar */}
        <div className="mt-8 pt-6 border-t border-white/10 space-y-2 max-w-xl">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className="text-slate-300">Level {level} Progress</span>
            <span className="text-neon-cyan font-display">
              {currentLevelXp} / {nextLevelXp} XP ({progressPercent}%)
            </span>
          </div>
          <ProgressBar value={progressPercent} color="cyan" height="h-2.5" />
        </div>
      </div>

      {/* Stats Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl glass-panel border border-white/10 text-center space-y-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase">TOTAL GAMES</span>
          <p className="text-2xl font-black font-display text-white">{totalGames}</p>
        </div>

        <div className="p-4 rounded-2xl glass-panel border border-white/10 text-center space-y-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase">WIN RATE</span>
          <p className="text-2xl font-black font-display text-emerald-400">{winRate}%</p>
        </div>

        <div className="p-4 rounded-2xl glass-panel border border-white/10 text-center space-y-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase">WIN STREAK</span>
          <p className="text-2xl font-black font-display text-amber-400 flex items-center justify-center gap-1">
            <Flame className="w-5 h-5 text-amber-400" />
            {stats.currentStreak || 0}
          </p>
        </div>

        <div className="p-4 rounded-2xl glass-panel border border-white/10 text-center space-y-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase">COMPETITIVE RANK</span>
          <p className="text-sm font-bold font-display uppercase tracking-wider" style={{ color: tierInfo.color }}>
            {tierInfo.label}
          </p>
        </div>
      </div>

      {/* Recent Matches & Trophies */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Personal Best High Scores */}
        <div className="glass-panel border border-white/10 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-bold font-display text-white flex items-center gap-2">
            <Trophy className="w-5 h-5 text-neon-gold" />
            Game High Scores
          </h3>

          <div className="space-y-2.5">
            {profileData.topScores?.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">No scores recorded yet.</p>
            ) : (
              profileData.topScores?.map((score: any) => (
                <div
                  key={score.id}
                  className="flex items-center justify-between p-3 rounded-xl bg-obsidian-900 border border-white/5"
                >
                  <span className="text-xs font-bold text-white">{score.game.title}</span>
                  <span className="text-sm font-bold font-display text-neon-cyan">
                    {score.score} PTS
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Matches */}
        <div className="glass-panel border border-white/10 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-bold font-display text-white flex items-center gap-2">
            <Swords className="w-5 h-5 text-neon-violet" />
            Recent Match Participations
          </h3>

          <div className="space-y-2.5">
            {profileData.recentMatches?.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">No recent matches played.</p>
            ) : (
              profileData.recentMatches?.map((m: any, idx: number) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-xl bg-obsidian-900 border border-white/5"
                >
                  <div>
                    <span className="text-xs font-bold text-white block">{m.game}</span>
                    <span className="text-[10px] text-slate-400">
                      {new Date(m.endedAt).toLocaleDateString()}
                    </span>
                  </div>

                  <div className="text-right">
                    <span
                      className={`text-xs font-bold ${
                        m.isWinner ? 'text-emerald-400' : 'text-slate-400'
                      }`}
                    >
                      {m.isWinner ? 'Victory' : m.status}
                    </span>
                    {m.ratingDelta !== 0 && (
                      <span className="text-[10px] text-neon-violet block">
                        {m.ratingDelta > 0 ? `+${m.ratingDelta}` : m.ratingDelta} Elo
                      </span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Edit Profile Modal */}
      <Modal isOpen={isEditOpen} onClose={() => setIsEditOpen(false)} title="Edit Player Profile">
        <form onSubmit={handleUpdateProfile} className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">Display Name</label>
            <input
              type="text"
              value={editDisplayName}
              onChange={(e) => setEditDisplayName(e.target.value)}
              className="w-full px-3 py-2 bg-obsidian-900 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-neon-cyan"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">Gladiator Bio</label>
            <textarea
              value={editBio}
              onChange={(e) => setEditBio(e.target.value)}
              rows={3}
              className="w-full p-3 bg-obsidian-900 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-neon-cyan"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-2">Avatar Preset</label>
            <div className="flex flex-wrap gap-2.5">
              {AVATAR_PRESETS.map((avUrl, idx) => (
                <img
                  key={idx}
                  src={avUrl}
                  alt={`Preset ${idx}`}
                  onClick={() => setEditAvatar(avUrl)}
                  className={`w-12 h-12 rounded-xl object-cover cursor-pointer border-2 transition-all ${
                    editAvatar === avUrl ? 'border-neon-cyan scale-105 shadow-neon-cyan' : 'border-white/10 opacity-70 hover:opacity-100'
                  }`}
                />
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3">
            <NeonButton variant="ghost" size="sm" type="button" onClick={() => setIsEditOpen(false)}>
              Cancel
            </NeonButton>
            <NeonButton variant="cyan" size="sm" type="submit">
              Save Changes
            </NeonButton>
          </div>
        </form>
      </Modal>
    </div>
  );
};
