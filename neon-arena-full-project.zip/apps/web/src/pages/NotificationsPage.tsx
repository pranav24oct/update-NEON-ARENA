import React, { useState, useEffect } from 'react';
import { Bell, CheckCheck, Trash2, Sparkles, UserPlus, Trophy, AlertCircle } from 'lucide-react';
import { api } from '../lib/api.js';
import { useAuthStore } from '../stores/authStore.js';
import { NeonButton } from '../components/ui/NeonButton.js';
import { Badge } from '../components/ui/Badge.js';

export const NotificationsPage: React.FC = () => {
  const { isAuthenticated } = useAuthStore();
  const [notifications, setNotifications] = useState<any[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [loading, setLoading] = useState(true);

  const loadNotifications = () => {
    if (!isAuthenticated) return;
    api.notifications
      .getAll()
      .then((res) => {
        setNotifications(res.notifications || []);
        setUnreadCount(res.unreadCount || 0);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };

  useEffect(() => {
    loadNotifications();
  }, [isAuthenticated]);

  const handleMarkAllRead = async () => {
    try {
      await api.notifications.markAllRead();
      loadNotifications();
    } catch (err) {
      console.error('Failed to mark all read:', err);
    }
  };

  const handleMarkSingleRead = async (id: string) => {
    try {
      await api.notifications.markRead(id);
      loadNotifications();
    } catch (err) {
      console.error('Failed to mark single read:', err);
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'FRIEND_REQUEST':
      case 'FRIEND_ACCEPTED':
        return <UserPlus className="w-5 h-5 text-neon-cyan" />;
      case 'LEVEL_UP':
      case 'ACHIEVEMENT_UNLOCKED':
        return <Trophy className="w-5 h-5 text-neon-gold" />;
      case 'TOURNAMENT_ALERT':
        return <Sparkles className="w-5 h-5 text-neon-violet" />;
      default:
        return <Bell className="w-5 h-5 text-slate-400" />;
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="text-center py-20 space-y-3">
        <Bell className="w-12 h-12 text-slate-600 mx-auto" />
        <h2 className="text-2xl font-bold text-white">Notifications</h2>
        <p className="text-xs text-slate-400">Please sign in to view your alert inbox.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h1 className="text-3xl font-black font-display text-white">NOTIFICATIONS</h1>
            {unreadCount > 0 && (
              <Badge variant="magenta" size="sm">
                {unreadCount} Unread
              </Badge>
            )}
          </div>
          <p className="text-sm text-slate-400">
            System alerts, challenge awards, friend requests, and match results.
          </p>
        </div>

        {unreadCount > 0 && (
          <NeonButton variant="outline" size="sm" onClick={handleMarkAllRead}>
            <CheckCheck className="w-4 h-4" />
            Mark All Read
          </NeonButton>
        )}
      </div>

      {/* Notifications List */}
      <div className="space-y-3">
        {notifications.length === 0 ? (
          <div className="text-center py-16 glass-panel rounded-2xl border border-white/10 text-slate-400 text-xs">
            No notifications in your inbox.
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              onClick={() => !n.isRead && handleMarkSingleRead(n.id)}
              className={`p-4 rounded-2xl glass-panel border transition-all flex items-start justify-between gap-4 cursor-pointer ${
                !n.isRead
                  ? 'border-neon-cyan/40 bg-neon-cyan/5 shadow-[0_0_15px_rgba(0,240,255,0.08)]'
                  : 'border-white/5 opacity-70 hover:opacity-100'
              }`}
            >
              <div className="flex items-start gap-3.5">
                <div className="p-2.5 rounded-xl bg-obsidian-900 border border-white/10 flex-shrink-0">
                  {getNotificationIcon(n.type)}
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-sm text-white">{n.title}</h3>
                    {!n.isRead && (
                      <span className="w-2 h-2 rounded-full bg-neon-cyan animate-pulse" />
                    )}
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed">{n.message}</p>
                  <span className="text-[10px] text-slate-500 block">
                    {new Date(n.createdAt).toLocaleDateString()} &bull;{' '}
                    {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
              </div>

              {!n.isRead && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleMarkSingleRead(n.id);
                  }}
                  className="text-xs text-neon-cyan hover:underline font-semibold flex-shrink-0"
                >
                  Mark read
                </button>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};
