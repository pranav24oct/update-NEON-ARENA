import React, { useState, useEffect } from 'react';
import { Users, UserPlus, Check, X, ShieldAlert, Ban, MessageSquare, Gamepad2, Send } from 'lucide-react';
import { api } from '../lib/api.js';
import { getSocket } from '../lib/socket.js';
import { useAuthStore } from '../stores/authStore.js';
import { NeonButton } from '../components/ui/NeonButton.js';
import { Badge } from '../components/ui/Badge.js';
import { Modal } from '../components/ui/Modal.js';

export const FriendsPage: React.FC = () => {
  const { user, isAuthenticated } = useAuthStore();
  const socket = getSocket();

  const [friends, setFriends] = useState<any[]>([]);
  const [pendingIncoming, setPendingIncoming] = useState<any[]>([]);
  const [targetUsername, setTargetUsername] = useState('');
  const [loading, setLoading] = useState(true);

  // Report Modal
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportTargetId, setReportTargetId] = useState('');
  const [reportReason, setReportReason] = useState('');

  const loadFriends = () => {
    if (!isAuthenticated) return;
    api.friends
      .getList()
      .then((res) => {
        setFriends(res.friends || []);
        setPendingIncoming(res.pendingIncoming || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  };

  useEffect(() => {
    loadFriends();
  }, [isAuthenticated]);

  const handleSendRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetUsername.trim()) return;

    try {
      await api.friends.sendRequest(targetUsername.trim());
      alert(`Friend request sent to ${targetUsername}!`);
      setTargetUsername('');
      loadFriends();
    } catch (err: any) {
      alert(err.message || 'Failed to send request');
    }
  };

  const handleRespond = async (requestId: string, action: 'ACCEPT' | 'DECLINE') => {
    try {
      await api.friends.respond(requestId, action);
      loadFriends();
    } catch (err: any) {
      alert(err.message || 'Failed to process request');
    }
  };

  const handleRemoveFriend = async (friendshipId: string) => {
    if (!confirm('Remove this player from your friends list?')) return;
    try {
      await api.friends.remove(friendshipId);
      loadFriends();
    } catch (err: any) {
      alert(err.message || 'Failed to remove friend');
    }
  };

  const handleBlockUser = async (targetUserId: string) => {
    if (!confirm('Are you sure you want to block this user?')) return;
    try {
      await api.friends.block(targetUserId);
      alert('User blocked.');
      loadFriends();
    } catch (err: any) {
      alert(err.message || 'Failed to block user');
    }
  };

  const handleReportUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reportReason.trim()) return;
    try {
      await api.friends.report({ targetUserId: reportTargetId, reason: reportReason.trim() });
      alert('Report submitted to moderation team.');
      setReportModalOpen(false);
      setReportReason('');
    } catch (err: any) {
      alert(err.message || 'Failed to submit report');
    }
  };

  const handleInviteToGame = (friendId: string) => {
    socket.emit('social:send_invite', { targetUserId: friendId, roomCode: 'QUICK' });
    alert('Match invite sent to friend!');
  };

  if (!isAuthenticated) {
    return (
      <div className="text-center py-20 space-y-4">
        <Users className="w-12 h-12 text-slate-600 mx-auto" />
        <h2 className="text-2xl font-bold text-white">Friends & Social</h2>
        <p className="text-sm text-slate-400">Please sign in to connect with friends and invite them to duels.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-3xl font-black font-display text-white flex items-center gap-2.5">
          <Users className="w-8 h-8 text-neon-cyan" />
          FRIENDS & SOCIAL
        </h1>
        <p className="text-sm text-slate-400">
          Connect with gladiators, track live presence, and invite companions to competitive multiplayer duels.
        </p>
      </div>

      {/* Add Friend Input */}
      <form
        onSubmit={handleSendRequest}
        className="glass-panel border border-white/10 rounded-2xl p-4 flex flex-col sm:flex-row items-center gap-3"
      >
        <div className="relative flex-1 w-full">
          <UserPlus className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={targetUsername}
            onChange={(e) => setTargetUsername(e.target.value)}
            placeholder="Enter player's exact username..."
            className="w-full pl-10 pr-4 py-2 bg-obsidian-900 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-neon-cyan"
          />
        </div>
        <NeonButton variant="cyan" size="md" type="submit" className="w-full sm:w-auto">
          Send Friend Request
        </NeonButton>
      </form>

      {/* Pending Incoming Requests */}
      {pendingIncoming.length > 0 && (
        <div className="glass-panel border border-neon-violet/30 rounded-2xl p-6 space-y-4">
          <h2 className="text-base font-bold font-display text-white flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-neon-violet animate-ping" />
            Pending Friend Requests ({pendingIncoming.length})
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {pendingIncoming.map((req) => (
              <div
                key={req.friendshipId}
                className="p-3 rounded-xl bg-obsidian-900 border border-white/10 flex items-center justify-between"
              >
                <div className="flex items-center gap-2.5">
                  <img
                    src={req.sender.avatar || 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80'}
                    alt={req.sender.username}
                    className="w-8 h-8 rounded-full object-cover border border-white/10"
                  />
                  <div>
                    <span className="text-xs font-bold text-white block">{req.sender.displayName}</span>
                    <span className="text-[10px] text-slate-400">@{req.sender.username}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleRespond(req.friendshipId, 'ACCEPT')}
                    className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 transition-colors"
                    title="Accept"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleRespond(req.friendshipId, 'DECLINE')}
                    className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400 hover:bg-rose-500/30 transition-colors"
                    title="Decline"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Friends List */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold font-display text-white">
          Active Companions ({friends.length})
        </h2>

        {friends.length === 0 ? (
          <div className="text-center py-12 glass-panel rounded-2xl border border-white/10 text-slate-400 text-xs">
            No friends added yet. Enter a username above to start your social circle!
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {friends.map((friend) => (
              <div
                key={friend.friendshipId}
                className="p-4 rounded-2xl glass-panel border border-white/10 hover:border-neon-cyan/40 transition-colors flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <img
                      src={
                        friend.avatar ||
                        'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80'
                      }
                      alt={friend.username}
                      className="w-10 h-10 rounded-full object-cover border border-neon-cyan/30"
                    />
                    <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-emerald-400 border-2 border-obsidian-950" />
                  </div>

                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-sm font-bold text-white">{friend.displayName}</span>
                      <Badge variant="cyan" size="sm">
                        LVL {friend.level}
                      </Badge>
                    </div>
                    <span className="text-[11px] text-slate-400">@{friend.username}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleInviteToGame(friend.friendId)}
                    className="p-2 rounded-xl bg-neon-cyan/15 text-neon-cyan hover:bg-neon-cyan/25 transition-colors"
                    title="Invite to Game"
                  >
                    <Gamepad2 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => {
                      setReportTargetId(friend.friendId);
                      setReportModalOpen(true);
                    }}
                    className="p-2 rounded-xl text-slate-400 hover:text-amber-400 hover:bg-white/5 transition-colors"
                    title="Report User"
                  >
                    <ShieldAlert className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => handleRemoveFriend(friend.friendshipId)}
                    className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-white/5 transition-colors"
                    title="Remove Friend"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Report User Modal */}
      <Modal isOpen={reportModalOpen} onClose={() => setReportModalOpen(false)} title="Report User">
        <form onSubmit={handleReportUser} className="space-y-4">
          <p className="text-xs text-slate-400">
            Submit an incident report for moderation. False reports are subject to disciplinary action.
          </p>
          <textarea
            value={reportReason}
            onChange={(e) => setReportReason(e.target.value)}
            rows={4}
            required
            placeholder="Describe the violation (e.g. offensive language, cheating, harassment)..."
            className="w-full p-3 bg-obsidian-900 border border-white/10 rounded-xl text-xs text-white focus:outline-none focus:border-neon-magenta"
          />
          <div className="flex justify-end gap-2">
            <NeonButton variant="ghost" size="sm" type="button" onClick={() => setReportModalOpen(false)}>
              Cancel
            </NeonButton>
            <NeonButton variant="magenta" size="sm" type="submit">
              Submit Report
            </NeonButton>
          </div>
        </form>
      </Modal>
    </div>
  );
};
