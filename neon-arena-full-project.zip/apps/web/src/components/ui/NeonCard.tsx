import React from 'react';

interface NeonCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  interactive?: boolean;
  glowColor?: 'cyan' | 'violet' | 'magenta' | 'none';
  className?: string;
}

export const NeonCard: React.FC<NeonCardProps> = ({
  children,
  interactive = false,
  glowColor = 'none',
  className = '',
  ...props
}) => {
  const glowStyles = {
    cyan: 'border-neon-cyan/40 shadow-[0_0_15px_rgba(0,240,255,0.2)]',
    violet: 'border-neon-violet/40 shadow-[0_0_15px_rgba(157,78,221,0.2)]',
    magenta: 'border-neon-magenta/40 shadow-[0_0_15px_rgba(244,63,94,0.2)]',
    none: 'border-white/10'
  }[glowColor];

  const interactiveStyles = interactive
    ? 'glass-panel-interactive cursor-pointer hover:border-neon-cyan/50'
    : 'glass-panel';

  return (
    <div
      className={`rounded-xl p-5 ${interactiveStyles} ${glowStyles} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
};
