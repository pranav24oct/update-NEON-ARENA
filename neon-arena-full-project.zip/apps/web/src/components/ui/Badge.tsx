import React from 'react';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'cyan' | 'violet' | 'magenta' | 'gold' | 'emerald' | 'gray';
  size?: 'sm' | 'md';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'cyan',
  size = 'md',
  className = ''
}) => {
  const sizeStyles = size === 'sm' ? 'text-xs px-2 py-0.5' : 'text-xs px-2.5 py-1';

  const variantStyles = {
    cyan: 'bg-neon-cyan/15 text-neon-cyan border border-neon-cyan/30',
    violet: 'bg-neon-violet/15 text-neon-violet border border-neon-violet/30',
    magenta: 'bg-neon-magenta/15 text-neon-magenta border border-neon-magenta/30',
    gold: 'bg-neon-gold/15 text-neon-gold border border-neon-gold/30',
    emerald: 'bg-neon-emerald/15 text-neon-emerald border border-neon-emerald/30',
    gray: 'bg-slate-800 text-slate-300 border border-slate-700'
  }[variant];

  return (
    <span
      className={`inline-flex items-center font-medium rounded-full tracking-wide uppercase ${sizeStyles} ${variantStyles} ${className}`}
    >
      {children}
    </span>
  );
};
