import React from 'react';
import { soundManager } from '../../lib/audio.js';

interface NeonButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'cyan' | 'violet' | 'magenta' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  glow?: boolean;
  children: React.ReactNode;
}

export const NeonButton: React.FC<NeonButtonProps> = ({
  variant = 'cyan',
  size = 'md',
  glow = true,
  className = '',
  onClick,
  children,
  ...props
}) => {
  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    soundManager.playClick();
    if (onClick) onClick(e);
  };

  const baseStyles =
    'relative inline-flex items-center justify-center font-semibold rounded-lg transition-all duration-200 select-none disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer active:scale-95';

  const sizeStyles = {
    sm: 'text-xs px-3 py-1.5 gap-1.5',
    md: 'text-sm px-4 py-2 gap-2',
    lg: 'text-base px-6 py-3 gap-2.5'
  }[size];

  const variantStyles = {
    cyan: `bg-neon-cyan text-obsidian-950 font-bold hover:bg-[#33f3ff] ${
      glow ? 'shadow-neon-cyan hover:shadow-[0_0_25px_rgba(0,240,255,0.7)]' : ''
    }`,
    violet: `bg-neon-violet text-white font-bold hover:bg-[#b05eed] ${
      glow ? 'shadow-neon-violet hover:shadow-[0_0_25px_rgba(157,78,221,0.7)]' : ''
    }`,
    magenta: `bg-neon-magenta text-white font-bold hover:bg-[#f65a75] ${
      glow ? 'shadow-neon-magenta hover:shadow-[0_0_25px_rgba(244,63,94,0.7)]' : ''
    }`,
    outline:
      'border border-slate-700 bg-obsidian-900/60 text-slate-200 hover:border-neon-cyan hover:text-neon-cyan hover:bg-neon-cyan/5',
    ghost: 'text-slate-400 hover:text-white hover:bg-white/5'
  }[variant];

  return (
    <button
      className={`${baseStyles} ${sizeStyles} ${variantStyles} ${className}`}
      onClick={handleClick}
      {...props}
    >
      {children}
    </button>
  );
};
