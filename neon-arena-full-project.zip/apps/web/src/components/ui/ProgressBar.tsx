import React from 'react';

interface ProgressBarProps {
  value: number; // 0 - 100
  color?: 'cyan' | 'violet' | 'gold' | 'emerald';
  height?: string;
  showLabel?: boolean;
  className?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  value,
  color = 'cyan',
  height = 'h-2.5',
  showLabel = false,
  className = ''
}) => {
  const clamped = Math.max(0, Math.min(100, value));

  const barColor = {
    cyan: 'bg-gradient-to-r from-cyan-500 to-neon-cyan shadow-[0_0_10px_rgba(0,240,255,0.5)]',
    violet: 'bg-gradient-to-r from-violet-600 to-neon-violet shadow-[0_0_10px_rgba(157,78,221,0.5)]',
    gold: 'bg-gradient-to-r from-amber-500 to-neon-gold shadow-[0_0_10px_rgba(251,191,36,0.5)]',
    emerald: 'bg-gradient-to-r from-emerald-600 to-neon-emerald shadow-[0_0_10px_rgba(16,185,129,0.5)]'
  }[color];

  return (
    <div className={`w-full ${className}`}>
      {showLabel && (
        <div className="flex justify-between items-center text-xs text-slate-400 mb-1.5 font-medium">
          <span>Progress</span>
          <span className="text-white font-semibold">{clamped}%</span>
        </div>
      )}
      <div className={`w-full bg-obsidian-900/80 rounded-full overflow-hidden border border-white/5 ${height}`}>
        <div
          className={`${height} ${barColor} transition-all duration-500 ease-out rounded-full`}
          style={{ width: `${clamped}%` }}
        />
      </div>
    </div>
  );
};
