import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

export const NeonHeroCanvas: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!mountRef.current) return;

    const width = mountRef.current.clientWidth;
    const height = mountRef.current.clientHeight;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x07080c, 0.035);

    const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 1000);
    camera.position.set(0, 5, 20);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    mountRef.current.appendChild(renderer.domElement);

    // 1. Cyber Grid Floor
    const gridHelper = new THREE.GridHelper(80, 50, 0x00f0ff, 0x181b2a);
    gridHelper.position.y = -4;
    scene.add(gridHelper);

    // 2. Glowing Floating Polyhedrons (Icosahedron & Octahedron)
    const geometryIco = new THREE.IcosahedronGeometry(2.5, 0);
    const materialIco = new THREE.MeshBasicMaterial({
      color: 0x00f0ff,
      wireframe: true,
      transparent: true,
      opacity: 0.75
    });
    const icoMesh = new THREE.Mesh(geometryIco, materialIco);
    icoMesh.position.set(-6, 2, 2);
    scene.add(icoMesh);

    const geometryOct = new THREE.OctahedronGeometry(2, 0);
    const materialOct = new THREE.MeshBasicMaterial({
      color: 0x9d4edd,
      wireframe: true,
      transparent: true,
      opacity: 0.75
    });
    const octMesh = new THREE.Mesh(geometryOct, materialOct);
    octMesh.position.set(7, 3, -2);
    scene.add(octMesh);

    // 3. Floating Particle Field
    const particleCount = 200;
    const particleGeometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    const color1 = new THREE.Color(0x00f0ff);
    const color2 = new THREE.Color(0x9d4edd);

    for (let i = 0; i < particleCount; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 40;
      positions[i * 3 + 1] = Math.random() * 20 - 4;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 40;

      const mixedColor = Math.random() > 0.5 ? color1 : color2;
      colors[i * 3] = mixedColor.r;
      colors[i * 3 + 1] = mixedColor.g;
      colors[i * 3 + 2] = mixedColor.b;
    }

    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const particleMaterial = new THREE.PointsMaterial({
      size: 0.18,
      vertexColors: true,
      transparent: true,
      opacity: 0.8
    });

    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);

    // Mouse Interaction
    let mouseX = 0;
    let mouseY = 0;
    const handleMouseMove = (e: MouseEvent) => {
      const rect = mountRef.current?.getBoundingClientRect();
      if (!rect) return;
      mouseX = ((e.clientX - rect.left) / width - 0.5) * 2;
      mouseY = -((e.clientY - rect.top) / height - 0.5) * 2;
    };
    window.addEventListener('mousemove', handleMouseMove);

    // Animation Loop
    let animId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Rotate polyhedrons
      icoMesh.rotation.x = elapsedTime * 0.3;
      icoMesh.rotation.y = elapsedTime * 0.4;
      icoMesh.position.y = 2 + Math.sin(elapsedTime * 1.5) * 0.5;

      octMesh.rotation.x = elapsedTime * 0.4;
      octMesh.rotation.z = elapsedTime * 0.3;
      octMesh.position.y = 3 + Math.cos(elapsedTime * 1.2) * 0.6;

      // Slowly move grid backwards
      gridHelper.position.z = (elapsedTime * 2) % (80 / 50);

      // Subtle camera tilt toward mouse
      camera.position.x += (mouseX * 4 - camera.position.x) * 0.05;
      camera.position.y += (mouseY * 2 + 5 - camera.position.y) * 0.05;
      camera.lookAt(0, 1, 0);

      renderer.render(scene, camera);
    };

    animate();

    // Handle Resize
    const handleResize = () => {
      if (!mountRef.current) return;
      const newWidth = mountRef.current.clientWidth;
      const newHeight = mountRef.current.clientHeight;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  return <div ref={mountRef} className="absolute inset-0 w-full h-full pointer-events-none opacity-85 z-0" />;
};
