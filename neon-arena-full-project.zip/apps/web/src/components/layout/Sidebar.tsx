import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  Home,
  Gamepad2,
  Clock,
  Heart,
  Swords,
  Calendar,
  Scroll,
  Trophy,
  Award,
  Users,
  ShieldCheck,
  User,
  Bell,
  Settings,
  Lock,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { useAuthStore } from '../../stores/authStore.js';
import { ProgressBar } from '../ui/ProgressBar.js';
import { calculateLevelFromXp } from '@neon-arena/shared';

interface SidebarProps {
  isOpen: boolean;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  isCollapsed,
  onToggleCollapse,
  onCloseMobile
}) => {
  const { user } = useAuthStore();

  const navSections = [
    {
      title: 'DISCOVER',
      items: [
        { label: 'Home', path: '/', icon: Home },
        { label: 'Game Library', path: '/games', icon: Gamepad2 },
        { label: 'Recently Played', path: '/recently-played', icon: Clock },
        { label: 'Favorites', path: '/favorites', icon: Heart }
      ]
    },
    {
      title: 'COMPETITIVE',
      items: [
        { label: 'Multiplayer Arena', path: '/multiplayer', icon: Swords, highlight: true },
        { label: 'Tournaments', path: '/tournaments', icon: Trophy },
        { label: 'Leaderboards', path: '/leaderboards', icon: Award }
      ]
    },
    {
      title: 'PROGRESSION',
      items: [
        { label: 'Daily Challenges', path: '/challenges', icon: Calendar },
        { label: 'Quests', path: '/quests', icon: Scroll },
        { label: 'Achievements', path: '/achievements', icon: ShieldCheck }
      ]
    },
    {
      title: 'COMMUNITY',
      items: [
        { label: 'Friends & Social', path: '/friends', icon: Users },
        { label: 'Player Profile', path: '/profile', icon: User },
        { label: 'Notifications', path: '/notifications', icon: Bell },
        { label: 'Settings', path: '/settings', icon: Settings }
      ]
    }
  ];

  // Progression calculation for current player
  const totalXp = user?.statistics?.totalXp || 0;
  const { level, currentLevelXp, nextLevelXp, progressPercent } = calculateLevelFromXp(totalXp);

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden animate-fadeIn"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed md:sticky top-16 z-40 h-[calc(100vh-4rem)] glass-panel border-r border-white/10 flex flex-col justify-between transition-all duration-300 ${
          isCollapsed ? 'w-20' : 'w-64'
        } ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}
      >
        {/* Navigation Items */}
        <div className="flex-1 overflow-y-auto py-4 px-3 space-y-6">
          {navSections.map((section, sIdx) => (
            <div key={sIdx} className="space-y-1">
              {!isCollapsed && (
                <p className="px-3 text-[11px] font-bold text-slate-500 uppercase tracking-widest font-display mb-2">
                  {section.title}
                </p>
              )}
              {section.items.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.path}
                    to={item.path}
                    onClick={onCloseMobile}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all group ${
                        isActive
                          ? 'bg-neon-cyan/15 text-neon-cyan border border-neon-cyan/30 shadow-[0_0_15px_rgba(0,240,255,0.15)] font-semibold'
                          : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                      } ${item.highlight && !isActive ? 'text-neon-cyan/80 hover:text-neon-cyan' : ''}`
                    }
                    title={isCollapsed ? item.label : undefined}
                  >
                    <Icon className="w-5 h-5 flex-shrink-0 group-hover:scale-110 transition-transform" />
                    {!isCollapsed && <span className="truncate">{item.label}</span>}
                  </NavLink>
                );
              })}
            </div>
          ))}

          {/* Admin Dashboard Link if Admin */}
          {user?.role === 'ADMIN' && (
            <div className="pt-2 border-t border-white/10">
              <NavLink
                to="/admin"
                onClick={onCloseMobile}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-neon-magenta/20 text-neon-magenta border border-neon-magenta/40 font-bold'
                      : 'text-neon-magenta/80 hover:text-neon-magenta hover:bg-neon-magenta/10'
                  }`
                }
              >
                <Lock className="w-5 h-5 flex-shrink-0" />
                {!isCollapsed && <span className="font-bold">Admin Console</span>}
              </NavLink>
            </div>
          )}
        </div>

        {/* Footer Level Badge & Collapse Button */}
        <div className="p-3 border-t border-white/10 bg-obsidian-950/60">
          {!isCollapsed && user && (
            <div className="mb-3 p-3 rounded-xl bg-obsidian-900/80 border border-white/5">
              <div className="flex items-center justify-between text-xs mb-1.5 font-semibold">
                <span className="text-slate-300">Level {level}</span>
                <span className="text-neon-cyan">
                  {currentLevelXp} / {nextLevelXp} XP
                </span>
              </div>
              <ProgressBar value={progressPercent} color="cyan" height="h-1.5" />
            </div>
          )}

          <div className="flex items-center justify-end">
            <button
              onClick={onToggleCollapse}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors hidden md:block"
              title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
            >
              {isCollapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
