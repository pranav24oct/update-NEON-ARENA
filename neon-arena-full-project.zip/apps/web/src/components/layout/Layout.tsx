import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Navbar } from './Navbar.js';
import { Sidebar } from './Sidebar.js';
import { Footer } from './Footer.js';

export const Layout: React.FC = () => {
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isDesktopCollapsed, setIsDesktopCollapsed] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-obsidian-950 text-slate-100 bg-cyber-grid">
      <Navbar
        onToggleSidebar={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
        isSidebarOpen={isMobileSidebarOpen}
      />

      <div className="flex-1 flex w-full">
        <Sidebar
          isOpen={isMobileSidebarOpen}
          isCollapsed={isDesktopCollapsed}
          onToggleCollapse={() => setIsDesktopCollapsed(!isDesktopCollapsed)}
          onCloseMobile={() => setIsMobileSidebarOpen(false)}
        />

        <main className="flex-1 min-w-0 flex flex-col overflow-x-hidden">
          <div className="flex-1 p-4 md:p-8 max-w-7xl w-full mx-auto animate-fadeIn">
            <Outlet />
          </div>
          <Footer />
        </main>
      </div>
    </div>
  );
};
