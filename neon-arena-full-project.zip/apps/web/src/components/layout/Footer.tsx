import React from 'react';
import { Link } from 'react-router-dom';
import { Zap, ShieldCheck, Heart, Terminal } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="w-full glass-panel border-t border-white/10 mt-20 py-10 px-6 md:px-12 text-slate-400">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
        {/* Brand */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-md bg-neon-cyan/20 border border-neon-cyan/40 flex items-center justify-center">
              <Zap className="w-4 h-4 text-neon-cyan" />
            </div>
            <span className="font-display font-black text-lg text-white">
              NEON<span className="text-neon-cyan">ARENA</span>
            </span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            The next-generation competitive arcade gaming platform. Play verified games, level up, and challenge players worldwide.
          </p>
          <div className="flex items-center gap-2 text-xs text-emerald-400 font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            All Arena Systems Operational
          </div>
        </div>

        {/* Arcade Games */}
        <div>
          <h4 className="text-xs font-bold text-white uppercase tracking-wider font-display mb-3">
            Arcade Games
          </h4>
          <ul className="space-y-2 text-xs">
            <li>
              <Link to="/games/tic-tac-toe" className="hover:text-neon-cyan transition-colors">
                Tic-Tac-Toe Neon (Multiplayer)
              </Link>
            </li>
            <li>
              <Link to="/games/snake" className="hover:text-neon-cyan transition-colors">
                Neon Snake
              </Link>
            </li>
            <li>
              <Link to="/games/2048" className="hover:text-neon-cyan transition-colors">
                Cyber 2048
              </Link>
            </li>
            <li>
              <Link to="/games/neon-flap" className="hover:text-neon-cyan transition-colors">
                Neon Cyber Flap
              </Link>
            </li>
            <li>
              <Link to="/games/cyber-slice" className="hover:text-neon-cyan transition-colors">
                Cyber Slice
              </Link>
            </li>
            <li>
              <Link to="/games/orbit-strike" className="hover:text-neon-cyan transition-colors">
                Orbit Strike (Physics)
              </Link>
            </li>
          </ul>
        </div>

        {/* Platform & Community */}
        <div>
          <h4 className="text-xs font-bold text-white uppercase tracking-wider font-display mb-3">
            Community & Ranked
          </h4>
          <ul className="space-y-2 text-xs">
            <li>
              <Link to="/multiplayer" className="hover:text-neon-cyan transition-colors">
                Multiplayer Matchmaking
              </Link>
            </li>
            <li>
              <Link to="/tournaments" className="hover:text-neon-cyan transition-colors">
                Seasonal Tournaments
              </Link>
            </li>
            <li>
              <Link to="/leaderboards" className="hover:text-neon-cyan transition-colors">
                Global Leaderboards
              </Link>
            </li>
            <li>
              <Link to="/quests" className="hover:text-neon-cyan transition-colors">
                Quests & XP Rewards
              </Link>
            </li>
            <li>
              <Link to="/friends" className="hover:text-neon-cyan transition-colors">
                Friends & Social
              </Link>
            </li>
          </ul>
        </div>

        {/* Security & Rules */}
        <div>
          <h4 className="text-xs font-bold text-white uppercase tracking-wider font-display mb-3">
            Fair Play & Integrity
          </h4>
          <p className="text-xs text-slate-400 mb-3 leading-relaxed">
            All match results, high scores, XP gains, and leaderboard standings are cryptographically verified by server-authoritative logic.
          </p>
          <div className="flex items-center gap-1.5 text-xs text-slate-300">
            <ShieldCheck className="w-4 h-4 text-neon-cyan" />
            <span>Anti-Tamper & Elo Verified</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between text-xs gap-3">
        <p>&copy; 2026 NEON ARENA. Built for ultimate competitive gaming.</p>
        <div className="flex items-center gap-4 text-slate-400">
          <span className="flex items-center gap-1">
            <Terminal className="w-3.5 h-3.5 text-neon-cyan" />
            TypeScript &bull; React &bull; Node &bull; Prisma &bull; Socket.IO
          </span>
        </div>
      </div>
    </footer>
  );
};
