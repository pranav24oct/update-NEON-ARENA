import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Zap,
  Search,
  Bell,
  Volume2,
  VolumeX,
  User,
  Shield,
  LogOut,
  Settings as SettingsIcon,
  Menu,
  X
} from 'lucide-react';
import { useAuthStore } from '../../stores/authStore.js';
import { useGameStore } from '../../stores/gameStore.js';
import { api } from '../../lib/api.js';
import { NeonButton } from '../ui/NeonButton.js';
import { Badge } from '../ui/Badge.js';

interface NavbarProps {
  onToggleSidebar?: () => void;
  isSidebarOpen?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleSidebar, isSidebarOpen }) => {
  const navigate = useNavigate();
  const { user, isAuthenticated, logout } = useAuthStore();
  const { isMuted, toggleSound } = useGameStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [unreadCount, setUnreadCount] = useState(0);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);

  useEffect(() => {
    if (isAuthenticated) {
      api.notifications
        .getAll()
        .then((res) => {
          setUnreadCount(res.unreadCount);
          setNotifications(res.notifications.slice(0, 5));
        })
        .catch(() => {});
    }
  }, [isAuthenticated]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/games?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full h-16 glass-panel border-b border-white/10 px-4 md:px-6 flex items-center justify-between">
      {/* Left: Mobile Menu Toggle & Brand */}
      <div className="flex items-center gap-3 md:gap-4">
        {onToggleSidebar && (
          <button
            onClick={onToggleSidebar}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors md:hidden"
            aria-label="Toggle Navigation"
          >
            {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        )}

        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-neon-cyan via-blue-600 to-neon-violet p-0.5 shadow-neon-cyan group-hover:shadow-[0_0_20px_rgba(0,240,255,0.8)] transition-all">
            <div className="w-full h-full bg-obsidian-950 rounded-[7px] flex items-center justify-center">
              <Zap className="w-5 h-5 text-neon-cyan fill-neon-cyan/20 animate-pulse" />
            </div>
          </div>
          <div className="flex flex-col">
            <span className="font-display font-black text-lg tracking-wider text-white flex items-center gap-1 leading-none">
              NEON<span className="text-neon-cyan text-glow-cyan">ARENA</span>
            </span>
            <span className="text-[10px] tracking-widest text-slate-400 uppercase font-semibold">
              Compete &bull; Ascend
            </span>
          </div>
        </Link>
      </div>

      {/* Middle: Quick Search */}
      <div className="hidden sm:flex flex-1 max-w-md mx-6">
        <form onSubmit={handleSearchSubmit} className="relative w-full">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search games, genres, players..."
            className="w-full pl-10 pr-4 py-1.5 bg-obsidian-900/80 border border-white/10 rounded-full text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-neon-cyan/50 focus:shadow-[0_0_15px_rgba(0,240,255,0.2)] transition-all"
          />
        </form>
      </div>

      {/* Right: Actions, Sound, Notifications, User */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* Sound Toggle */}
        <button
          onClick={toggleSound}
          title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
          className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
        >
          {isMuted ? (
            <VolumeX className="w-5 h-5 text-rose-400" />
          ) : (
            <Volume2 className="w-5 h-5 text-neon-cyan" />
          )}
        </button>

        {/* Notifications Dropdown */}
        {isAuthenticated && (
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
              title="Notifications"
            >
              <Bell className="w-5 h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-neon-magenta shadow-[0_0_8px_#f43f5e]" />
              )}
            </button>

            {showNotifications && (
              <div className="absolute right-0 mt-2 w-80 glass-panel border border-neon-cyan/30 rounded-xl shadow-2xl p-4 z-50 animate-scaleUp">
                <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
                  <span className="font-semibold text-sm text-white">Notifications</span>
                  <Link
                    to="/notifications"
                    onClick={() => setShowNotifications(false)}
                    className="text-xs text-neon-cyan hover:underline"
                  >
                    View All
                  </Link>
                </div>
                {notifications.length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-4">No notifications yet.</p>
                ) : (
                  <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                    {notifications.map((n) => (
                      <div
                        key={n.id}
                        className="p-2 rounded-lg bg-obsidian-900/60 border border-white/5 hover:border-neon-cyan/30 transition-colors"
                      >
                        <p className="text-xs font-semibold text-white">{n.title}</p>
                        <p className="text-[11px] text-slate-400 line-clamp-2 mt-0.5">{n.message}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* User Pill / Login */}
        {isAuthenticated && user ? (
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2.5 p-1 pl-2 pr-3 rounded-full bg-obsidian-900/80 border border-white/15 hover:border-neon-cyan/50 transition-all cursor-pointer"
            >
              <img
                src={
                  user.profile?.avatar ||
                  'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80'
                }
                alt={user.username}
                className="w-7 h-7 rounded-full object-cover border border-neon-cyan/40"
              />
              <div className="flex flex-col items-start text-left">
                <span className="text-xs font-bold text-slate-100 leading-tight">
                  {user.profile?.displayName || user.username}
                </span>
                <span className="text-[10px] text-neon-cyan font-semibold leading-none">
                  LVL {user.statistics?.level || 1}
                </span>
              </div>
            </button>

            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-52 glass-panel border border-neon-cyan/30 rounded-xl shadow-2xl p-2 z-50 animate-scaleUp">
                <div className="px-3 py-2 border-b border-white/10 mb-1">
                  <p className="text-xs font-semibold text-white truncate">{user.username}</p>
                  <p className="text-[11px] text-slate-400 truncate">{user.email}</p>
                  <div className="mt-1.5 flex items-center gap-1.5">
                    <Badge variant="cyan" size="sm">
                      Level {user.statistics?.level || 1}
                    </Badge>
                    {user.role === 'ADMIN' && (
                      <Badge variant="magenta" size="sm">
                        Admin
                      </Badge>
                    )}
                  </div>
                </div>

                <Link
                  to="/profile"
                  onClick={() => setShowUserMenu(false)}
                  className="flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
                >
                  <User className="w-4 h-4 text-neon-cyan" />
                  My Profile & Stats
                </Link>

                <Link
                  to="/settings"
                  onClick={() => setShowUserMenu(false)}
                  className="flex items-center gap-2 px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
                >
                  <SettingsIcon className="w-4 h-4 text-slate-400" />
                  Settings
                </Link>

                {user.role === 'ADMIN' && (
                  <Link
                    to="/admin"
                    onClick={() => setShowUserMenu(false)}
                    className="flex items-center gap-2 px-3 py-2 text-xs text-neon-magenta hover:bg-neon-magenta/10 rounded-lg transition-colors font-semibold"
                  >
                    <Shield className="w-4 h-4 text-neon-magenta" />
                    Admin Dashboard
                  </Link>
                )}

                <button
                  onClick={() => {
                    setShowUserMenu(false);
                    logout();
                  }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors mt-1"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <Link to="/login">
              <NeonButton variant="outline" size="sm">
                Sign In
              </NeonButton>
            </Link>
            <Link to="/register">
              <NeonButton variant="cyan" size="sm">
                Enter Arena
              </NeonButton>
            </Link>
          </div>
        )}
      </div>
    </header>
  );
};
