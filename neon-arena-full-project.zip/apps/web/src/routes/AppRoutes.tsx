import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from '../components/layout/Layout.js';

// Pages
import { HomePage } from '../pages/HomePage.js';
import { GameLibraryPage } from '../pages/GameLibraryPage.js';
import { GameDetailPage } from '../pages/GameDetailPage.js';
import { RecentlyPlayedPage } from '../pages/RecentlyPlayedPage.js';
import { FavoritesPage } from '../pages/FavoritesPage.js';
import { MultiplayerPage } from '../pages/MultiplayerPage.js';
import { ChallengesPage } from '../pages/ChallengesPage.js';
import { QuestsPage } from '../pages/QuestsPage.js';
import { LeaderboardsPage } from '../pages/LeaderboardsPage.js';
import { TournamentsPage } from '../pages/TournamentsPage.js';
import { FriendsPage } from '../pages/FriendsPage.js';
import { AchievementsPage } from '../pages/AchievementsPage.js';
import { ProfilePage } from '../pages/ProfilePage.js';
import { NotificationsPage } from '../pages/NotificationsPage.js';
import { SettingsPage } from '../pages/SettingsPage.js';
import { AdminPage } from '../pages/AdminPage.js';
import { LoginPage } from '../pages/LoginPage.js';
import { RegisterPage } from '../pages/RegisterPage.js';

export const AppRoutes: React.FC = () => {
  return (
    <Routes>
      <Route element={<Layout />}>
        {/* 15 Core Nav Pages */}
        <Route path="/" element={<HomePage />} />
        <Route path="/games" element={<GameLibraryPage />} />
        <Route path="/games/:slug" element={<GameDetailPage />} />
        <Route path="/recently-played" element={<RecentlyPlayedPage />} />
        <Route path="/favorites" element={<FavoritesPage />} />
        <Route path="/multiplayer" element={<MultiplayerPage />} />
        <Route path="/challenges" element={<ChallengesPage />} />
        <Route path="/quests" element={<QuestsPage />} />
        <Route path="/leaderboards" element={<LeaderboardsPage />} />
        <Route path="/tournaments" element={<TournamentsPage />} />
        <Route path="/friends" element={<FriendsPage />} />
        <Route path="/achievements" element={<AchievementsPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/players/:username" element={<ProfilePage />} />
        <Route path="/notifications" element={<NotificationsPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/admin" element={<AdminPage />} />

        {/* Auth routes */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />

        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
};
