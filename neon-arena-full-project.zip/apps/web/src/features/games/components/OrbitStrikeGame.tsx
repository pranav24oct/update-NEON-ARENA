import React, { useState, useEffect, useRef } from 'react';
import { Point, calculateTrajectory } from '@neon-arena/game-engine';
import { soundManager } from '../../../lib/audio.js';
import { api } from '../../../lib/api.js';
import { useAuthStore } from '../../../stores/authStore.js';
import { NeonButton } from '../../../components/ui/NeonButton.js';
import { Play, RotateCcw, Trophy, Target, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface TargetCore {
  x: number;
  y: number;
  radius: number;
  destroyed: boolean;
  color: string;
}

interface ObstacleBlock {
  x: number;
  y: number;
  width: number;
  height: number;
  hp: number;
  color: string;
}

interface Projectile {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  active: boolean;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  alpha: number;
  color: string;
}

interface OrbitStrikeGameProps {
  onScoreSaved?: () => void;
}

export const OrbitStrikeGame: React.FC<OrbitStrikeGameProps> = ({ onScoreSaved }) => {
  const { isAuthenticated, updateUserStats } = useAuthStore();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [level, setLevel] = useState<number>(1);
  const [shotsLeft, setShotsLeft] = useState<number>(4);
  const [score, setScore] = useState<number>(0);
  const [bestScore, setBestScore] = useState<number>(0);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [startTime, setStartTime] = useState<number>(Date.now());

  // Slingshot anchor
  const SLING_ORIGIN: Point = { x: 75, y: 320 };

  const isAimingRef = useRef<boolean>(false);
  const dragPointRef = useRef<Point>(SLING_ORIGIN);
  const projectileRef = useRef<Projectile | null>(null);
  const targetsRef = useRef<TargetCore[]>([]);
  const obstaclesRef = useRef<ObstacleBlock[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const animFrameRef = useRef<number>(0);

  const initSession = async () => {
    if (isAuthenticated) {
      try {
        const res = await api.games.startSession('orbit-strike');
        setSessionId(res.sessionId);
        setStartTime(Date.now());
      } catch (err) {
        console.error('Failed to start orbit-strike session:', err);
      }
    }
  };

  const setupLevel = (lvl: number) => {
    // Level layout
    if (lvl === 1) {
      targetsRef.current = [
        { x: 380, y: 310, radius: 18, destroyed: false, color: '#f43f5e' }
      ];
      obstaclesRef.current = [
        { x: 350, y: 270, width: 20, height: 90, hp: 2, color: '#9d4edd' },
        { x: 340, y: 250, width: 80, height: 20, hp: 2, color: '#00f0ff' }
      ];
    } else if (lvl === 2) {
      targetsRef.current = [
        { x: 360, y: 230, radius: 16, destroyed: false, color: '#f43f5e' },
        { x: 420, y: 320, radius: 18, destroyed: false, color: '#f43f5e' }
      ];
      obstaclesRef.current = [
        { x: 330, y: 260, width: 20, height: 100, hp: 2, color: '#9d4edd' },
        { x: 390, y: 260, width: 20, height: 100, hp: 2, color: '#9d4edd' },
        { x: 320, y: 240, width: 100, height: 20, hp: 3, color: '#00f0ff' }
      ];
    } else {
      targetsRef.current = [
        { x: 340, y: 190, radius: 16, destroyed: false, color: '#f43f5e' },
        { x: 410, y: 220, radius: 16, destroyed: false, color: '#f43f5e' },
        { x: 380, y: 320, radius: 18, destroyed: false, color: '#f43f5e' }
      ];
      obstaclesRef.current = [
        { x: 320, y: 230, width: 20, height: 130, hp: 3, color: '#9d4edd' },
        { x: 430, y: 230, width: 20, height: 130, hp: 3, color: '#9d4edd' },
        { x: 310, y: 210, width: 150, height: 20, hp: 3, color: '#00f0ff' }
      ];
    }
  };

  // Pointer drag for slingshot
  const handlePointerDown = (e: React.PointerEvent) => {
    if (!isPlaying || isGameOver || projectileRef.current?.active) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const px = (e.clientX - rect.left) * (canvas.width / rect.width);
    const py = (e.clientY - rect.top) * (canvas.height / rect.height);

    const dist = Math.hypot(px - SLING_ORIGIN.x, py - SLING_ORIGIN.y);
    if (dist < 45) {
      isAimingRef.current = true;
      dragPointRef.current = { x: px, y: py };
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isAimingRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const px = (e.clientX - rect.left) * (canvas.width / rect.width);
    const py = (e.clientY - rect.top) * (canvas.height / rect.height);

    // Limit maximum pull distance to 60px
    const dx = px - SLING_ORIGIN.x;
    const dy = py - SLING_ORIGIN.y;
    const angle = Math.atan2(dy, dx);
    const dist = Math.min(60, Math.hypot(dx, dy));

    dragPointRef.current = {
      x: SLING_ORIGIN.x + Math.cos(angle) * dist,
      y: SLING_ORIGIN.y + Math.sin(angle) * dist
    };
  };

  const handlePointerUp = () => {
    if (!isAimingRef.current) return;
    isAimingRef.current = false;

    // Launch projectile!
    const pullX = SLING_ORIGIN.x - dragPointRef.current.x;
    const pullY = SLING_ORIGIN.y - dragPointRef.current.y;
    const power = 0.22;

    projectileRef.current = {
      x: SLING_ORIGIN.x,
      y: SLING_ORIGIN.y,
      vx: pullX * power,
      vy: pullY * power,
      radius: 9,
      active: true
    };

    soundManager.playFlap();
    dragPointRef.current = SLING_ORIGIN;
    setShotsLeft((prev) => prev - 1);
  };

  // Main 60fps Loop
  useEffect(() => {
    if (!isPlaying || isGameOver) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const loop = () => {
      // 1. Update Projectile Physics
      const p = projectileRef.current;
      if (p && p.active) {
        p.vy += 0.35; // Gravity
        p.x += p.vx;
        p.y += p.vy;

        // Particle trail
        if (Math.random() < 0.6) {
          particlesRef.current.push({
            x: p.x,
            y: p.y,
            vx: (Math.random() - 0.5) * 2,
            vy: (Math.random() - 0.5) * 2,
            alpha: 1,
            color: '#00f0ff'
          });
        }

        // Collision with targets
        targetsRef.current.forEach((t) => {
          if (!t.destroyed) {
            const dist = Math.hypot(p.x - t.x, p.y - t.y);
            if (dist < p.radius + t.radius) {
              t.destroyed = true;
              soundManager.playVictory();
              setScore((s) => s + 250);
              createExplosion(t.x, t.y, t.color, 25);
            }
          }
        });

        // Collision with obstacles
        obstaclesRef.current.forEach((obs) => {
          if (obs.hp > 0) {
            const hitX = p.x + p.radius > obs.x && p.x - p.radius < obs.x + obs.width;
            const hitY = p.y + p.radius > obs.y && p.y - p.radius < obs.y + obs.height;
            if (hitX && hitY) {
              obs.hp -= 1;
              p.vx *= -0.5; // Bounce
              soundManager.playMove();
              setScore((s) => s + 40);
              createExplosion(p.x, p.y, obs.color, 8);
            }
          }
        });

        // Hit floor or offscreen
        if (p.y > 350 || p.x > canvas.width + 20) {
          p.active = false;
          checkLevelProgression();
        }
      }

      // Particle physics
      for (let i = particlesRef.current.length - 1; i >= 0; i--) {
        const part = particlesRef.current[i];
        part.x += part.vx;
        part.y += part.vy;
        part.alpha -= 0.03;
        if (part.alpha <= 0) particlesRef.current.splice(i, 1);
      }

      // 2. Render Canvas
      ctx.fillStyle = '#0a0b10';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Floor
      ctx.fillStyle = '#181b2a';
      ctx.fillRect(0, 350, canvas.width, canvas.height - 350);
      ctx.strokeStyle = '#00f0ff';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, 350);
      ctx.lineTo(canvas.width, 350);
      ctx.stroke();

      // Slingshot base
      ctx.strokeStyle = '#9d4edd';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(SLING_ORIGIN.x - 10, 350);
      ctx.lineTo(SLING_ORIGIN.x, SLING_ORIGIN.y);
      ctx.lineTo(SLING_ORIGIN.x + 10, 350);
      ctx.stroke();

      // Slingshot elastic band
      if (isAimingRef.current) {
        ctx.strokeStyle = '#00f0ff';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(SLING_ORIGIN.x, SLING_ORIGIN.y);
        ctx.lineTo(dragPointRef.current.x, dragPointRef.current.y);
        ctx.stroke();

        // Trajectory preview dots
        const trajectory = calculateTrajectory(SLING_ORIGIN, dragPointRef.current, 0.22, 25, 0.35);
        ctx.fillStyle = 'rgba(0, 240, 255, 0.6)';
        trajectory.forEach((pt, idx) => {
          if (idx % 2 === 0) {
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, 2.5, 0, Math.PI * 2);
            ctx.fill();
          }
        });
      }

      // Render Obstacles
      obstaclesRef.current.forEach((obs) => {
        if (obs.hp > 0) {
          ctx.save();
          ctx.shadowBlur = 10;
          ctx.shadowColor = obs.color;
          ctx.fillStyle = `${obs.color}33`;
          ctx.strokeStyle = obs.color;
          ctx.lineWidth = 2;
          ctx.fillRect(obs.x, obs.y, obs.width, obs.height);
          ctx.strokeRect(obs.x, obs.y, obs.width, obs.height);
          ctx.restore();
        }
      });

      // Render Targets
      targetsRef.current.forEach((t) => {
        if (!t.destroyed) {
          ctx.save();
          ctx.shadowBlur = 15;
          ctx.shadowColor = t.color;
          ctx.fillStyle = t.color;
          ctx.beginPath();
          ctx.arc(t.x, t.y, t.radius, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(t.x, t.y, t.radius * 0.45, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
      });

      // Render Projectile
      if (p && p.active) {
        ctx.save();
        ctx.shadowBlur = 15;
        ctx.shadowColor = '#00f0ff';
        ctx.fillStyle = '#00f0ff';
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // Render Particles
      particlesRef.current.forEach((part) => {
        ctx.save();
        ctx.globalAlpha = Math.max(0, part.alpha);
        ctx.fillStyle = part.color;
        ctx.beginPath();
        ctx.arc(part.x, part.y, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [isPlaying, isGameOver]);

  const createExplosion = (x: number, y: number, color: string, count: number) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 5 + 1;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        alpha: 1,
        color
      });
    }
  };

  const checkLevelProgression = () => {
    const allDestroyed = targetsRef.current.every((t) => t.destroyed);
    if (allDestroyed) {
      confetti({ particleCount: 75, spread: 60 });
      if (level < 3) {
        setLevel((l) => l + 1);
        setupLevel(level + 1);
        setShotsLeft((s) => s + 3);
      } else {
        // Game Completed!
        handleGameOver(score + 500);
      }
    } else if (shotsLeft <= 1) {
      // Out of shots!
      handleGameOver(score);
    }
  };

  const handleGameOver = async (finalScore: number) => {
    setIsGameOver(true);
    setIsPlaying(false);
    if (finalScore > bestScore) {
      setBestScore(finalScore);
    }

    if (isAuthenticated && sessionId) {
      const durationSeconds = Math.max(5, Math.floor((Date.now() - startTime) / 1000));
      try {
        const resp = await api.games.completeSession('orbit-strike', sessionId, {
          score: finalScore,
          durationSeconds
        });

        if (resp.progression) {
          updateUserStats(
            resp.progression.xpAwarded,
            resp.progression.newTotalXp,
            resp.progression.level
          );
        }

        if (onScoreSaved) onScoreSaved();
      } catch (err) {
        console.error('Failed to submit orbit-strike score:', err);
      }
    }
  };

  const startGame = () => {
    soundManager.playClick();
    setLevel(1);
    setScore(0);
    setShotsLeft(4);
    setupLevel(1);
    projectileRef.current = null;
    particlesRef.current = [];
    setIsGameOver(false);
    setIsPlaying(true);
    initSession();
  };

  return (
    <div className="flex flex-col items-center w-full max-w-lg mx-auto select-none">
      {/* Header Info */}
      <div className="flex items-center justify-between w-full mb-3 px-2">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="text-xs text-slate-400 uppercase font-semibold">Sector:</span>
            <span className="text-sm font-bold text-neon-cyan font-display">{level}/3</span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-xs text-slate-400 uppercase font-semibold">Shots:</span>
            <span className="text-sm font-bold text-neon-magenta font-display">{shotsLeft}</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-300 font-semibold">
          <Trophy className="w-4 h-4 text-neon-gold" />
          Score: <span className="text-neon-gold font-bold">{score}</span>
        </div>
      </div>

      {/* Physics Slingshot Canvas */}
      <div className="relative p-2 rounded-2xl glass-panel border border-neon-cyan/40 shadow-2xl cursor-grab active:cursor-grabbing overflow-hidden touch-none">
        <canvas
          ref={canvasRef}
          width={500}
          height={380}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="rounded-xl w-72 h-60 sm:w-112 sm:h-84 block"
        />

        {!isPlaying && (
          <div className="absolute inset-0 bg-obsidian-950/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-fadeIn rounded-2xl">
            {isGameOver ? (
              <>
                <p className="text-2xl font-black font-display text-neon-cyan mb-1">
                  MISSION COMPLETE
                </p>
                <p className="text-xs text-slate-400 mb-4">
                  Final Strike Score: <span className="text-white font-bold">{score}</span>
                </p>
                <NeonButton variant="cyan" size="md" onClick={startGame}>
                  <RotateCcw className="w-4 h-4" />
                  Try Again
                </NeonButton>
              </>
            ) : (
              <>
                <p className="text-xl font-black font-display text-white mb-2">ORBIT STRIKE</p>
                <p className="text-xs text-slate-400 max-w-xs mb-5">
                  Click and drag back on the slingshot orb to aim launch trajectory. Demolish target cores with minimum shots!
                </p>
                <NeonButton variant="cyan" size="lg" onClick={startGame}>
                  <Play className="w-5 h-5 fill-current" />
                  Launch Battery
                </NeonButton>
              </>
            )}
          </div>
        )}
      </div>

      <p className="text-xs text-slate-500 mt-4 text-center">
        Drag backward on the purple slingshot post to charge trajectory, release to fire.
      </p>
    </div>
  );
};
