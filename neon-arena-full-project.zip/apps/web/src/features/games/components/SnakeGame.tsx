import React, { useState, useEffect, useRef } from 'react';
import {
  SnakeState,
  createInitialSnakeState,
  stepSnake,
  SnakeDirection
} from '@neon-arena/game-engine';
import { soundManager } from '../../../lib/audio.js';
import { api } from '../../../lib/api.js';
import { useAuthStore } from '../../../stores/authStore.js';
import { NeonButton } from '../../../components/ui/NeonButton.js';
import { Play, Pause, RotateCcw, Trophy, ArrowUp, ArrowDown, ArrowLeft, ArrowRight } from 'lucide-react';
import confetti from 'canvas-confetti';

interface SnakeGameProps {
  onScoreSaved?: () => void;
}

export const SnakeGame: React.FC<SnakeGameProps> = ({ onScoreSaved }) => {
  const { isAuthenticated, updateUserStats } = useAuthStore();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [gameState, setGameState] = useState<SnakeState>(createInitialSnakeState(20));
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [highScore, setHighScore] = useState<number>(0);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [startTime, setStartTime] = useState<number>(Date.now());

  const stateRef = useRef(gameState);
  stateRef.current = gameState;

  // Start new backend session
  const initSession = async () => {
    if (isAuthenticated) {
      try {
        const res = await api.games.startSession('snake');
        setSessionId(res.sessionId);
        setStartTime(Date.now());
      } catch (err) {
        console.error('Failed to start snake session:', err);
      }
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isPlaying || isPaused || stateRef.current.isGameOver) return;

      let nextDir: SnakeDirection | null = null;
      const curDir = stateRef.current.direction;

      if ((e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') && curDir !== 'DOWN') {
        nextDir = 'UP';
      } else if ((e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') && curDir !== 'UP') {
        nextDir = 'DOWN';
      } else if ((e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') && curDir !== 'RIGHT') {
        nextDir = 'LEFT';
      } else if ((e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') && curDir !== 'LEFT') {
        nextDir = 'RIGHT';
      } else if (e.key === ' ') {
        e.preventDefault();
        setIsPaused((p) => !p);
        return;
      }

      if (nextDir) {
        e.preventDefault();
        setGameState((prev) => ({ ...prev, nextDirection: nextDir! }));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isPaused]);

  // Main game loop
  useEffect(() => {
    if (!isPlaying || isPaused || gameState.isGameOver) return;

    // Calculate speed based on score (starts at 120ms, caps at 60ms)
    const speed = Math.max(60, 120 - Math.floor(gameState.score / 30) * 8);

    const timer = setInterval(() => {
      setGameState((prev) => {
        const nextState = stepSnake(prev);

        if (nextState.score > prev.score) {
          soundManager.playScore();
        }

        if (nextState.isGameOver && !prev.isGameOver) {
          soundManager.playGameOver();
          handleGameOver(nextState.score);
        }

        return nextState;
      });
    }, speed);

    return () => clearInterval(timer);
  }, [isPlaying, isPaused, gameState.isGameOver, gameState.score]);

  // Render on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const gridSize = gameState.gridSize;
    const cellSize = canvas.width / gridSize;

    // Clear background
    ctx.fillStyle = '#0a0b10';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw subtle grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= gridSize; i++) {
      ctx.beginPath();
      ctx.moveTo(i * cellSize, 0);
      ctx.lineTo(i * cellSize, canvas.height);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, i * cellSize);
      ctx.lineTo(canvas.width, i * cellSize);
      ctx.stroke();
    }

    // Draw Neon Food
    const fx = gameState.food.x * cellSize + cellSize / 2;
    const fy = gameState.food.y * cellSize + cellSize / 2;
    const radius = cellSize * 0.38;

    ctx.save();
    ctx.shadowBlur = 15;
    ctx.shadowColor = '#00f0ff';
    ctx.fillStyle = '#00f0ff';
    ctx.beginPath();
    ctx.arc(fx, fy, radius, 0, Math.PI * 2);
    ctx.fill();

    // Inner bright core
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(fx, fy, radius * 0.45, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    // Draw Snake Segments
    gameState.snake.forEach((part, index) => {
      const px = part.x * cellSize;
      const py = part.y * cellSize;

      ctx.save();
      if (index === 0) {
        // Head
        ctx.shadowBlur = 12;
        ctx.shadowColor = '#00f0ff';
        ctx.fillStyle = '#00f0ff';
        ctx.fillRect(px + 1, py + 1, cellSize - 2, cellSize - 2);

        // Eye dots
        ctx.fillStyle = '#0a0b10';
        ctx.fillRect(px + 3, py + 3, 3, 3);
        ctx.fillRect(px + cellSize - 6, py + 3, 3, 3);
      } else {
        // Body with gradient from cyan to violet
        const alpha = Math.max(0.35, 1 - index / gameState.snake.length);
        ctx.fillStyle = index % 2 === 0 ? `rgba(0, 240, 255, ${alpha})` : `rgba(157, 78, 221, ${alpha})`;
        ctx.fillRect(px + 2, py + 2, cellSize - 4, cellSize - 4);
      }
      ctx.restore();
    });
  }, [gameState]);

  const handleGameOver = async (finalScore: number) => {
    setIsPlaying(false);
    if (finalScore > highScore) {
      setHighScore(finalScore);
      confetti({ particleCount: 60, spread: 50 });
    }

    if (isAuthenticated && sessionId) {
      const durationSeconds = Math.max(5, Math.floor((Date.now() - startTime) / 1000));
      try {
        const resp = await api.games.completeSession('snake', sessionId, {
          score: finalScore,
          durationSeconds
        });

        if (resp.progression) {
          updateUserStats(
            resp.progression.xpAwarded,
            resp.progression.newTotalXp,
            resp.progression.level
          );
        }

        if (onScoreSaved) onScoreSaved();
      } catch (err) {
        console.error('Failed to submit snake score:', err);
      }
    }
  };

  const startGame = () => {
    soundManager.playClick();
    setGameState(createInitialSnakeState(20));
    setIsPlaying(true);
    setIsPaused(false);
    initSession();
  };

  const handleDpad = (dir: SnakeDirection) => {
    if (!isPlaying || isPaused) return;
    const curDir = stateRef.current.direction;
    if (dir === 'UP' && curDir !== 'DOWN') setGameState((p) => ({ ...p, nextDirection: 'UP' }));
    if (dir === 'DOWN' && curDir !== 'UP') setGameState((p) => ({ ...p, nextDirection: 'DOWN' }));
    if (dir === 'LEFT' && curDir !== 'RIGHT') setGameState((p) => ({ ...p, nextDirection: 'LEFT' }));
    if (dir === 'RIGHT' && curDir !== 'LEFT') setGameState((p) => ({ ...p, nextDirection: 'RIGHT' }));
  };

  return (
    <div className="flex flex-col items-center w-full max-w-lg mx-auto">
      {/* Score Header */}
      <div className="flex items-center justify-between w-full mb-3 px-2">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 uppercase font-semibold">Score:</span>
          <span className="text-xl font-black font-display text-neon-cyan text-glow-cyan">
            {gameState.score}
          </span>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-300 font-semibold">
          <Trophy className="w-4 h-4 text-neon-gold" />
          Best: <span className="text-neon-gold font-bold">{highScore}</span>
        </div>
      </div>

      {/* Canvas Screen */}
      <div className="relative p-2 rounded-2xl glass-panel border border-neon-cyan/30 shadow-2xl overflow-hidden">
        <canvas
          ref={canvasRef}
          width={400}
          height={400}
          className="rounded-xl w-72 h-72 sm:w-96 sm:h-96 block"
        />

        {/* Overlay when game over or not started */}
        {!isPlaying && (
          <div className="absolute inset-0 bg-obsidian-950/85 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center animate-fadeIn">
            {gameState.isGameOver ? (
              <>
                <p className="text-2xl font-black font-display text-rose-500 mb-1">RUN TERMINATED</p>
                <p className="text-xs text-slate-400 mb-4">
                  Final Energy Core: <span className="text-white font-bold">{gameState.score}</span>
                </p>
                <NeonButton variant="cyan" size="md" onClick={startGame}>
                  <RotateCcw className="w-4 h-4" />
                  Try Again
                </NeonButton>
              </>
            ) : (
              <>
                <p className="text-xl font-black font-display text-white mb-2">NEON SERPENT</p>
                <p className="text-xs text-slate-400 max-w-xs mb-5">
                  Consume glowing energy cores to accelerate speed. Avoid crashing into boundaries and yourself.
                </p>
                <NeonButton variant="cyan" size="lg" onClick={startGame}>
                  <Play className="w-5 h-5 fill-current" />
                  Launch Game
                </NeonButton>
              </>
            )}
          </div>
        )}

        {isPaused && isPlaying && (
          <div className="absolute inset-0 bg-obsidian-950/70 backdrop-blur-sm flex items-center justify-center">
            <p className="text-lg font-bold font-display text-neon-cyan animate-pulse">GAME PAUSED</p>
          </div>
        )}
      </div>

      {/* Control Buttons & Mobile D-Pad */}
      <div className="mt-4 flex flex-col items-center gap-3 w-full">
        {isPlaying && (
          <div className="flex items-center gap-2">
            <NeonButton
              variant="outline"
              size="sm"
              onClick={() => {
                soundManager.playClick();
                setIsPaused(!isPaused);
              }}
            >
              {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
              {isPaused ? 'Resume' : 'Pause'}
            </NeonButton>
            <NeonButton variant="ghost" size="sm" onClick={startGame}>
              <RotateCcw className="w-4 h-4" />
              Restart
            </NeonButton>
          </div>
        )}

        {/* Mobile Touch D-Pad */}
        <div className="grid grid-cols-3 gap-2 mt-2 sm:hidden">
          <div />
          <button
            onClick={() => handleDpad('UP')}
            className="p-3 rounded-lg bg-obsidian-900 border border-white/10 active:bg-neon-cyan/20 text-white flex items-center justify-center"
          >
            <ArrowUp className="w-5 h-5" />
          </button>
          <div />
          <button
            onClick={() => handleDpad('LEFT')}
            className="p-3 rounded-lg bg-obsidian-900 border border-white/10 active:bg-neon-cyan/20 text-white flex items-center justify-center"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => handleDpad('DOWN')}
            className="p-3 rounded-lg bg-obsidian-900 border border-white/10 active:bg-neon-cyan/20 text-white flex items-center justify-center"
          >
            <ArrowDown className="w-5 h-5" />
          </button>
          <button
            onClick={() => handleDpad('RIGHT')}
            className="p-3 rounded-lg bg-obsidian-900 border border-white/10 active:bg-neon-cyan/20 text-white flex items-center justify-center"
          >
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
