import React, { useState, useEffect } from 'react';
import {
  TTTBoard,
  checkTTTResult,
  getTTTMinimaxMove
} from '@neon-arena/game-engine';
import { soundManager } from '../../../lib/audio.js';
import { api } from '../../../lib/api.js';
import { getSocket } from '../../../lib/socket.js';
import { useAuthStore } from '../../../stores/authStore.js';
import { NeonButton } from '../../../components/ui/NeonButton.js';
import { Badge } from '../../../components/ui/Badge.js';
import { Trophy, RefreshCw, Bot, Users, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface TicTacToeGameProps {
  onScoreSaved?: () => void;
}

export const TicTacToeGame: React.FC<TicTacToeGameProps> = ({ onScoreSaved }) => {
  const { user, isAuthenticated, updateUserStats } = useAuthStore();
  const socket = getSocket();

  // Mode: 'SOLO' | 'MULTIPLAYER'
  const [mode, setMode] = useState<'SOLO' | 'MULTIPLAYER'>('SOLO');
  const [difficulty, setDifficulty] = useState<'EASY' | 'MEDIUM' | 'HARD'>('HARD');

  // Solo State
  const [board, setBoard] = useState<TTTBoard>(Array(9).fill(null));
  const [isPlayerTurn, setIsPlayerTurn] = useState<boolean>(true);
  const [winner, setWinner] = useState<'X' | 'O' | null>(null);
  const [isDraw, setIsDraw] = useState<boolean>(false);
  const [winningLine, setWinningLine] = useState<number[] | null>(null);
  const [soloWins, setSoloWins] = useState<number>(0);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [sessionStartTime, setSessionStartTime] = useState<number>(Date.now());

  // Multiplayer State
  const [roomId, setRoomId] = useState<string | null>(null);
  const [roomCode, setRoomCode] = useState<string | null>(null);
  const [myMarker, setMyMarker] = useState<'X' | 'O' | null>(null);
  const [currentTurn, setCurrentTurn] = useState<'X' | 'O'>('X');
  const [oppUsername, setOppUsername] = useState<string>('Searching...');
  const [mpStatus, setMpStatus] = useState<'IDLE' | 'SEARCHING' | 'PLAYING' | 'FINISHED'>('IDLE');
  const [rematchRequested, setRematchRequested] = useState<boolean>(false);

  // Initialize solo session
  useEffect(() => {
    if (isAuthenticated && mode === 'SOLO') {
      api.games.startSession('tic-tac-toe')
        .then((res) => {
          setCurrentSessionId(res.sessionId);
          setSessionStartTime(Date.now());
        })
        .catch(() => {});
    }
  }, [isAuthenticated, mode]);

  // Handle Multiplayer Socket Events
  useEffect(() => {
    if (mode !== 'MULTIPLAYER') return;

    socket.on('matchmaking:match_found', (data: any) => {
      setRoomId(data.roomId);
      setRoomCode(data.roomCode);
      setBoard(data.board);
      setCurrentTurn(data.currentTurn);
      setMpStatus('PLAYING');
      setWinner(null);
      setIsDraw(false);
      setWinningLine(null);

      const me = data.players.find((p: any) => p.userId === user?.id);
      const opp = data.players.find((p: any) => p.userId !== user?.id);

      if (me) setMyMarker(me.marker);
      if (opp) setOppUsername(opp.username);
    });

    socket.on('game:move_made', (data: any) => {
      setBoard(data.board);
      setCurrentTurn(data.currentTurn);
      soundManager.playMove();

      if (data.isGameOver) {
        setWinner(data.winner);
        setIsDraw(data.isDraw);
        setWinningLine(data.winningLine);
        setMpStatus('FINISHED');

        if (data.winner === myMarker) {
          soundManager.playVictory();
          confetti({ particleCount: 75, spread: 60, origin: { y: 0.6 } });
        } else if (data.winner) {
          soundManager.playGameOver();
        }
      }
    });

    socket.on('game:rematch_accepted', (data: any) => {
      setBoard(data.board);
      setCurrentTurn(data.currentTurn);
      setWinner(null);
      setIsDraw(false);
      setWinningLine(null);
      setMpStatus('PLAYING');
      setRematchRequested(false);
    });

    return () => {
      socket.off('matchmaking:match_found');
      socket.off('game:move_made');
      socket.off('game:rematch_accepted');
    };
  }, [mode, myMarker, user?.id]);

  // Solo move handler
  const handleSoloCellClick = async (index: number) => {
    if (board[index] !== null || !isPlayerTurn || winner || isDraw) return;

    soundManager.playMove();
    const newBoard = [...board];
    newBoard[index] = 'X';
    setBoard(newBoard);

    const result = checkTTTResult(newBoard);
    if (result.isGameOver) {
      handleGameOver(result, newBoard);
      return;
    }

    // AI's Turn
    setIsPlayerTurn(false);
    setTimeout(() => {
      const aiMove = getTTTMinimaxMove(newBoard, 'O', difficulty);
      if (aiMove !== -1) {
        newBoard[aiMove] = 'O';
        setBoard([...newBoard]);
        soundManager.playMove();

        const aiResult = checkTTTResult(newBoard);
        if (aiResult.isGameOver) {
          handleGameOver(aiResult, newBoard);
        } else {
          setIsPlayerTurn(true);
        }
      }
    }, 400);
  };

  const handleGameOver = async (result: any, finalBoard: TTTBoard) => {
    setWinner(result.winner);
    setIsDraw(result.isDraw);
    setWinningLine(result.winningLine);

    if (result.winner === 'X') {
      soundManager.playVictory();
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
      setSoloWins((prev) => prev + 1);
    } else if (result.winner === 'O') {
      soundManager.playGameOver();
    }

    // Save session score to backend
    if (isAuthenticated && currentSessionId) {
      const durationSeconds = Math.max(5, Math.floor((Date.now() - sessionStartTime) / 1000));
      const score = result.winner === 'X' ? 100 : result.isDraw ? 25 : 10;

      try {
        const resp = await api.games.completeSession('tic-tac-toe', currentSessionId, {
          score,
          durationSeconds,
          metadata: { board: finalBoard, difficulty }
        });

        if (resp.progression) {
          updateUserStats(
            resp.progression.xpAwarded,
            resp.progression.newTotalXp,
            resp.progression.level
          );
        }

        if (onScoreSaved) onScoreSaved();
      } catch (err) {
        console.error('Error recording match score:', err);
      }
    }
  };

  const resetSoloGame = () => {
    soundManager.playClick();
    setBoard(Array(9).fill(null));
    setIsPlayerTurn(true);
    setWinner(null);
    setIsDraw(false);
    setWinningLine(null);

    if (isAuthenticated) {
      api.games.startSession('tic-tac-toe')
        .then((res) => {
          setCurrentSessionId(res.sessionId);
          setSessionStartTime(Date.now());
        })
        .catch(() => {});
    }
  };

  // Multiplayer Actions
  const handleStartMatchmaking = () => {
    soundManager.playClick();
    setMpStatus('SEARCHING');
    socket.emit('matchmaking:join');
  };

  const handleCancelMatchmaking = () => {
    soundManager.playClick();
    setMpStatus('IDLE');
    socket.emit('matchmaking:leave');
  };

  const handleMultiplayerCellClick = (index: number) => {
    if (board[index] !== null || currentTurn !== myMarker || mpStatus !== 'PLAYING') return;
    socket.emit('game:make_move', { cellIndex: index });
  };

  const handleRequestRematch = () => {
    soundManager.playClick();
    setRematchRequested(true);
    socket.emit('game:request_rematch');
  };

  return (
    <div className="w-full max-w-xl mx-auto flex flex-col items-center">
      {/* Mode Selector Tabs */}
      <div className="flex items-center gap-2 p-1 rounded-xl bg-obsidian-900 border border-white/10 mb-6">
        <button
          onClick={() => {
            soundManager.playClick();
            setMode('SOLO');
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
            mode === 'SOLO'
              ? 'bg-neon-cyan text-obsidian-950 shadow-neon-cyan'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Bot className="w-4 h-4" />
          Solo vs AI
        </button>

        <button
          onClick={() => {
            soundManager.playClick();
            setMode('MULTIPLAYER');
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
            mode === 'MULTIPLAYER'
              ? 'bg-neon-violet text-white shadow-neon-violet'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Users className="w-4 h-4" />
          Online Ranked
        </button>
      </div>

      {/* Solo Options & Difficulty */}
      {mode === 'SOLO' && (
        <div className="flex items-center justify-between w-full mb-4 px-2">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Difficulty:</span>
            {(['EASY', 'MEDIUM', 'HARD'] as const).map((d) => (
              <button
                key={d}
                onClick={() => {
                  soundManager.playClick();
                  setDifficulty(d);
                  resetSoloGame();
                }}
                className={`text-[11px] font-bold px-2.5 py-1 rounded-md transition-colors ${
                  difficulty === d
                    ? 'bg-neon-cyan/20 text-neon-cyan border border-neon-cyan/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {d}
              </button>
            ))}
          </div>

          <div className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
            <Trophy className="w-3.5 h-3.5 text-neon-gold" />
            Wins: <span className="text-neon-gold font-bold">{soloWins}</span>
          </div>
        </div>
      )}

      {/* Multiplayer Status Banner */}
      {mode === 'MULTIPLAYER' && (
        <div className="w-full mb-4 px-2">
          {mpStatus === 'IDLE' && (
            <div className="p-4 rounded-xl bg-obsidian-900/80 border border-white/10 text-center space-y-3">
              <p className="text-sm font-semibold text-white">
                Queue up for real-time competitive matchmaking!
              </p>
              <NeonButton variant="violet" size="md" onClick={handleStartMatchmaking}>
                Find Ranked Match
              </NeonButton>
            </div>
          )}

          {mpStatus === 'SEARCHING' && (
            <div className="p-4 rounded-xl bg-obsidian-900/80 border border-neon-violet/40 text-center space-y-3 animate-pulse">
              <div className="flex items-center justify-center gap-2 text-neon-violet font-semibold text-sm">
                <RefreshCw className="w-4 h-4 animate-spin" />
                Scanning cyber arena for opponent...
              </div>
              <NeonButton variant="outline" size="sm" onClick={handleCancelMatchmaking}>
                Cancel Queue
              </NeonButton>
            </div>
          )}

          {mpStatus === 'PLAYING' && (
            <div className="flex items-center justify-between p-3 rounded-xl bg-obsidian-900/80 border border-white/10">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Playing vs</span>
                <span className="text-xs font-bold text-neon-violet">{oppUsername}</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant={myMarker === 'X' ? 'cyan' : 'violet'} size="sm">
                  You: {myMarker}
                </Badge>
                <span className="text-xs text-slate-400">
                  Turn:{' '}
                  <span className={`font-bold ${currentTurn === 'X' ? 'text-neon-cyan' : 'text-neon-violet'}`}>
                    {currentTurn} {currentTurn === myMarker ? '(Your Turn)' : ''}
                  </span>
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Game Board */}
      <div className="relative p-4 rounded-2xl glass-panel border border-white/10 shadow-2xl">
        <div className="grid grid-cols-3 gap-3 w-72 h-72 sm:w-84 sm:h-84">
          {board.map((cell, idx) => {
            const isWinningCell = winningLine?.includes(idx);
            return (
              <button
                key={idx}
                onClick={() =>
                  mode === 'SOLO' ? handleSoloCellClick(idx) : handleMultiplayerCellClick(idx)
                }
                disabled={
                  mode === 'SOLO'
                    ? !isPlayerTurn || cell !== null || !!winner || isDraw
                    : mpStatus !== 'PLAYING' || currentTurn !== myMarker || cell !== null
                }
                className={`relative flex items-center justify-center rounded-xl bg-obsidian-900/90 border transition-all duration-200 select-none text-4xl sm:text-5xl font-black font-display cursor-pointer hover:border-neon-cyan/50 active:scale-95 disabled:cursor-not-allowed ${
                  isWinningCell
                    ? cell === 'X'
                      ? 'border-neon-cyan bg-neon-cyan/20 shadow-neon-cyan'
                      : 'border-neon-violet bg-neon-violet/20 shadow-neon-violet'
                    : 'border-white/10 hover:bg-white/5'
                }`}
              >
                {cell === 'X' && (
                  <span className="text-neon-cyan text-glow-cyan animate-scaleUp">X</span>
                )}
                {cell === 'O' && (
                  <span className="text-neon-violet text-glow-violet animate-scaleUp">O</span>
                )}
              </button>
            );
          })}
        </div>

        {/* Turn Status Overlay (Solo) */}
        {mode === 'SOLO' && !winner && !isDraw && (
          <div className="mt-4 text-center">
            <span className="text-xs font-semibold text-slate-400">
              {isPlayerTurn ? (
                <span className="text-neon-cyan flex items-center justify-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-neon-cyan animate-ping" />
                  Your turn (X)
                </span>
              ) : (
                <span className="text-neon-violet">AI calculating (O)...</span>
              )}
            </span>
          </div>
        )}
      </div>

      {/* Game Outcome Modal / Actions */}
      {(winner || isDraw) && (
        <div className="mt-6 flex flex-col items-center gap-3 p-4 rounded-xl glass-panel border border-white/20 w-full animate-scaleUp text-center">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-neon-gold animate-bounce" />
            <span className="text-lg font-bold font-display text-white">
              {winner
                ? mode === 'SOLO'
                  ? winner === 'X'
                    ? 'Victory! You defeated the AI!'
                    : 'AI Outsmarted You!'
                  : winner === myMarker
                  ? 'Victory! You Won the Duel!'
                  : `${oppUsername} Won the Duel!`
                : 'Stalemate! Game Ended in a Draw!'}
            </span>
          </div>

          <div className="flex items-center gap-3 mt-1">
            {mode === 'SOLO' ? (
              <NeonButton variant="cyan" size="sm" onClick={resetSoloGame}>
                <RefreshCw className="w-4 h-4" />
                Play Again
              </NeonButton>
            ) : (
              <NeonButton
                variant="violet"
                size="sm"
                onClick={handleRequestRematch}
                disabled={rematchRequested}
              >
                <RefreshCw className="w-4 h-4" />
                {rematchRequested ? 'Rematch Requested...' : 'Request Rematch'}
              </NeonButton>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
