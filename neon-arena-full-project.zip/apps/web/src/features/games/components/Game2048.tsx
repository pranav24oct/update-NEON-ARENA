import React, { useState, useEffect, useRef } from 'react';
import {
  Board2048,
  createEmptyBoard2048,
  addRandomTile2048,
  move2048,
  isGameOver2048
} from '@neon-arena/game-engine';
import { soundManager } from '../../../lib/audio.js';
import { api } from '../../../lib/api.js';
import { useAuthStore } from '../../../stores/authStore.js';
import { NeonButton } from '../../../components/ui/NeonButton.js';
import { RotateCcw, Trophy, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface Game2048Props {
  onScoreSaved?: () => void;
}

export const Game2048: React.FC<Game2048Props> = ({ onScoreSaved }) => {
  const { isAuthenticated, updateUserStats } = useAuthStore();

  const [board, setBoard] = useState<Board2048>(() => {
    let b = createEmptyBoard2048(4);
    b = addRandomTile2048(b);
    return addRandomTile2048(b);
  });

  const [score, setScore] = useState<number>(0);
  const [bestScore, setBestScore] = useState<number>(0);
  const [gameOver, setGameOver] = useState<boolean>(false);
  const [hasWon2048, setHasWon2048] = useState<boolean>(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [startTime, setStartTime] = useState<number>(Date.now());

  const touchStartRef = useRef<{ x: number; y: number } | null>(null);

  // Initialize backend game session
  const initSession = async () => {
    if (isAuthenticated) {
      try {
        const res = await api.games.startSession('2048');
        setSessionId(res.sessionId);
        setStartTime(Date.now());
      } catch (err) {
        console.error('Failed to start 2048 session:', err);
      }
    }
  };

  useEffect(() => {
    initSession();
  }, [isAuthenticated]);

  // Handle movement
  const handleMove = (direction: 'LEFT' | 'RIGHT' | 'UP' | 'DOWN') => {
    if (gameOver) return;

    const result = move2048(board, direction);
    if (!result.moved) return;

    soundManager.playMove();

    // Add random new tile
    const newBoard = addRandomTile2048(result.board);
    const newScore = score + result.scoreGained;

    setBoard(newBoard);
    setScore(newScore);

    if (newScore > bestScore) {
      setBestScore(newScore);
    }

    if (result.scoreGained > 0) {
      soundManager.playScore();
    }

    // Check for 2048 tile reached
    if (!hasWon2048) {
      for (const row of newBoard) {
        if (row.includes(2048)) {
          setHasWon2048(true);
          soundManager.playVictory();
          confetti({ particleCount: 100, spread: 80 });
          break;
        }
      }
    }

    // Check game over
    if (isGameOver2048(newBoard)) {
      setGameOver(true);
      soundManager.playGameOver();
      finalizeGame(newScore);
    }
  };

  const finalizeGame = async (finalScore: number) => {
    if (isAuthenticated && sessionId) {
      const durationSeconds = Math.max(5, Math.floor((Date.now() - startTime) / 1000));
      try {
        const resp = await api.games.completeSession('2048', sessionId, {
          score: finalScore,
          durationSeconds
        });

        if (resp.progression) {
          updateUserStats(
            resp.progression.xpAwarded,
            resp.progression.newTotalXp,
            resp.progression.level
          );
        }

        if (onScoreSaved) onScoreSaved();
      } catch (err) {
        console.error('Failed to complete 2048 session:', err);
      }
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameOver) return;
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        e.preventDefault();
        handleMove('LEFT');
      } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        e.preventDefault();
        handleMove('RIGHT');
      } else if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
        e.preventDefault();
        handleMove('UP');
      } else if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') {
        e.preventDefault();
        handleMove('DOWN');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [board, score, gameOver]);

  // Touch Swipe navigation
  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    touchStartRef.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartRef.current) return;
    const touch = e.changedTouches[0];
    const dx = touch.clientX - touchStartRef.current.x;
    const dy = touch.clientY - touchStartRef.current.y;
    touchStartRef.current = null;

    if (Math.abs(dx) > Math.abs(dy)) {
      if (Math.abs(dx) > 30) {
        handleMove(dx > 0 ? 'RIGHT' : 'LEFT');
      }
    } else {
      if (Math.abs(dy) > 30) {
        handleMove(dy > 0 ? 'DOWN' : 'UP');
      }
    }
  };

  const resetGame = () => {
    soundManager.playClick();
    let b = createEmptyBoard2048(4);
    b = addRandomTile2048(b);
    b = addRandomTile2048(b);
    setBoard(b);
    setScore(0);
    setGameOver(false);
    setHasWon2048(false);
    initSession();
  };

  // Styling helper for tile numbers
  const getTileStyles = (val: number) => {
    if (val === 0) return 'bg-obsidian-900/60 border-white/5 text-transparent';
    if (val === 2) return 'bg-neon-cyan/15 border-neon-cyan/40 text-neon-cyan shadow-[0_0_10px_rgba(0,240,255,0.2)]';
    if (val === 4) return 'bg-neon-cyan/30 border-neon-cyan/60 text-neon-cyan shadow-[0_0_15px_rgba(0,240,255,0.35)]';
    if (val === 8) return 'bg-neon-violet/25 border-neon-violet/40 text-neon-violet shadow-[0_0_12px_rgba(157,78,221,0.3)]';
    if (val === 16) return 'bg-neon-violet/45 border-neon-violet/70 text-white shadow-[0_0_18px_rgba(157,78,221,0.5)]';
    if (val === 32) return 'bg-neon-magenta/30 border-neon-magenta/50 text-neon-magenta shadow-[0_0_15px_rgba(244,63,94,0.35)]';
    if (val === 64) return 'bg-neon-magenta/60 border-neon-magenta text-white shadow-[0_0_20px_rgba(244,63,94,0.6)]';
    if (val === 128) return 'bg-blue-600/50 border-blue-400 text-white shadow-[0_0_20px_rgba(59,130,246,0.6)]';
    if (val === 256) return 'bg-neon-emerald/50 border-neon-emerald text-white shadow-[0_0_20px_rgba(16,185,129,0.6)]';
    if (val === 512) return 'bg-neon-gold/50 border-neon-gold text-white shadow-[0_0_25px_rgba(251,191,36,0.7)]';
    if (val === 1024) return 'bg-neon-gold/80 border-white text-obsidian-950 font-black shadow-[0_0_30px_rgba(251,191,36,0.9)]';
    return 'bg-gradient-to-r from-neon-cyan via-neon-violet to-neon-magenta text-white font-black shadow-[0_0_35px_rgba(0,240,255,1)] animate-pulse';
  };

  return (
    <div className="flex flex-col items-center w-full max-w-md mx-auto select-none">
      {/* Header Info */}
      <div className="flex items-center justify-between w-full mb-4 px-2">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-obsidian-900 border border-white/10 text-center min-w-[80px]">
            <p className="text-[10px] text-slate-400 font-bold uppercase">SCORE</p>
            <p className="text-base font-black font-display text-neon-cyan text-glow-cyan">{score}</p>
          </div>

          <div className="p-2 rounded-xl bg-obsidian-900 border border-white/10 text-center min-w-[80px]">
            <p className="text-[10px] text-slate-400 font-bold uppercase">BEST</p>
            <p className="text-base font-black font-display text-neon-gold flex items-center justify-center gap-1">
              <Trophy className="w-3.5 h-3.5" />
              {bestScore}
            </p>
          </div>
        </div>

        <NeonButton variant="outline" size="sm" onClick={resetGame}>
          <RotateCcw className="w-4 h-4" />
          Reset
        </NeonButton>
      </div>

      {/* 4x4 Grid Container */}
      <div
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
        className="relative p-3 rounded-2xl glass-panel border border-neon-violet/30 shadow-2xl"
      >
        <div className="grid grid-cols-4 gap-2.5 w-72 h-72 sm:w-88 sm:h-88">
          {board.map((row, rIdx) =>
            row.map((cell, cIdx) => (
              <div
                key={`${rIdx}-${cIdx}`}
                className={`flex items-center justify-center rounded-xl border font-display font-black text-xl sm:text-2xl transition-all duration-150 ${getTileStyles(
                  cell
                )}`}
              >
                {cell !== 0 ? cell : ''}
              </div>
            ))
          )}
        </div>

        {/* Game Over Overlay */}
        {gameOver && (
          <div className="absolute inset-0 bg-obsidian-950/85 backdrop-blur-md rounded-2xl flex flex-col items-center justify-center p-6 text-center animate-fadeIn">
            <p className="text-2xl font-black font-display text-rose-500 mb-1">NO MORE MOVES</p>
            <p className="text-xs text-slate-400 mb-4">
              Final Energy Score: <span className="text-white font-bold">{score}</span>
            </p>
            <NeonButton variant="cyan" size="md" onClick={resetGame}>
              <RotateCcw className="w-4 h-4" />
              Play Again
            </NeonButton>
          </div>
        )}

        {hasWon2048 && !gameOver && (
          <div className="absolute top-2 right-2 flex items-center gap-1 bg-neon-gold/20 border border-neon-gold/50 px-2 py-0.5 rounded-full text-[11px] text-neon-gold font-bold">
            <Sparkles className="w-3 h-3" />
            2048 Core Synthesized!
          </div>
        )}
      </div>

      <p className="text-xs text-slate-500 mt-4 text-center">
        Use Arrow keys, WASD, or swipe to slide and fuse identical cyber tiles.
      </p>
    </div>
  );
};
