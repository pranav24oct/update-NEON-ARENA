import React, { useState, useEffect, useRef } from 'react';
import { FlapPipe, checkFlapCollision } from '@neon-arena/game-engine';
import { soundManager } from '../../../lib/audio.js';
import { api } from '../../../lib/api.js';
import { useAuthStore } from '../../../stores/authStore.js';
import { NeonButton } from '../../../components/ui/NeonButton.js';
import { Play, RotateCcw, Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';

interface NeonFlapGameProps {
  onScoreSaved?: () => void;
}

export const NeonFlapGame: React.FC<NeonFlapGameProps> = ({ onScoreSaved }) => {
  const { isAuthenticated, updateUserStats } = useAuthStore();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [bestScore, setBestScore] = useState<number>(0);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [startTime, setStartTime] = useState<number>(Date.now());

  // Physics State Refs (for smooth 60fps canvas loop)
  const droneYRef = useRef<number>(200);
  const velocityRef = useRef<number>(0);
  const pipesRef = useRef<FlapPipe[]>([]);
  const scoreRef = useRef<number>(0);
  const animFrameRef = useRef<number>(0);

  const DRONE_RADIUS = 12;
  const DRONE_X = 70;
  const PIPE_WIDTH = 45;
  const GRAVITY = 0.38;
  const JUMP_STRENGTH = -7.2;

  const initSession = async () => {
    if (isAuthenticated) {
      try {
        const res = await api.games.startSession('neon-flap');
        setSessionId(res.sessionId);
        setStartTime(Date.now());
      } catch (err) {
        console.error('Failed to start flappy session:', err);
      }
    }
  };

  const jump = () => {
    if (!isPlaying || isGameOver) return;
    velocityRef.current = JUMP_STRENGTH;
    soundManager.playFlap();
  };

  // Keyboard jump
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') {
        e.preventDefault();
        if (!isPlaying && !isGameOver) {
          startGame();
        } else {
          jump();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isGameOver]);

  // Main 60fps Animation Loop
  useEffect(() => {
    if (!isPlaying || isGameOver) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let pipeSpawnTimer = 0;

    const loop = () => {
      // 1. Update Physics
      velocityRef.current += GRAVITY;
      droneYRef.current += velocityRef.current;

      // Spawn pipes
      pipeSpawnTimer++;
      if (pipeSpawnTimer > 90) {
        pipeSpawnTimer = 0;
        const gapHeight = 110;
        const minGapY = 50;
        const maxGapY = canvas.height - gapHeight - 50;
        const gapY = Math.floor(Math.random() * (maxGapY - minGapY)) + minGapY;

        pipesRef.current.push({
          x: canvas.width,
          gapY,
          gapHeight,
          passed: false
        });
      }

      // Move pipes & check score
      for (let i = pipesRef.current.length - 1; i >= 0; i--) {
        const pipe = pipesRef.current[i];
        pipe.x -= 2.5;

        // Passed pipe
        if (!pipe.passed && pipe.x + PIPE_WIDTH < DRONE_X) {
          pipe.passed = true;
          scoreRef.current += 1;
          setScore(scoreRef.current);
          soundManager.playScore();
        }

        // Remove offscreen pipes
        if (pipe.x + PIPE_WIDTH < 0) {
          pipesRef.current.splice(i, 1);
        }
      }

      // 2. Collision Check
      const hasCollided = checkFlapCollision(
        droneYRef.current,
        DRONE_RADIUS,
        DRONE_X,
        pipesRef.current,
        PIPE_WIDTH,
        canvas.height
      );

      if (hasCollided) {
        soundManager.playGameOver();
        handleCrash(scoreRef.current);
        return;
      }

      // 3. Render Canvas
      ctx.fillStyle = '#0a0b10';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Subtle background grid
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
      ctx.lineWidth = 1;
      for (let x = 0; x < canvas.width; x += 30) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }

      // Render Pipes (Electric Neon Pillars)
      pipesRef.current.forEach((pipe) => {
        ctx.save();
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#9d4edd';
        ctx.fillStyle = 'rgba(157, 78, 221, 0.25)';
        ctx.strokeStyle = '#9d4edd';
        ctx.lineWidth = 2;

        // Top barrier
        ctx.fillRect(pipe.x, 0, PIPE_WIDTH, pipe.gapY);
        ctx.strokeRect(pipe.x, 0, PIPE_WIDTH, pipe.gapY);

        // Bottom barrier
        const bottomTop = pipe.gapY + pipe.gapHeight;
        const bottomHeight = canvas.height - bottomTop;
        ctx.fillRect(pipe.x, bottomTop, PIPE_WIDTH, bottomHeight);
        ctx.strokeRect(pipe.x, bottomTop, PIPE_WIDTH, bottomHeight);

        // Electric gap glow particles
        ctx.strokeStyle = '#00f0ff';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(pipe.x + PIPE_WIDTH / 2, pipe.gapY);
        ctx.lineTo(pipe.x + PIPE_WIDTH / 2, bottomTop);
        ctx.stroke();

        ctx.restore();
      });

      // Render Drone
      ctx.save();
      ctx.shadowBlur = 15;
      ctx.shadowColor = '#00f0ff';
      ctx.fillStyle = '#00f0ff';
      ctx.beginPath();
      ctx.arc(DRONE_X, droneYRef.current, DRONE_RADIUS, 0, Math.PI * 2);
      ctx.fill();

      // Drone core
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(DRONE_X, droneYRef.current, DRONE_RADIUS * 0.45, 0, Math.PI * 2);
      ctx.fill();

      // Thruster tail flame
      if (velocityRef.current < 0) {
        ctx.fillStyle = '#f43f5e';
        ctx.beginPath();
        ctx.arc(DRONE_X - DRONE_RADIUS - 3, droneYRef.current, 4, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [isPlaying, isGameOver]);

  const handleCrash = async (finalScore: number) => {
    setIsGameOver(true);
    setIsPlaying(false);

    if (finalScore > bestScore) {
      setBestScore(finalScore);
      confetti({ particleCount: 70, spread: 60 });
    }

    if (isAuthenticated && sessionId) {
      const durationSeconds = Math.max(5, Math.floor((Date.now() - startTime) / 1000));
      try {
        const resp = await api.games.completeSession('neon-flap', sessionId, {
          score: finalScore * 10,
          durationSeconds
        });

        if (resp.progression) {
          updateUserStats(
            resp.progression.xpAwarded,
            resp.progression.newTotalXp,
            resp.progression.level
          );
        }

        if (onScoreSaved) onScoreSaved();
      } catch (err) {
        console.error('Failed to submit flap score:', err);
      }
    }
  };

  const startGame = () => {
    soundManager.playClick();
    droneYRef.current = 200;
    velocityRef.current = 0;
    pipesRef.current = [];
    scoreRef.current = 0;
    setScore(0);
    setIsGameOver(false);
    setIsPlaying(true);
    initSession();
  };

  return (
    <div className="flex flex-col items-center w-full max-w-lg mx-auto select-none">
      {/* Score Header */}
      <div className="flex items-center justify-between w-full mb-3 px-2">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 uppercase font-semibold">Gates Cleared:</span>
          <span className="text-xl font-black font-display text-neon-cyan text-glow-cyan">
            {score}
          </span>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-300 font-semibold">
          <Trophy className="w-4 h-4 text-neon-gold" />
          Best: <span className="text-neon-gold font-bold">{bestScore}</span>
        </div>
      </div>

      {/* Screen Canvas */}
      <div
        onClick={jump}
        className="relative p-2 rounded-2xl glass-panel border border-neon-cyan/40 shadow-2xl cursor-pointer"
      >
        <canvas
          ref={canvasRef}
          width={400}
          height={480}
          className="rounded-xl w-72 h-88 sm:w-96 sm:h-112 block"
        />

        {/* Start / Game Over Overlay */}
        {!isPlaying && (
          <div className="absolute inset-0 bg-obsidian-950/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-fadeIn rounded-2xl">
            {isGameOver ? (
              <>
                <p className="text-2xl font-black font-display text-rose-500 mb-1">DRONE DESTROYED</p>
                <p className="text-xs text-slate-400 mb-4">
                  Energy Gates Cleared: <span className="text-white font-bold">{score}</span>
                </p>
                <NeonButton variant="cyan" size="md" onClick={startGame}>
                  <RotateCcw className="w-4 h-4" />
                  Try Again
                </NeonButton>
              </>
            ) : (
              <>
                <p className="text-xl font-black font-display text-white mb-2">NEON CYBER FLAP</p>
                <p className="text-xs text-slate-400 max-w-xs mb-5">
                  Tap Spacebar or screen to fire thrusters. Clear narrow electric energy corridors without crashing.
                </p>
                <NeonButton variant="cyan" size="lg" onClick={startGame}>
                  <Play className="w-5 h-5 fill-current" />
                  Launch Flight
                </NeonButton>
              </>
            )}
          </div>
        )}
      </div>

      <p className="text-xs text-slate-500 mt-4 text-center">
        Press Spacebar or Click/Tap canvas to trigger impulse thrusters.
      </p>
    </div>
  );
};
