import React, { useState, useEffect, useRef } from 'react';
import { Point, lineIntersectsCircle } from '@neon-arena/game-engine';
import { soundManager } from '../../../lib/audio.js';
import { api } from '../../../lib/api.js';
import { useAuthStore } from '../../../stores/authStore.js';
import { NeonButton } from '../../../components/ui/NeonButton.js';
import { Play, RotateCcw, Trophy, Heart, Bomb } from 'lucide-react';
import confetti from 'canvas-confetti';

interface TargetItem {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  isBomb: boolean;
  isSliced: boolean;
  rotation: number;
  rotSpeed: number;
}

interface SlicedHalf {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  rotation: number;
  alpha: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  alpha: number;
  size: number;
}

interface CyberSliceGameProps {
  onScoreSaved?: () => void;
}

export const CyberSliceGame: React.FC<CyberSliceGameProps> = ({ onScoreSaved }) => {
  const { isAuthenticated, updateUserStats } = useAuthStore();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [score, setScore] = useState<number>(0);
  const [bestScore, setBestScore] = useState<number>(0);
  const [lives, setLives] = useState<number>(3);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [startTime, setStartTime] = useState<number>(Date.now());

  // Game loop state refs
  const targetsRef = useRef<TargetItem[]>([]);
  const halvesRef = useRef<SlicedHalf[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const trailRef = useRef<Point[]>([]);
  const isDraggingRef = useRef<boolean>(false);
  const scoreRef = useRef<number>(0);
  const livesRef = useRef<number>(3);
  const animFrameRef = useRef<number>(0);

  const GRAVITY = 0.28;

  const initSession = async () => {
    if (isAuthenticated) {
      try {
        const res = await api.games.startSession('cyber-slice');
        setSessionId(res.sessionId);
        setStartTime(Date.now());
      } catch (err) {
        console.error('Failed to start cyber-slice session:', err);
      }
    }
  };

  // Spawn random target
  const spawnTarget = (width: number, height: number) => {
    const isBomb = Math.random() < 0.22;
    const colors = ['#00f0ff', '#9d4edd', '#f43f5e', '#fbbf24', '#10b981'];
    const chosenColor = isBomb ? '#ef4444' : colors[Math.floor(Math.random() * colors.length)];

    const x = Math.random() * (width - 120) + 60;
    const y = height + 20;
    const vx = (Math.random() - 0.5) * 5;
    const vy = -(Math.random() * 4 + 11.5); // Upward impulse

    targetsRef.current.push({
      id: Date.now() + Math.random(),
      x,
      y,
      vx,
      vy,
      radius: isBomb ? 24 : 22,
      color: chosenColor,
      isBomb,
      isSliced: false,
      rotation: 0,
      rotSpeed: (Math.random() - 0.5) * 0.1
    });
  };

  // Mouse / Touch handlers for blade swipe
  const handlePointerDown = (e: React.PointerEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    isDraggingRef.current = true;
    trailRef.current = [
      {
        x: (e.clientX - rect.left) * (canvas.width / rect.width),
        y: (e.clientY - rect.top) * (canvas.height / rect.height)
      }
    ];
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDraggingRef.current) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const currentPoint: Point = {
      x: (e.clientX - rect.left) * (canvas.width / rect.width),
      y: (e.clientY - rect.top) * (canvas.height / rect.height)
    };

    const trail = trailRef.current;
    if (trail.length > 0) {
      const prevPoint = trail[trail.length - 1];

      // Check intersection with active targets
      let comboCount = 0;
      targetsRef.current.forEach((target) => {
        if (!target.isSliced) {
          const hit = lineIntersectsCircle(prevPoint, currentPoint, { x: target.x, y: target.y }, target.radius);
          if (hit) {
            target.isSliced = true;

            if (target.isBomb) {
              // Hit bomb! Deduct life
              soundManager.playGameOver();
              livesRef.current -= 1;
              setLives(livesRef.current);
              createExplosion(target.x, target.y, '#ef4444', 30);

              if (livesRef.current <= 0) {
                endGame(scoreRef.current);
              }
            } else {
              // Sliced Cyber Fruit
              soundManager.playSlice();
              comboCount++;
              createExplosion(target.x, target.y, target.color, 15);
              splitTarget(target);
            }
          }
        }
      });

      if (comboCount > 0) {
        const bonus = comboCount >= 3 ? comboCount * 25 : comboCount * 10;
        scoreRef.current += bonus;
        setScore(scoreRef.current);
      }
    }

    trail.push(currentPoint);
    if (trail.length > 10) trail.shift();
  };

  const handlePointerUp = () => {
    isDraggingRef.current = false;
    trailRef.current = [];
  };

  const splitTarget = (target: TargetItem) => {
    halvesRef.current.push(
      {
        x: target.x - 6,
        y: target.y,
        vx: target.vx - 3,
        vy: target.vy,
        radius: target.radius * 0.8,
        color: target.color,
        rotation: target.rotation,
        alpha: 1
      },
      {
        x: target.x + 6,
        y: target.y,
        vx: target.vx + 3,
        vy: target.vy,
        radius: target.radius * 0.8,
        color: target.color,
        rotation: target.rotation,
        alpha: 1
      }
    );
  };

  const createExplosion = (x: number, y: number, color: string, count: number) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 5 + 2;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color,
        alpha: 1,
        size: Math.random() * 3 + 2
      });
    }
  };

  // Main 60fps Loop
  useEffect(() => {
    if (!isPlaying || isGameOver) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let spawnTimer = 0;

    const loop = () => {
      // 1. Spawning
      spawnTimer++;
      if (spawnTimer > 55) {
        spawnTimer = 0;
        const countToSpawn = Math.random() < 0.35 ? 2 : 1;
        for (let i = 0; i < countToSpawn; i++) {
          spawnTarget(canvas.width, canvas.height);
        }
      }

      // 2. Physics & Item Update
      for (let i = targetsRef.current.length - 1; i >= 0; i--) {
        const item = targetsRef.current[i];
        item.x += item.vx;
        item.y += item.vy;
        item.vy += GRAVITY;
        item.rotation += item.rotSpeed;

        // Fallen offscreen without being sliced
        if (item.y > canvas.height + 40) {
          if (!item.isSliced && !item.isBomb) {
            livesRef.current -= 1;
            setLives(livesRef.current);
            if (livesRef.current <= 0) {
              soundManager.playGameOver();
              endGame(scoreRef.current);
              return;
            }
          }
          targetsRef.current.splice(i, 1);
        }
      }

      // Halves physics
      for (let i = halvesRef.current.length - 1; i >= 0; i--) {
        const half = halvesRef.current[i];
        half.x += half.vx;
        half.y += half.vy;
        half.vy += GRAVITY;
        half.alpha -= 0.015;
        if (half.y > canvas.height + 50 || half.alpha <= 0) {
          halvesRef.current.splice(i, 1);
        }
      }

      // Particles physics
      for (let i = particlesRef.current.length - 1; i >= 0; i--) {
        const p = particlesRef.current[i];
        p.x += p.vx;
        p.y += p.vy;
        p.alpha -= 0.03;
        if (p.alpha <= 0) {
          particlesRef.current.splice(i, 1);
        }
      }

      // 3. Canvas Rendering
      ctx.fillStyle = '#0a0b10';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Render Active Targets
      targetsRef.current.forEach((t) => {
        if (t.isSliced) return;
        ctx.save();
        ctx.translate(t.x, t.y);
        ctx.rotate(t.rotation);

        if (t.isBomb) {
          ctx.shadowBlur = 15;
          ctx.shadowColor = '#ef4444';
          ctx.fillStyle = '#ef4444';
          ctx.beginPath();
          ctx.arc(0, 0, t.radius, 0, Math.PI * 2);
          ctx.fill();

          // Skull core
          ctx.fillStyle = '#ffffff';
          ctx.font = '14px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('💣', 0, 0);
        } else {
          ctx.shadowBlur = 12;
          ctx.shadowColor = t.color;
          ctx.fillStyle = t.color;
          ctx.beginPath();
          ctx.arc(0, 0, t.radius, 0, Math.PI * 2);
          ctx.fill();

          // Inner geometric core
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(0, 0, t.radius * 0.45, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      });

      // Render Sliced Halves
      halvesRef.current.forEach((h) => {
        ctx.save();
        ctx.globalAlpha = Math.max(0, h.alpha);
        ctx.fillStyle = h.color;
        ctx.beginPath();
        ctx.arc(h.x, h.y, h.radius, 0, Math.PI);
        ctx.fill();
        ctx.restore();
      });

      // Render Particles
      particlesRef.current.forEach((p) => {
        ctx.save();
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Render Blade Swipe Trail
      if (trailRef.current.length > 1) {
        ctx.save();
        ctx.shadowBlur = 15;
        ctx.shadowColor = '#00f0ff';
        ctx.strokeStyle = '#00f0ff';
        ctx.lineWidth = 4;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';

        ctx.beginPath();
        ctx.moveTo(trailRef.current[0].x, trailRef.current[0].y);
        for (let i = 1; i < trailRef.current.length; i++) {
          ctx.lineTo(trailRef.current[i].x, trailRef.current[i].y);
        }
        ctx.stroke();
        ctx.restore();
      }

      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animFrameRef.current);
  }, [isPlaying, isGameOver]);

  const endGame = async (finalScore: number) => {
    setIsGameOver(true);
    setIsPlaying(false);

    if (finalScore > bestScore) {
      setBestScore(finalScore);
      confetti({ particleCount: 75, spread: 60 });
    }

    if (isAuthenticated && sessionId) {
      const durationSeconds = Math.max(5, Math.floor((Date.now() - startTime) / 1000));
      try {
        const resp = await api.games.completeSession('cyber-slice', sessionId, {
          score: finalScore,
          durationSeconds
        });

        if (resp.progression) {
          updateUserStats(
            resp.progression.xpAwarded,
            resp.progression.newTotalXp,
            resp.progression.level
          );
        }

        if (onScoreSaved) onScoreSaved();
      } catch (err) {
        console.error('Failed to submit slice score:', err);
      }
    }
  };

  const startGame = () => {
    soundManager.playClick();
    targetsRef.current = [];
    halvesRef.current = [];
    particlesRef.current = [];
    trailRef.current = [];
    scoreRef.current = 0;
    livesRef.current = 3;
    setScore(0);
    setLives(3);
    setIsGameOver(false);
    setIsPlaying(true);
    initSession();
  };

  return (
    <div className="flex flex-col items-center w-full max-w-lg mx-auto select-none">
      {/* Header Info */}
      <div className="flex items-center justify-between w-full mb-3 px-2">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 uppercase font-semibold">Slice Score:</span>
          <span className="text-xl font-black font-display text-neon-cyan text-glow-cyan">
            {score}
          </span>
        </div>

        {/* Lives Counter */}
        <div className="flex items-center gap-1.5">
          {Array(3)
            .fill(0)
            .map((_, idx) => (
              <Heart
                key={idx}
                className={`w-5 h-5 transition-colors ${
                  idx < lives ? 'text-neon-magenta fill-neon-magenta' : 'text-slate-700'
                }`}
              />
            ))}
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-300 font-semibold">
          <Trophy className="w-4 h-4 text-neon-gold" />
          Best: <span className="text-neon-gold font-bold">{bestScore}</span>
        </div>
      </div>

      {/* Interactive Blade Canvas */}
      <div className="relative p-2 rounded-2xl glass-panel border border-neon-magenta/40 shadow-2xl cursor-crosshair overflow-hidden touch-none">
        <canvas
          ref={canvasRef}
          width={450}
          height={480}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          className="rounded-xl w-72 h-88 sm:w-104 sm:h-112 block"
        />

        {/* Overlay */}
        {!isPlaying && (
          <div className="absolute inset-0 bg-obsidian-950/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-fadeIn rounded-2xl">
            {isGameOver ? (
              <>
                <p className="text-2xl font-black font-display text-rose-500 mb-1">ARENA OVER</p>
                <p className="text-xs text-slate-400 mb-4">
                  Final Slice Score: <span className="text-white font-bold">{score}</span>
                </p>
                <NeonButton variant="magenta" size="md" onClick={startGame}>
                  <RotateCcw className="w-4 h-4" />
                  Try Again
                </NeonButton>
              </>
            ) : (
              <>
                <p className="text-xl font-black font-display text-white mb-2">CYBER SLICE</p>
                <p className="text-xs text-slate-400 max-w-xs mb-5">
                  Drag your neon blade across launched cyber orbs to cleave them. Slice 3+ together for combos. Avoid red hazard bombs!
                </p>
                <NeonButton variant="magenta" size="lg" onClick={startGame}>
                  <Play className="w-5 h-5 fill-current" />
                  Start Slicing
                </NeonButton>
              </>
            )}
          </div>
        )}
      </div>

      <p className="text-xs text-slate-500 mt-4 text-center">
        Click & Drag or Swipe to draw your neon laser blade.
      </p>
    </div>
  );
};
