import { create } from 'zustand';
import { api } from '../lib/api.js';
import { refreshSocketAuth, disconnectSocket } from '../lib/socket.js';

interface User {
  id: string;
  username: string;
  email: string;
  role: 'PLAYER' | 'MODERATOR' | 'ADMIN';
  profile?: {
    displayName?: string;
    bio?: string;
    avatar?: string;
    country?: string;
    selectedTitle?: string;
    selectedFrame?: string;
  };
  statistics?: {
    totalXp: number;
    level: number;
    totalGamesPlayed: number;
    totalWins: number;
    totalLosses: number;
    currentStreak: number;
    bestStreak: number;
    multiplayerWins: number;
  };
}

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;

  login: (identifier: string, pass: string) => Promise<void>;
  register: (username: string, email: string, pass: string, avatar?: string) => Promise<void>;
  logout: () => Promise<void>;
  checkAuth: () => Promise<void>;
  setUser: (user: User | null) => void;
  updateUserStats: (xpAwarded: number, newTotalXp: number, level: number) => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  token: typeof localStorage !== 'undefined' ? localStorage.getItem('neon_access_token') : null,
  isAuthenticated: typeof localStorage !== 'undefined' ? !!localStorage.getItem('neon_access_token') : false,
  isLoading: true,
  error: null,

  login: async (identifier: string, pass: string) => {
    set({ isLoading: true, error: null });
    try {
      const data = await api.auth.login({ identifier, password: pass });
      localStorage.setItem('neon_access_token', data.accessToken);
      set({
        user: data.user,
        token: data.accessToken,
        isAuthenticated: true,
        isLoading: false
      });
      refreshSocketAuth();
    } catch (err: any) {
      set({ isLoading: false, error: err.message || 'Login failed' });
      throw err;
    }
  },

  register: async (username: string, email: string, pass: string, avatar?: string) => {
    set({ isLoading: true, error: null });
    try {
      const data = await api.auth.register({ username, email, password: pass, avatar });
      localStorage.setItem('neon_access_token', data.accessToken);
      set({
        user: data.user,
        token: data.accessToken,
        isAuthenticated: true,
        isLoading: false
      });
      refreshSocketAuth();
    } catch (err: any) {
      set({ isLoading: false, error: err.message || 'Registration failed' });
      throw err;
    }
  },

  logout: async () => {
    try {
      await api.auth.logout();
    } catch {
      // Ignore network errors on logout
    }
    localStorage.removeItem('neon_access_token');
    disconnectSocket();
    set({
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false,
      error: null
    });
  },

  checkAuth: async () => {
    const token = localStorage.getItem('neon_access_token');
    if (!token) {
      set({ user: null, isAuthenticated: false, isLoading: false });
      return;
    }

    try {
      const data = await api.auth.getMe();
      set({
        user: data.user,
        isAuthenticated: true,
        isLoading: false
      });
      refreshSocketAuth();
    } catch {
      localStorage.removeItem('neon_access_token');
      set({ user: null, isAuthenticated: false, isLoading: false });
    }
  },

  setUser: (user) => set({ user, isAuthenticated: !!user }),

  updateUserStats: (xpAwarded, newTotalXp, level) => {
    const current = get().user;
    if (!current) return;
    set({
      user: {
        ...current,
        statistics: {
          ...(current.statistics || {
            totalGamesPlayed: 0,
            totalWins: 0,
            totalLosses: 0,
            currentStreak: 0,
            bestStreak: 0,
            multiplayerWins: 0
          }),
          totalXp: newTotalXp,
          level
        }
      }
    });
  }
}));
