import { create } from 'zustand';
import { soundManager } from '../lib/audio.js';

interface GameStoreState {
  favorites: string[];
  recentlyPlayed: { slug: string; playedAt: string }[];
  isMuted: boolean;

  toggleFavorite: (slug: string) => void;
  isFavorite: (slug: string) => boolean;
  recordPlayed: (slug: string) => void;
  toggleSound: () => void;
}

export const useGameStore = create<GameStoreState>((set, get) => {
  const savedFavorites = JSON.parse(localStorage.getItem('neon_favorites') || '[]');
  const savedRecent = JSON.parse(localStorage.getItem('neon_recently_played') || '[]');

  return {
    favorites: savedFavorites,
    recentlyPlayed: savedRecent,
    isMuted: soundManager.isMuted(),

    toggleFavorite: (slug: string) => {
      const current = get().favorites;
      const updated = current.includes(slug)
        ? current.filter((s) => s !== slug)
        : [...current, slug];

      localStorage.setItem('neon_favorites', JSON.stringify(updated));
      set({ favorites: updated });
    },

    isFavorite: (slug: string) => get().favorites.includes(slug),

    recordPlayed: (slug: string) => {
      const current = get().recentlyPlayed.filter((item) => item.slug !== slug);
      const updated = [{ slug, playedAt: new Date().toISOString() }, ...current].slice(0, 10);

      localStorage.setItem('neon_recently_played', JSON.stringify(updated));
      set({ recentlyPlayed: updated });
    },

    toggleSound: () => {
      const newMuted = soundManager.toggleMute();
      set({ isMuted: newMuted });
    }
  };
});
