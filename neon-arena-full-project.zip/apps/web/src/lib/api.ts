// NEON ARENA - Frontend API Client

const BASE_URL = '/api/v1';

async function fetcher<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = localStorage.getItem('neon_access_token');

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(`${BASE_URL}${endpoint}`, {
    ...options,
    headers
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const errorMsg = data.error || data.message || `Request failed with status ${response.status}`;
    throw new Error(errorMsg);
  }

  return data as T;
}

export const api = {
  // Auth
  auth: {
    login: (body: any) => fetcher<any>('/auth/login', { method: 'POST', body: JSON.stringify(body) }),
    register: (body: any) => fetcher<any>('/auth/register', { method: 'POST', body: JSON.stringify(body) }),
    logout: () => fetcher<any>('/auth/logout', { method: 'POST' }),
    getMe: () => fetcher<{ user: any }>('/auth/me')
  },

  // Players
  players: {
    getProfile: (username: string) => fetcher<{ player: any }>(`/players/${username}`),
    updateMyProfile: (body: any) => fetcher<any>('/players/me', { method: 'PATCH', body: JSON.stringify(body) }),
    getStats: (username: string) => fetcher<any>(`/players/${username}/stats`)
  },

  // Games
  games: {
    getAll: (params?: Record<string, string>) => {
      const query = params ? `?${new URLSearchParams(params).toString()}` : '';
      return fetcher<{ games: any[] }>(`/games${query}`);
    },
    getBySlug: (slug: string) => fetcher<{ game: any }>(`/games/${slug}`),
    startSession: (slug: string) => fetcher<{ sessionId: string }>(`/games/${slug}/sessions`, { method: 'POST' }),
    completeSession: (slug: string, sessionId: string, body: any) =>
      fetcher<any>(`/games/${slug}/sessions/${sessionId}/complete`, { method: 'POST', body: JSON.stringify(body) })
  },

  // Quests
  quests: {
    getAll: () => fetcher<{ quests: any[] }>('/quests'),
    getMy: () => fetcher<{ quests: any[] }>('/quests/me'),
    claim: (questId: string) => fetcher<any>(`/quests/${questId}/claim`, { method: 'POST' })
  },

  // Challenges & Achievements
  challenges: {
    getDaily: () => fetcher<any>('/challenges/daily'),
    getAchievements: () => fetcher<{ achievements: any[] }>('/challenges/achievements')
  },

  // Leaderboards
  leaderboards: {
    getGlobal: (page = 1, limit = 20) => fetcher<any>(`/leaderboards/global?page=${page}&limit=${limit}`),
    getGame: (slug: string, page = 1, limit = 20) => fetcher<any>(`/leaderboards/games/${slug}?page=${page}&limit=${limit}`),
    getCompetitive: (page = 1, limit = 20) => fetcher<any>(`/leaderboards/competitive?page=${page}&limit=${limit}`),
    getFriends: () => fetcher<{ entries: any[] }>('/leaderboards/friends')
  },

  // Matches
  matches: {
    getHistory: (page = 1, limit = 15) => fetcher<any>(`/matches/history?page=${page}&limit=${limit}`),
    getDetails: (matchId: string) => fetcher<{ match: any }>(`/matches/${matchId}`)
  },

  // Tournaments
  tournaments: {
    getAll: () => fetcher<{ tournaments: any[] }>('/tournaments'),
    getById: (id: string) => fetcher<{ tournament: any }>(`/tournaments/${id}`),
    register: (id: string) => fetcher<any>(`/tournaments/${id}/register`, { method: 'POST' }),
    getBracket: (id: string) => fetcher<any>(`/tournaments/${id}/bracket`)
  },

  // Friends & Social
  friends: {
    getList: () => fetcher<any>('/friends'),
    sendRequest: (targetUsername: string) => fetcher<any>('/friends/request', { method: 'POST', body: JSON.stringify({ targetUsername }) }),
    respond: (requestId: string, action: 'ACCEPT' | 'DECLINE') => fetcher<any>('/friends/respond', { method: 'POST', body: JSON.stringify({ requestId, action }) }),
    remove: (friendshipId: string) => fetcher<any>(`/friends/${friendshipId}`, { method: 'DELETE' }),
    block: (targetUserId: string) => fetcher<any>('/friends/block', { method: 'POST', body: JSON.stringify({ targetUserId }) }),
    report: (body: any) => fetcher<any>('/friends/report', { method: 'POST', body: JSON.stringify(body) })
  },

  // Notifications
  notifications: {
    getAll: () => fetcher<{ unreadCount: number; notifications: any[] }>('/notifications'),
    markRead: (id: string) => fetcher<any>(`/notifications/${id}/read`, { method: 'PATCH' }),
    markAllRead: () => fetcher<any>('/notifications/read-all', { method: 'POST' })
  },

  // Admin
  admin: {
    getOverview: () => fetcher<any>('/admin/overview'),
    getUsers: (page = 1, limit = 20) => fetcher<any>(`/admin/users?page=${page}&limit=${limit}`),
    updateRole: (userId: string, role: string) => fetcher<any>('/admin/users/role', { method: 'PATCH', body: JSON.stringify({ userId, role }) }),
    banUser: (body: any) => fetcher<any>('/admin/users/ban', { method: 'POST', body: JSON.stringify(body) }),
    unbanUser: (userId: string) => fetcher<any>(`/admin/users/${userId}/unban`, { method: 'POST' }),
    getReports: () => fetcher<{ reports: any[] }>('/admin/reports'),
    resolveReport: (reportId: string, action: string) => fetcher<any>(`/admin/reports/${reportId}/resolve`, { method: 'PATCH', body: JSON.stringify({ action }) }),
    createTournament: (body: any) => fetcher<any>('/admin/tournaments', { method: 'POST', body: JSON.stringify(body) })
  }
};
