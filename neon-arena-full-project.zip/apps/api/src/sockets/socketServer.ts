import { Server as HttpServer } from 'http';
import { Server, Socket } from 'socket.io';
import jwt from 'jsonwebtoken';
import { ENV } from '../config/env.js';
import { prisma } from '../lib/prisma.js';
import { SOCKET_EVENTS, PresenceStatus, NotificationType, GameSlug } from '@neon-arena/shared';
import { gameRoomManager } from './gameRoomManager.js';

interface AuthenticatedSocket extends Socket {
  userId?: string;
  username?: string;
  rating?: number;
  avatar?: string;
}

interface QueueEntry {
  userId: string;
  username: string;
  rating: number;
  avatar?: string;
  socketId: string;
  joinedAt: number;
}

export function initSocketServer(httpServer: HttpServer): Server {
  const io = new Server(httpServer, {
    cors: {
      origin: [ENV.CLIENT_URL, 'http://localhost:5173', 'http://localhost:3000'],
      methods: ['GET', 'POST'],
      credentials: true
    }
  });

  // Track connected users: userId -> Set of socketIds
  const connectedUsers: Map<string, Set<string>> = new Map();
  // Matchmaking Queue
  const matchmakingQueue: QueueEntry[] = [];

  // Middleware: Authentication
  io.use(async (socket: AuthenticatedSocket, next) => {
    try {
      const token =
        socket.handshake.auth?.token ||
        socket.handshake.headers?.authorization?.replace('Bearer ', '');

      if (!token) {
        // Allow anonymous sockets to view public rooms if needed, or require auth for multiplayer
        return next();
      }

      const decoded = jwt.verify(token, ENV.JWT_ACCESS_SECRET) as {
        userId: string;
        username: string;
      };

      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        include: {
          profile: true,
          ratings: {
            where: { game: { slug: GameSlug.TIC_TAC_TOE } }
          }
        }
      });

      if (user && !user.isBanned) {
        socket.userId = user.id;
        socket.username = user.username;
        socket.avatar = user.profile?.avatar;
        socket.rating = user.ratings[0]?.rating || 1200;
      }

      next();
    } catch {
      next(); // Proceed as guest or unauthenticated
    }
  });

  io.on('connection', (socket: AuthenticatedSocket) => {
    // Register online presence
    if (socket.userId) {
      if (!connectedUsers.has(socket.userId)) {
        connectedUsers.set(socket.userId, new Set());
      }
      connectedUsers.get(socket.userId)!.add(socket.id);

      io.emit(SOCKET_EVENTS.PRESENCE_UPDATE, {
        userId: socket.userId,
        status: PresenceStatus.ONLINE
      });
    }

    // -------------------------------------------------------------------------
    // 1. MATCHMAKING QUEUE (QUICK MATCH)
    // -------------------------------------------------------------------------
    socket.on(SOCKET_EVENTS.JOIN_QUEUE, async () => {
      if (!socket.userId || !socket.username) {
        socket.emit('error', { message: 'Must be authenticated to join matchmaking queue.' });
        return;
      }

      // Check if already in queue
      const existingIdx = matchmakingQueue.findIndex((q) => q.userId === socket.userId);
      if (existingIdx !== -1) {
        matchmakingQueue.splice(existingIdx, 1);
      }

      const entry: QueueEntry = {
        userId: socket.userId,
        username: socket.username,
        rating: socket.rating || 1200,
        avatar: socket.avatar,
        socketId: socket.id,
        joinedAt: Date.now()
      };

      // Check if there is an opponent in queue
      if (matchmakingQueue.length > 0) {
        const opponent = matchmakingQueue.shift()!;

        // Don't match with self
        if (opponent.userId === socket.userId) {
          matchmakingQueue.push(entry);
          socket.emit(SOCKET_EVENTS.QUEUE_STATUS, { inQueue: true, queueSize: matchmakingQueue.length });
          return;
        }

        // Create match room
        const room = gameRoomManager.createRoom(
          {
            userId: opponent.userId,
            username: opponent.username,
            socketId: opponent.socketId,
            avatar: opponent.avatar,
            rating: opponent.rating
          },
          false
        );

        // Join second player
        await gameRoomManager.joinRoom(room.roomId, {
          userId: entry.userId,
          username: entry.username,
          socketId: entry.socketId,
          avatar: entry.avatar,
          rating: entry.rating
        });

        // Join socket rooms
        io.sockets.sockets.get(opponent.socketId)?.join(room.roomId);
        socket.join(room.roomId);

        // Notify both players
        io.to(room.roomId).emit(SOCKET_EVENTS.MATCH_FOUND, {
          roomCode: room.roomCode,
          roomId: room.roomId,
          players: room.players,
          board: room.board,
          currentTurn: room.currentTurn
        });
      } else {
        matchmakingQueue.push(entry);
        socket.emit(SOCKET_EVENTS.QUEUE_STATUS, { inQueue: true, queueSize: matchmakingQueue.length });
      }
    });

    socket.on(SOCKET_EVENTS.LEAVE_QUEUE, () => {
      const idx = matchmakingQueue.findIndex((q) => q.socketId === socket.id);
      if (idx !== -1) {
        matchmakingQueue.splice(idx, 1);
      }
      socket.emit(SOCKET_EVENTS.QUEUE_STATUS, { inQueue: false });
    });

    // -------------------------------------------------------------------------
    // 2. CUSTOM PRIVATE ROOMS
    // -------------------------------------------------------------------------
    socket.on(SOCKET_EVENTS.CREATE_ROOM, (data?: { isPrivate?: boolean }) => {
      if (!socket.userId || !socket.username) {
        socket.emit('error', { message: 'Must be authenticated to create a game room.' });
        return;
      }

      const room = gameRoomManager.createRoom(
        {
          userId: socket.userId,
          username: socket.username,
          socketId: socket.id,
          avatar: socket.avatar,
          rating: socket.rating || 1200
        },
        data?.isPrivate ?? true
      );

      socket.join(room.roomId);

      socket.emit(SOCKET_EVENTS.ROOM_DATA, {
        roomCode: room.roomCode,
        roomId: room.roomId,
        players: room.players,
        status: room.status,
        isHost: true
      });
    });

    socket.on(SOCKET_EVENTS.JOIN_ROOM, async ({ roomCode }: { roomCode: string }) => {
      if (!socket.userId || !socket.username) {
        socket.emit('error', { message: 'Must be authenticated to join room.' });
        return;
      }

      const result = await gameRoomManager.joinRoom(roomCode, {
        userId: socket.userId,
        username: socket.username,
        socketId: socket.id,
        avatar: socket.avatar,
        rating: socket.rating || 1200
      });

      if (result.error) {
        socket.emit('error', { message: result.error });
        return;
      }

      const room = result.room!;
      socket.join(room.roomId);

      // Broadcast room update to all in room
      io.to(room.roomId).emit(SOCKET_EVENTS.ROOM_DATA, {
        roomCode: room.roomCode,
        roomId: room.roomId,
        players: room.players,
        status: room.status,
        board: room.board,
        currentTurn: room.currentTurn
      });
    });

    // -------------------------------------------------------------------------
    // 3. GAMEPLAY EVENTS: TIC-TAC-TOE
    // -------------------------------------------------------------------------
    socket.on(SOCKET_EVENTS.MAKE_MOVE, async ({ cellIndex }: { cellIndex: number }) => {
      if (!socket.userId) return;

      const room = gameRoomManager.getRoomBySocketId(socket.id);
      if (!room) {
        socket.emit('error', { message: 'No active match found for this socket.' });
        return;
      }

      const moveResult = await gameRoomManager.makeMove(room.roomId, socket.userId, cellIndex);

      if (moveResult.error) {
        socket.emit('error', { message: moveResult.error });
        return;
      }

      // Broadcast updated board
      io.to(room.roomId).emit(SOCKET_EVENTS.MOVE_MADE, {
        cellIndex,
        board: room.board,
        currentTurn: room.currentTurn,
        winner: room.winner,
        winningLine: room.winningLine,
        isDraw: room.isDraw,
        isGameOver: moveResult.isGameOver
      });
    });

    socket.on(SOCKET_EVENTS.REQUEST_REMATCH, async () => {
      if (!socket.userId) return;

      const room = gameRoomManager.getRoomBySocketId(socket.id);
      if (!room) return;

      const result = await gameRoomManager.requestRematch(room.roomId, socket.userId);

      if (result.restarted) {
        io.to(room.roomId).emit(SOCKET_EVENTS.REMATCH_ACCEPTED, {
          players: room.players,
          board: room.board,
          currentTurn: room.currentTurn,
          status: room.status
        });
      } else {
        // Notify other player that a rematch was requested
        socket.to(room.roomId).emit('game:rematch_requested', {
          requestedBy: socket.username
        });
      }
    });

    // -------------------------------------------------------------------------
    // 4. CHAT & SOCIAL
    // -------------------------------------------------------------------------
    socket.on(SOCKET_EVENTS.SEND_CHAT_MESSAGE, ({ message, channel = 'global' }: { message: string; channel?: string }) => {
      if (!socket.username || !message.trim()) return;

      const chatPayload = {
        id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        sender: socket.username,
        avatar: socket.avatar,
        text: message.trim().slice(0, 200),
        channel,
        timestamp: new Date().toISOString()
      };

      if (channel.startsWith('room_')) {
        io.to(channel).emit(SOCKET_EVENTS.NEW_CHAT_MESSAGE, chatPayload);
      } else {
        io.emit(SOCKET_EVENTS.NEW_CHAT_MESSAGE, chatPayload);
      }
    });

    socket.on(SOCKET_EVENTS.SEND_INVITE, ({ targetUserId, roomCode }: { targetUserId: string; roomCode: string }) => {
      const targetSockets = connectedUsers.get(targetUserId);
      if (targetSockets) {
        targetSockets.forEach((sId) => {
          io.to(sId).emit(SOCKET_EVENTS.RECEIVE_INVITE, {
            fromUsername: socket.username,
            fromAvatar: socket.avatar,
            roomCode
          });
        });
      }
    });

    // -------------------------------------------------------------------------
    // 5. DISCONNECTION HANDLING
    // -------------------------------------------------------------------------
    socket.on(SOCKET_EVENTS.DISCONNECT, () => {
      // Remove from matchmaking queue
      const qIdx = matchmakingQueue.findIndex((q) => q.socketId === socket.id);
      if (qIdx !== -1) {
        matchmakingQueue.splice(qIdx, 1);
      }

      // Handle room leaving
      const leaveResult = gameRoomManager.leaveRoom(socket.id);
      if (leaveResult.room && leaveResult.remainingPlayerSocketId) {
        io.to(leaveResult.room.roomId).emit('room:player_left', {
          wasPlaying: leaveResult.wasPlaying,
          winner: leaveResult.room.winner,
          players: leaveResult.room.players
        });
      }

      // Update presence
      if (socket.userId && connectedUsers.has(socket.userId)) {
        const userSockets = connectedUsers.get(socket.userId)!;
        userSockets.delete(socket.id);
        if (userSockets.size === 0) {
          connectedUsers.delete(socket.userId);
          io.emit(SOCKET_EVENTS.PRESENCE_UPDATE, {
            userId: socket.userId,
            status: PresenceStatus.OFFLINE
          });
        }
      }
    });
  });

  return io;
}
