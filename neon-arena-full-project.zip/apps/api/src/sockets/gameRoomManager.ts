import { TTTBoard, checkTTTResult, TTTCell } from '@neon-arena/game-engine';
import { prisma } from '../lib/prisma.js';
import { calculateEloChange, getTierFromRating, GameSlug } from '@neon-arena/shared';
import { ProgressionService } from '../services/progressionService.js';

export interface RoomPlayer {
  userId: string;
  username: string;
  socketId: string;
  avatar?: string;
  marker?: 'X' | 'O';
  isReady: boolean;
  rating: number;
}

export interface GameRoom {
  roomId: string;
  roomCode: string;
  isPrivate: boolean;
  gameSlug: string;
  status: 'WAITING' | 'READY' | 'PLAYING' | 'FINISHED';
  players: RoomPlayer[];
  board: TTTBoard;
  currentTurn: 'X' | 'O';
  winner: 'X' | 'O' | null;
  winningLine: number[] | null;
  isDraw: boolean;
  matchDbId?: string;
  rematchVotes: Set<string>;
  createdAt: number;
}

export class GameRoomManager {
  private rooms: Map<string, GameRoom> = new Map();
  private userToRoom: Map<string, string> = new Map(); // socketId -> roomId

  createRoom(
    host: { userId: string; username: string; socketId: string; avatar?: string; rating: number },
    isPrivate: boolean = false,
    customCode?: string
  ): GameRoom {
    const roomCode = customCode || Math.random().toString(36).substring(2, 8).toUpperCase();
    const roomId = `room_${roomCode}`;

    const newRoom: GameRoom = {
      roomId,
      roomCode,
      isPrivate,
      gameSlug: GameSlug.TIC_TAC_TOE,
      status: 'WAITING',
      players: [
        {
          userId: host.userId,
          username: host.username,
          socketId: host.socketId,
          avatar: host.avatar,
          isReady: true,
          rating: host.rating
        }
      ],
      board: Array(9).fill(null),
      currentTurn: 'X',
      winner: null,
      winningLine: null,
      isDraw: false,
      rematchVotes: new Set(),
      createdAt: Date.now()
    };

    this.rooms.set(roomId, newRoom);
    this.userToRoom.set(host.socketId, roomId);
    return newRoom;
  }

  getRoom(roomIdOrCode: string): GameRoom | undefined {
    if (this.rooms.has(roomIdOrCode)) {
      return this.rooms.get(roomIdOrCode);
    }
    // Search by room code
    for (const room of this.rooms.values()) {
      if (room.roomCode.toUpperCase() === roomIdOrCode.toUpperCase()) {
        return room;
      }
    }
    return undefined;
  }

  getRoomBySocketId(socketId: string): GameRoom | undefined {
    const roomId = this.userToRoom.get(socketId);
    if (!roomId) return undefined;
    return this.rooms.get(roomId);
  }

  async joinRoom(
    roomIdOrCode: string,
    player: { userId: string; username: string; socketId: string; avatar?: string; rating: number }
  ): Promise<{ room?: GameRoom; error?: string }> {
    const room = this.getRoom(roomIdOrCode);
    if (!room) {
      return { error: 'Game room not found.' };
    }

    if (room.players.length >= 2) {
      // Check if this player is reconnecting
      const existing = room.players.find((p) => p.userId === player.userId);
      if (existing) {
        existing.socketId = player.socketId;
        this.userToRoom.set(player.socketId, room.roomId);
        return { room };
      }
      return { error: 'Game room is already full.' };
    }

    // Add 2nd player
    room.players.push({
      userId: player.userId,
      username: player.username,
      socketId: player.socketId,
      avatar: player.avatar,
      isReady: true,
      rating: player.rating
    });

    this.userToRoom.set(player.socketId, room.roomId);

    // If 2 players are in the room, start game!
    if (room.players.length === 2) {
      await this.startGame(room);
    }

    return { room };
  }

  async startGame(room: GameRoom): Promise<void> {
    room.status = 'PLAYING';
    room.board = Array(9).fill(null);
    room.winner = null;
    room.winningLine = null;
    room.isDraw = false;
    room.rematchVotes.clear();

    // Randomly assign 'X' and 'O'
    const xIndex = Math.random() < 0.5 ? 0 : 1;
    room.players[xIndex].marker = 'X';
    room.players[1 - xIndex].marker = 'O';
    room.currentTurn = 'X';

    // Persist Match in Prisma DB
    try {
      const tttGame = await prisma.game.findUnique({ where: { slug: GameSlug.TIC_TAC_TOE } });
      if (tttGame) {
        const dbMatch = await prisma.match.create({
          data: {
            gameId: tttGame.id,
            roomCode: room.roomCode,
            status: 'IN_PROGRESS',
            participants: {
              create: room.players.map((p) => ({
                userId: p.userId,
                roleMarker: p.marker,
                ratingBefore: p.rating,
                ratingAfter: p.rating
              }))
            }
          }
        });
        room.matchDbId = dbMatch.id;
      }
    } catch (e) {
      console.error('Error creating match record in DB:', e);
    }
  }

  async makeMove(
    roomId: string,
    userId: string,
    cellIndex: number
  ): Promise<{ room?: GameRoom; error?: string; isGameOver?: boolean }> {
    const room = this.rooms.get(roomId);
    if (!room) return { error: 'Room not found.' };

    if (room.status !== 'PLAYING') {
      return { error: 'Game is not currently active.' };
    }

    const player = room.players.find((p) => p.userId === userId);
    if (!player) return { error: 'You are not a player in this room.' };

    if (player.marker !== room.currentTurn) {
      return { error: 'It is not your turn.' };
    }

    if (cellIndex < 0 || cellIndex >= 9) {
      return { error: 'Invalid cell index.' };
    }

    if (room.board[cellIndex] !== null) {
      return { error: 'Cell is already occupied.' };
    }

    // Apply move
    room.board[cellIndex] = player.marker;

    // Check game outcome
    const outcome = checkTTTResult(room.board);

    if (outcome.isGameOver) {
      room.status = 'FINISHED';
      room.winner = outcome.winner;
      room.winningLine = outcome.winningLine;
      room.isDraw = outcome.isDraw;

      // Finalize match in database
      await this.finalizeMatch(room);

      return { room, isGameOver: true };
    } else {
      // Toggle turn
      room.currentTurn = room.currentTurn === 'X' ? 'O' : 'X';
      return { room, isGameOver: false };
    }
  }

  private async finalizeMatch(room: GameRoom): Promise<void> {
    if (!room.matchDbId) return;

    try {
      const playerX = room.players.find((p) => p.marker === 'X')!;
      const playerO = room.players.find((p) => p.marker === 'O')!;

      let outcomeX: 1 | 0.5 | 0 = 0.5;
      let outcomeO: 1 | 0.5 | 0 = 0.5;
      let winningUserId: string | null = null;

      if (room.winner === 'X') {
        outcomeX = 1;
        outcomeO = 0;
        winningUserId = playerX.userId;
      } else if (room.winner === 'O') {
        outcomeX = 0;
        outcomeO = 1;
        winningUserId = playerO.userId;
      }

      // Calculate Elo changes
      const eloX = calculateEloChange(playerX.rating, playerO.rating, outcomeX);
      const eloO = calculateEloChange(playerO.rating, playerX.rating, outcomeO);

      // Update Match in DB
      await prisma.match.update({
        where: { id: room.matchDbId },
        data: {
          status: room.isDraw ? 'DRAW' : 'COMPLETED',
          winnerId: winningUserId,
          endedAt: new Date(),
          metadata: JSON.stringify({ board: room.board, winningLine: room.winningLine })
        }
      });

      // Update MatchParticipant records
      await prisma.matchParticipant.update({
        where: { matchId_userId: { matchId: room.matchDbId, userId: playerX.userId } },
        data: {
          ratingAfter: eloX.newRating,
          ratingDelta: eloX.change,
          isWinner: winningUserId === playerX.userId
        }
      });

      await prisma.matchParticipant.update({
        where: { matchId_userId: { matchId: room.matchDbId, userId: playerO.userId } },
        data: {
          ratingAfter: eloO.newRating,
          ratingDelta: eloO.change,
          isWinner: winningUserId === playerO.userId
        }
      });

      // Update PlayerRatings & Tiers
      const tttGame = await prisma.game.findUnique({ where: { slug: GameSlug.TIC_TAC_TOE } });
      if (tttGame) {
        await prisma.playerRating.updateMany({
          where: { userId: playerX.userId, gameId: tttGame.id },
          data: {
            rating: eloX.newRating,
            tier: getTierFromRating(eloX.newRating),
            matchesCount: { increment: 1 }
          }
        });

        await prisma.playerRating.updateMany({
          where: { userId: playerO.userId, gameId: tttGame.id },
          data: {
            rating: eloO.newRating,
            tier: getTierFromRating(eloO.newRating),
            matchesCount: { increment: 1 }
          }
        });
      }

      // Award XP and progression for both players
      await ProgressionService.processGameplayEvent({
        userId: playerX.userId,
        gameSlug: GameSlug.TIC_TAC_TOE,
        score: outcomeX === 1 ? 100 : 25,
        durationSeconds: 60,
        isWin: outcomeX === 1,
        isMultiplayer: true,
        matchId: room.matchDbId
      });

      await ProgressionService.processGameplayEvent({
        userId: playerO.userId,
        gameSlug: GameSlug.TIC_TAC_TOE,
        score: outcomeO === 1 ? 100 : 25,
        durationSeconds: 60,
        isWin: outcomeO === 1,
        isMultiplayer: true,
        matchId: room.matchDbId
      });
    } catch (e) {
      console.error('Error finalizing match:', e);
    }
  }

  async requestRematch(roomId: string, userId: string): Promise<{ room?: GameRoom; restarted: boolean }> {
    const room = this.rooms.get(roomId);
    if (!room || room.status !== 'FINISHED') return { restarted: false };

    room.rematchVotes.add(userId);

    if (room.rematchVotes.size >= 2) {
      await this.startGame(room);
      return { room, restarted: true };
    }

    return { room, restarted: false };
  }

  leaveRoom(socketId: string): { room?: GameRoom; wasPlaying: boolean; remainingPlayerSocketId?: string } {
    const roomId = this.userToRoom.get(socketId);
    if (!roomId) return { wasPlaying: false };

    this.userToRoom.delete(socketId);
    const room = this.rooms.get(roomId);
    if (!room) return { wasPlaying: false };

    const wasPlaying = room.status === 'PLAYING';
    const leavingPlayer = room.players.find((p) => p.socketId === socketId);
    room.players = room.players.filter((p) => p.socketId !== socketId);

    if (room.players.length === 0) {
      this.rooms.delete(roomId);
      return { wasPlaying: false };
    }

    const remainingPlayer = room.players[0];

    if (wasPlaying && leavingPlayer) {
      room.status = 'FINISHED';
      room.winner = remainingPlayer.marker || null;
      this.finalizeMatch(room);
    }

    return {
      room,
      wasPlaying,
      remainingPlayerSocketId: remainingPlayer?.socketId
    };
  }
}

export const gameRoomManager = new GameRoomManager();
