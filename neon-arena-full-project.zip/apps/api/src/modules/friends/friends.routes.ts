import { Router } from 'express';
import {
  getFriendsList,
  sendFriendRequest,
  respondFriendRequest,
  removeFriend,
  blockUser,
  reportUser
} from './friends.controller.js';
import { authenticateJwt } from '../../middleware/auth.js';

const router = Router();

router.use(authenticateJwt);

router.get('/', getFriendsList);
router.post('/request', sendFriendRequest);
router.post('/respond', respondFriendRequest);
router.delete('/:friendshipId', removeFriend);
router.post('/block', blockUser);
router.post('/report', reportUser);

export default router;
