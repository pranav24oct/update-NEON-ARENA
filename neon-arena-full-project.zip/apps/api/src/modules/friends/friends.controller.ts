import { Request, Response, NextFunction } from 'express';
import { prisma } from '../../lib/prisma.js';
import { sendFriendRequestSchema, respondFriendRequestSchema, reportUserSchema, blockUserSchema } from '@neon-arena/validation';
import { NotificationType } from '@neon-arena/shared';

export async function getFriendsList(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    const friendships = await prisma.friendship.findMany({
      where: {
        OR: [{ senderId: req.user.userId }, { receiverId: req.user.userId }]
      },
      include: {
        sender: {
          select: {
            id: true,
            username: true,
            profile: true,
            statistics: true
          }
        },
        receiver: {
          select: {
            id: true,
            username: true,
            profile: true,
            statistics: true
          }
        }
      }
    });

    const acceptedFriends: any[] = [];
    const pendingIncoming: any[] = [];
    const pendingOutgoing: any[] = [];

    for (const f of friendships) {
      const isSender = f.senderId === req.user.userId;
      const otherUser = isSender ? f.receiver : f.sender;

      if (f.status === 'ACCEPTED') {
        acceptedFriends.push({
          friendshipId: f.id,
          friendId: otherUser.id,
          username: otherUser.username,
          displayName: otherUser.profile?.displayName || otherUser.username,
          avatar: otherUser.profile?.avatar,
          level: otherUser.statistics?.level || 1,
          totalXp: otherUser.statistics?.totalXp || 0,
          currentStreak: otherUser.statistics?.currentStreak || 0,
          presence: 'ONLINE' // Real-time updated via sockets
        });
      } else if (f.status === 'PENDING') {
        if (isSender) {
          pendingOutgoing.push({
            friendshipId: f.id,
            targetUser: otherUser.username,
            createdAt: f.createdAt
          });
        } else {
          pendingIncoming.push({
            friendshipId: f.id,
            sender: {
              id: otherUser.id,
              username: otherUser.username,
              displayName: otherUser.profile?.displayName || otherUser.username,
              avatar: otherUser.profile?.avatar
            },
            createdAt: f.createdAt
          });
        }
      }
    }

    res.json({
      friends: acceptedFriends,
      pendingIncoming,
      pendingOutgoing
    });
  } catch (err) {
    next(err);
  }
}

export async function sendFriendRequest(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    const { targetUsername } = sendFriendRequestSchema.parse(req.body);

    if (targetUsername.toLowerCase() === req.user.username.toLowerCase()) {
      res.status(400).json({ error: 'You cannot send a friend request to yourself.' });
      return;
    }

    const targetUser = await prisma.user.findUnique({
      where: { username: targetUsername },
      include: { profile: true }
    });

    if (!targetUser) {
      res.status(404).json({ error: `Player '${targetUsername}' does not exist.` });
      return;
    }

    if (targetUser.profile?.allowFriendRequests === false) {
      res.status(403).json({ error: 'This player is not currently accepting friend requests.' });
      return;
    }

    // Check existing friendship
    const existing = await prisma.friendship.findFirst({
      where: {
        OR: [
          { senderId: req.user.userId, receiverId: targetUser.id },
          { senderId: targetUser.id, receiverId: req.user.userId }
        ]
      }
    });

    if (existing) {
      if (existing.status === 'ACCEPTED') {
        res.status(400).json({ error: 'You are already friends with this player.' });
        return;
      }
      if (existing.status === 'PENDING') {
        res.status(400).json({ error: 'A pending friend request already exists between you.' });
        return;
      }
    }

    const request = await prisma.friendship.create({
      data: {
        senderId: req.user.userId,
        receiverId: targetUser.id,
        status: 'PENDING'
      }
    });

    // Create notification for target
    await prisma.notification.create({
      data: {
        userId: targetUser.id,
        type: NotificationType.FRIEND_REQUEST,
        title: 'New Friend Request',
        message: `${req.user.username} sent you a friend request.`
      }
    });

    res.status(201).json({
      message: `Friend request sent to ${targetUsername}.`,
      friendshipId: request.id
    });
  } catch (err) {
    next(err);
  }
}

export async function respondFriendRequest(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    const { requestId, action } = respondFriendRequestSchema.parse(req.body);

    const friendship = await prisma.friendship.findUnique({
      where: { id: requestId },
      include: { sender: true }
    });

    if (!friendship || friendship.receiverId !== req.user.userId) {
      res.status(404).json({ error: 'Friend request not found.' });
      return;
    }

    if (action === 'ACCEPT') {
      await prisma.friendship.update({
        where: { id: requestId },
        data: { status: 'ACCEPTED' }
      });

      await prisma.notification.create({
        data: {
          userId: friendship.senderId,
          type: NotificationType.FRIEND_ACCEPTED,
          title: 'Friend Request Accepted',
          message: `${req.user.username} accepted your friend request.`
        }
      });

      res.json({ message: 'Friend request accepted!' });
    } else {
      await prisma.friendship.delete({
        where: { id: requestId }
      });

      res.json({ message: 'Friend request declined.' });
    }
  } catch (err) {
    next(err);
  }
}

export async function removeFriend(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    const { friendshipId } = req.params as { friendshipId: string };

    const friendship = await prisma.friendship.findUnique({
      where: { id: friendshipId }
    });

    if (
      !friendship ||
      (friendship.senderId !== req.user.userId && friendship.receiverId !== req.user.userId)
    ) {
      res.status(404).json({ error: 'Friendship not found.' });
      return;
    }

    await prisma.friendship.delete({ where: { id: friendshipId } });

    res.json({ message: 'Friend removed.' });
  } catch (err) {
    next(err);
  }
}

export async function blockUser(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    const { targetUserId } = blockUserSchema.parse(req.body);

    await prisma.blockedUser.upsert({
      where: {
        userId_blockedId: {
          userId: req.user.userId,
          blockedId: targetUserId
        }
      },
      update: {},
      create: {
        userId: req.user.userId,
        blockedId: targetUserId
      }
    });

    // Remove any existing friendships
    await prisma.friendship.deleteMany({
      where: {
        OR: [
          { senderId: req.user.userId, receiverId: targetUserId },
          { senderId: targetUserId, receiverId: req.user.userId }
        ]
      }
    });

    res.json({ message: 'User blocked.' });
  } catch (err) {
    next(err);
  }
}

export async function reportUser(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    const { targetUserId, reason, context } = reportUserSchema.parse(req.body);

    const report = await prisma.report.create({
      data: {
        reporterId: req.user.userId,
        reportedId: targetUserId,
        reason,
        context
      }
    });

    res.status(201).json({
      message: 'Report submitted. Our moderation team will review this incident.',
      reportId: report.id
    });
  } catch (err) {
    next(err);
  }
}
