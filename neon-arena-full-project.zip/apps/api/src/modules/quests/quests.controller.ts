import { Request, Response, NextFunction } from 'express';
import { prisma } from '../../lib/prisma.js';
import { ProgressionService } from '../../services/progressionService.js';

export async function getAllQuests(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const templates = await prisma.questTemplate.findMany({
      where: { isActive: true },
      orderBy: [{ type: 'asc' }, { difficulty: 'asc' }]
    });

    res.json({ quests: templates });
  } catch (err) {
    next(err);
  }
}

export async function getMyQuests(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    // Ensure user has playerQuest records for all active templates
    const templates = await prisma.questTemplate.findMany({ where: { isActive: true } });
    const existing = await prisma.playerQuest.findMany({
      where: { userId: req.user.userId },
      select: { questId: true }
    });
    const existingIds = new Set(existing.map((e) => e.questId));

    for (const t of templates) {
      if (!existingIds.has(t.id)) {
        await prisma.playerQuest.create({
          data: {
            userId: req.user.userId,
            questId: t.id,
            progress: 0,
            completed: false,
            claimed: false
          }
        });
      }
    }

    const myQuests = await prisma.playerQuest.findMany({
      where: { userId: req.user.userId },
      include: { quest: true },
      orderBy: [{ completed: 'desc' }, { claimed: 'asc' }]
    });

    res.json({
      quests: myQuests.map((pq) => ({
        id: pq.id,
        questId: pq.quest.id,
        title: pq.quest.title,
        description: pq.quest.description,
        type: pq.quest.type,
        difficulty: pq.quest.difficulty,
        targetCount: pq.quest.targetCount,
        progress: pq.progress,
        progressPercent: Math.min(100, Math.floor((pq.progress / pq.quest.targetCount) * 100)),
        xpReward: pq.quest.xpReward,
        completed: pq.completed,
        claimed: pq.claimed,
        gameSlug: pq.quest.gameSlug
      }))
    });
  } catch (err) {
    next(err);
  }
}

export async function claimQuestReward(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    const { questId } = req.params as { questId: string };

    const playerQuest = await prisma.playerQuest.findFirst({
      where: {
        id: questId,
        userId: req.user.userId
      },
      include: { quest: true }
    });

    if (!playerQuest) {
      res.status(404).json({ error: 'Quest not found.' });
      return;
    }

    if (!playerQuest.completed) {
      res.status(400).json({ error: 'Quest objectives have not been completed yet.' });
      return;
    }

    if (playerQuest.claimed) {
      res.status(400).json({ error: 'Reward has already been claimed.' });
      return;
    }

    // Mark claimed
    await prisma.playerQuest.update({
      where: { id: playerQuest.id },
      data: {
        claimed: true,
        claimedAt: new Date()
      }
    });

    // Award XP
    const idempotencyKey = `quest_claim_${playerQuest.id}_${req.user.userId}`;
    const result = await ProgressionService.awardXp(
      req.user.userId,
      playerQuest.quest.xpReward,
      'QUEST_CLAIM',
      idempotencyKey
    );

    res.json({
      message: `Claimed ${playerQuest.quest.xpReward} XP for completing '${playerQuest.quest.title}'!`,
      xpAwarded: playerQuest.quest.xpReward,
      newTotalXp: result.newTotalXp,
      level: result.level,
      leveledUp: result.leveledUp
    });
  } catch (err) {
    next(err);
  }
}
