import { Router } from 'express';
import { getAllQuests, getMyQuests, claimQuestReward } from './quests.controller.js';
import { authenticateJwt } from '../../middleware/auth.js';

const router = Router();

router.get('/', getAllQuests);
router.get('/me', authenticateJwt, getMyQuests);
router.post('/:questId/claim', authenticateJwt, claimQuestReward);

export default router;
