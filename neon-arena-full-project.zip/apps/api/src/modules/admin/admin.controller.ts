import { Request, Response, NextFunction } from 'express';
import { prisma } from '../../lib/prisma.js';
import { adminUpdateUserRoleSchema, adminBanUserSchema, createTournamentSchema } from '@neon-arena/validation';

export async function getAdminOverview(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const [
      totalUsers,
      totalGames,
      totalMatches,
      totalGameSessions,
      pendingReportsCount,
      activeTournamentsCount
    ] = await Promise.all([
      prisma.user.count(),
      prisma.game.count(),
      prisma.match.count(),
      prisma.gameSession.count(),
      prisma.report.count({ where: { status: 'PENDING' } }),
      prisma.tournament.count({ where: { status: { in: ['ACTIVE', 'REGISTRATION'] } } })
    ]);

    const recentAuditLogs = await prisma.auditLog.findMany({
      orderBy: { createdAt: 'desc' },
      take: 10,
      include: {
        admin: {
          select: { username: true }
        }
      }
    });

    const memoryUsage = process.memoryUsage();

    res.json({
      metrics: {
        totalUsers,
        totalGames,
        totalMatches,
        totalGameSessions,
        pendingReportsCount,
        activeTournamentsCount
      },
      systemHealth: {
        uptimeSeconds: Math.floor(process.uptime()),
        nodeVersion: process.version,
        memoryUsageMb: {
          rss: Math.round(memoryUsage.rss / 1024 / 1024),
          heapUsed: Math.round(memoryUsage.heapUsed / 1024 / 1024)
        },
        database: 'Connected'
      },
      recentAuditLogs
    });
  } catch (err) {
    next(err);
  }
}

export async function getAllUsersAdmin(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const page = parseInt(String(req.query.page || '1'), 10);
    const limit = Math.min(50, parseInt(String(req.query.limit || '20'), 10));
    const skip = (page - 1) * limit;

    const [total, users] = await Promise.all([
      prisma.user.count(),
      prisma.user.findMany({
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        select: {
          id: true,
          username: true,
          email: true,
          role: true,
          isBanned: true,
          banReason: true,
          createdAt: true,
          profile: true,
          statistics: true
        }
      })
    ]);

    res.json({
      page,
      limit,
      total,
      users
    });
  } catch (err) {
    next(err);
  }
}

export async function updateUserRole(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { userId, role } = adminUpdateUserRoleSchema.parse(req.body);

    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    await prisma.user.update({
      where: { id: userId },
      data: { role }
    });

    // Record audit log
    await prisma.auditLog.create({
      data: {
        adminId: req.user!.userId,
        action: 'UPDATE_USER_ROLE',
        targetId: userId,
        details: JSON.stringify({ previousRole: user.role, newRole: role, targetUsername: user.username })
      }
    });

    res.json({ message: `Role for user '${user.username}' changed to ${role}.` });
  } catch (err) {
    next(err);
  }
}

export async function banUser(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { userId, reason, durationDays } = adminBanUserSchema.parse(req.body);

    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    if (user.role === 'ADMIN') {
      res.status(403).json({ error: 'Cannot ban an administrator.' });
      return;
    }

    const bannedUntil = durationDays
      ? new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000)
      : null;

    await prisma.user.update({
      where: { id: userId },
      data: {
        isBanned: true,
        banReason: reason,
        bannedUntil
      }
    });

    await prisma.auditLog.create({
      data: {
        adminId: req.user!.userId,
        action: 'BAN_USER',
        targetId: userId,
        details: JSON.stringify({ reason, durationDays, targetUsername: user.username })
      }
    });

    res.json({ message: `User '${user.username}' has been banned.` });
  } catch (err) {
    next(err);
  }
}

export async function unbanUser(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { userId } = req.params as { userId: string };

    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    await prisma.user.update({
      where: { id: userId },
      data: {
        isBanned: false,
        banReason: null,
        bannedUntil: null
      }
    });

    await prisma.auditLog.create({
      data: {
        adminId: req.user!.userId,
        action: 'UNBAN_USER',
        targetId: userId,
        details: JSON.stringify({ targetUsername: user.username })
      }
    });

    res.json({ message: `User '${user.username}' unbanned.` });
  } catch (err) {
    next(err);
  }
}

export async function getReports(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const reports = await prisma.report.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        reporter: { select: { id: true, username: true } },
        reportedUser: { select: { id: true, username: true, isBanned: true } }
      }
    });

    res.json({ reports });
  } catch (err) {
    next(err);
  }
}

export async function resolveReport(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { reportId } = req.params as { reportId: string };
    const { action } = req.body; // "DISMISSED" | "ACTIONED"

    await prisma.report.update({
      where: { id: reportId },
      data: { status: action || 'ACTIONED' }
    });

    await prisma.auditLog.create({
      data: {
        adminId: req.user!.userId,
        action: 'RESOLVE_REPORT',
        targetId: reportId,
        details: JSON.stringify({ resolution: action })
      }
    });

    res.json({ message: 'Report updated.' });
  } catch (err) {
    next(err);
  }
}

export async function adminCreateTournament(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const data = createTournamentSchema.parse(req.body);

    const game = await prisma.game.findUnique({ where: { slug: data.gameSlug } });
    if (!game) {
      res.status(404).json({ error: 'Game not found.' });
      return;
    }

    const tournament = await prisma.tournament.create({
      data: {
        title: data.title,
        description: data.description,
        gameId: game.id,
        maxParticipants: data.maxParticipants,
        startDate: new Date(data.startDate),
        registrationDeadline: new Date(data.registrationDeadline),
        xpReward: data.xpReward,
        status: 'REGISTRATION'
      }
    });

    await prisma.auditLog.create({
      data: {
        adminId: req.user!.userId,
        action: 'CREATE_TOURNAMENT',
        targetId: tournament.id,
        details: JSON.stringify({ title: data.title, maxParticipants: data.maxParticipants })
      }
    });

    res.status(201).json({
      message: 'Tournament created successfully.',
      tournament
    });
  } catch (err) {
    next(err);
  }
}
