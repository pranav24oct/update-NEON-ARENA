import { Router } from 'express';
import {
  getAdminOverview,
  getAllUsersAdmin,
  updateUserRole,
  banUser,
  unbanUser,
  getReports,
  resolveReport,
  adminCreateTournament
} from './admin.controller.js';
import { authenticateJwt, requireRole } from '../../middleware/auth.js';
import { UserRole } from '@neon-arena/shared';

const router = Router();

router.use(authenticateJwt);
router.use(requireRole([UserRole.ADMIN]));

router.get('/overview', getAdminOverview);
router.get('/users', getAllUsersAdmin);
router.patch('/users/role', updateUserRole);
router.post('/users/ban', banUser);
router.post('/users/:userId/unban', unbanUser);
router.get('/reports', getReports);
router.patch('/reports/:reportId/resolve', resolveReport);
router.post('/tournaments', adminCreateTournament);

export default router;
