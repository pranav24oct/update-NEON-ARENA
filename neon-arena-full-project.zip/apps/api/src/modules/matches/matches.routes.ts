import { Router } from 'express';
import { getMatchHistory, getMatchDetails } from './matches.controller.js';
import { authenticateJwt } from '../../middleware/auth.js';

const router = Router();

router.get('/history', authenticateJwt, getMatchHistory);
router.get('/:matchId', getMatchDetails);

export default router;
