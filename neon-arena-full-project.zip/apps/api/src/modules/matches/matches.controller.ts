import { Request, Response, NextFunction } from 'express';
import { prisma } from '../../lib/prisma.js';

export async function getMatchHistory(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    const page = parseInt(String(req.query.page || '1'), 10);
    const limit = Math.min(50, parseInt(String(req.query.limit || '15'), 10));
    const skip = (page - 1) * limit;

    const [total, participations] = await Promise.all([
      prisma.matchParticipant.count({ where: { userId: req.user.userId } }),
      prisma.matchParticipant.findMany({
        where: { userId: req.user.userId },
        orderBy: { joinedAt: 'desc' },
        skip,
        take: limit,
        include: {
          match: {
            include: {
              game: true,
              participants: {
                include: {
                  user: {
                    select: {
                      id: true,
                      username: true,
                      profile: { select: { avatar: true, displayName: true } }
                    }
                  }
                }
              }
            }
          }
        }
      })
    ]);

    const matches = participations.map((p) => {
      const opponents = p.match.participants
        .filter((part) => part.userId !== req.user!.userId)
        .map((part) => ({
          userId: part.userId,
          username: part.user.username,
          displayName: part.user.profile?.displayName || part.user.username,
          avatar: part.user.profile?.avatar,
          ratingAfter: part.ratingAfter,
          isWinner: part.isWinner
        }));

      return {
        matchId: p.matchId,
        gameTitle: p.match.game.title,
        gameSlug: p.match.game.slug,
        status: p.match.status,
        myMarker: p.roleMarker,
        isWinner: p.isWinner,
        ratingBefore: p.ratingBefore,
        ratingAfter: p.ratingAfter,
        ratingDelta: p.ratingDelta,
        startedAt: p.match.startedAt,
        endedAt: p.match.endedAt || p.joinedAt,
        opponents
      };
    });

    res.json({
      page,
      limit,
      total,
      matches
    });
  } catch (err) {
    next(err);
  }
}

export async function getMatchDetails(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { matchId } = req.params as { matchId: string };

    const match = await prisma.match.findUnique({
      where: { id: matchId },
      include: {
        game: true,
        participants: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                profile: true
              }
            }
          }
        }
      }
    });

    if (!match) {
      res.status(404).json({ error: 'Match not found.' });
      return;
    }

    res.json({ match });
  } catch (err) {
    next(err);
  }
}
