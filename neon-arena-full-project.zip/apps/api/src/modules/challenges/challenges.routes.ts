import { Router } from 'express';
import { getDailyChallenges, getAllAchievements } from './challenges.controller.js';
import { optionalAuth } from '../../middleware/auth.js';

const router = Router();

router.get('/daily', optionalAuth, getDailyChallenges);
router.get('/achievements', optionalAuth, getAllAchievements);

export default router;
