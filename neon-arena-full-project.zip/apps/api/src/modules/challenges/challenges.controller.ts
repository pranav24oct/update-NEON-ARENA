import { Request, Response, NextFunction } from 'express';
import { prisma } from '../../lib/prisma.js';

export async function getDailyChallenges(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    // Return daily quests formatted as today's active challenges with reset countdown
    const dailyQuests = await prisma.questTemplate.findMany({
      where: { type: 'DAILY', isActive: true }
    });

    // Calculate time until next midnight UTC
    const now = new Date();
    const nextMidnight = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1, 0, 0, 0));
    const secondsRemaining = Math.max(0, Math.floor((nextMidnight.getTime() - now.getTime()) / 1000));

    let userProgressMap: Record<string, { progress: number; completed: boolean; claimed: boolean }> = {};

    if (req.user) {
      const pQuests = await prisma.playerQuest.findMany({
        where: { userId: req.user.userId }
      });
      pQuests.forEach((pq) => {
        userProgressMap[pq.questId] = {
          progress: pq.progress,
          completed: pq.completed,
          claimed: pq.claimed
        };
      });
    }

    const challenges = dailyQuests.map((q) => {
      const up = userProgressMap[q.id] || { progress: 0, completed: false, claimed: false };
      return {
        id: q.id,
        title: q.title,
        description: q.description,
        difficulty: q.difficulty,
        targetCount: q.targetCount,
        progress: up.progress,
        completed: up.completed,
        claimed: up.claimed,
        progressPercent: Math.min(100, Math.floor((up.progress / q.targetCount) * 100)),
        xpReward: q.xpReward,
        gameSlug: q.gameSlug
      };
    });

    res.json({
      resetInSeconds: secondsRemaining,
      resetAtUtc: nextMidnight.toISOString(),
      challenges
    });
  } catch (err) {
    next(err);
  }
}

export async function getAllAchievements(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const achievements = await prisma.achievement.findMany({
      orderBy: { xpReward: 'asc' }
    });

    let unlockedSet = new Set<string>();
    let unlockedDates: Record<string, Date> = {};

    if (req.user) {
      const myUnlocks = await prisma.playerAchievement.findMany({
        where: { userId: req.user.userId }
      });
      myUnlocks.forEach((u) => {
        unlockedSet.add(u.achievementId);
        unlockedDates[u.achievementId] = u.unlockedAt;
      });
    }

    const result = achievements.map((ach) => ({
      id: ach.id,
      slug: ach.slug,
      name: ach.name,
      description: ach.description,
      icon: ach.icon,
      rarity: ach.rarity,
      xpReward: ach.xpReward,
      threshold: ach.threshold,
      conditionType: ach.conditionType,
      isUnlocked: unlockedSet.has(ach.id),
      unlockedAt: unlockedDates[ach.id] || null
    }));

    res.json({ achievements: result });
  } catch (err) {
    next(err);
  }
}
