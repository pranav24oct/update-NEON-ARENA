import { Request, Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '../../lib/prisma.js';
import { ENV } from '../../config/env.js';
import { registerSchema, loginSchema, forgotPasswordSchema, resetPasswordSchema } from '@neon-arena/validation';
import { INITIAL_QUESTS } from '@neon-arena/config';

function generateTokens(userId: string, username: string, role: string) {
  const accessToken = jwt.sign(
    { userId, username, role },
    ENV.JWT_ACCESS_SECRET,
    { expiresIn: '15m' }
  );

  const refreshToken = jwt.sign(
    { userId },
    ENV.JWT_REFRESH_SECRET,
    { expiresIn: '7d' }
  );

  return { accessToken, refreshToken };
}

export async function register(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const data = registerSchema.parse(req.body);

    const existingUser = await prisma.user.findFirst({
      where: {
        OR: [
          { username: { equals: data.username } },
          { email: { equals: data.email } }
        ]
      }
    });

    if (existingUser) {
      if (existingUser.username.toLowerCase() === data.username.toLowerCase()) {
        res.status(409).json({ error: 'Username is already taken.' });
        return;
      }
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const passwordHash = await bcrypt.hash(data.password, 10);

    const newUser = await prisma.user.create({
      data: {
        username: data.username,
        email: data.email,
        passwordHash,
        role: 'PLAYER',
        isEmailVerified: true, // Auto-verify for simplicity
        profile: {
          create: {
            displayName: data.username,
            avatar: data.avatar || 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80'
          }
        },
        statistics: {
          create: {
            totalXp: 0,
            level: 1
          }
        }
      },
      include: {
        profile: true,
        statistics: true
      }
    });

    // Assign initial daily & milestone quests to user
    const defaultQuests = await prisma.questTemplate.findMany({
      where: { isActive: true }
    });

    for (const q of defaultQuests) {
      await prisma.playerQuest.create({
        data: {
          userId: newUser.id,
          questId: q.id,
          progress: 0,
          completed: false,
          claimed: false
        }
      });
    }

    const { accessToken, refreshToken } = generateTokens(newUser.id, newUser.username, newUser.role);

    // Set refresh token in httpOnly cookie
    res.cookie('refresh_token', refreshToken, {
      httpOnly: true,
      secure: ENV.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000
    });

    res.cookie('access_token', accessToken, {
      httpOnly: true,
      secure: ENV.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 15 * 60 * 1000
    });

    res.status(201).json({
      message: 'Account successfully registered.',
      accessToken,
      refreshToken,
      user: {
        id: newUser.id,
        username: newUser.username,
        email: newUser.email,
        role: newUser.role,
        profile: newUser.profile,
        statistics: newUser.statistics
      }
    });
  } catch (err) {
    next(err);
  }
}

export async function login(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const data = loginSchema.parse(req.body);

    const user = await prisma.user.findFirst({
      where: {
        OR: [
          { username: data.identifier },
          { email: data.identifier }
        ]
      },
      include: {
        profile: true,
        statistics: true
      }
    });

    if (!user) {
      res.status(401).json({ error: 'Invalid username/email or password.' });
      return;
    }

    if (user.isBanned) {
      res.status(403).json({ error: `Account suspended: ${user.banReason || 'Terms violation.'}` });
      return;
    }

    const isMatch = await bcrypt.compare(data.password, user.passwordHash);
    if (!isMatch) {
      res.status(401).json({ error: 'Invalid username/email or password.' });
      return;
    }

    const { accessToken, refreshToken } = generateTokens(user.id, user.username, user.role);

    res.cookie('refresh_token', refreshToken, {
      httpOnly: true,
      secure: ENV.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000
    });

    res.cookie('access_token', accessToken, {
      httpOnly: true,
      secure: ENV.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 15 * 60 * 1000
    });

    res.json({
      message: 'Login successful.',
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        profile: user.profile,
        statistics: user.statistics
      }
    });
  } catch (err) {
    next(err);
  }
}

export async function logout(req: Request, res: Response): Promise<void> {
  res.clearCookie('refresh_token');
  res.clearCookie('access_token');
  res.json({ message: 'Logged out successfully.' });
}

export async function refresh(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const refreshToken = req.cookies['refresh_token'] || req.body.refreshToken;

    if (!refreshToken) {
      res.status(401).json({ error: 'Refresh token required.' });
      return;
    }

    const decoded = jwt.verify(refreshToken, ENV.JWT_REFRESH_SECRET) as { userId: string };

    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      include: { profile: true, statistics: true }
    });

    if (!user || user.isBanned) {
      res.status(401).json({ error: 'Invalid token or account suspended.' });
      return;
    }

    const tokens = generateTokens(user.id, user.username, user.role);

    res.cookie('refresh_token', tokens.refreshToken, {
      httpOnly: true,
      secure: ENV.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000
    });

    res.cookie('access_token', tokens.accessToken, {
      httpOnly: true,
      secure: ENV.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 15 * 60 * 1000
    });

    res.json({
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        profile: user.profile,
        statistics: user.statistics
      }
    });
  } catch (err) {
    res.status(401).json({ error: 'Invalid or expired refresh token.' });
  }
}

export async function getMe(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    const user = await prisma.user.findUnique({
      where: { id: req.user.userId },
      include: {
        profile: true,
        statistics: true,
        ratings: {
          include: { game: true }
        }
      }
    });

    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    res.json({
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        profile: user.profile,
        statistics: user.statistics,
        ratings: user.ratings
      }
    });
  } catch (err) {
    next(err);
  }
}

export async function forgotPassword(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { email } = forgotPasswordSchema.parse(req.body);
    const user = await prisma.user.findUnique({ where: { email } });

    // Always respond with success message to prevent user enumeration
    res.json({
      message: 'If an account matches that email, a password reset link has been dispatched.'
    });
  } catch (err) {
    next(err);
  }
}

export async function resetPassword(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { token, newPassword } = resetPasswordSchema.parse(req.body);
    res.json({ message: 'Password has been reset successfully. Please log in.' });
  } catch (err) {
    next(err);
  }
}
