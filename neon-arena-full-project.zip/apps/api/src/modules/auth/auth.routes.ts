import { Router } from 'express';
import { register, login, logout, refresh, getMe, forgotPassword, resetPassword } from './auth.controller.js';
import { authenticateJwt } from '../../middleware/auth.js';
import { authRateLimiter } from '../../middleware/rateLimiter.js';

const router = Router();

router.post('/register', authRateLimiter, register);
router.post('/login', authRateLimiter, login);
router.post('/logout', logout);
router.post('/refresh', refresh);
router.get('/me', authenticateJwt, getMe);
router.post('/forgot-password', authRateLimiter, forgotPassword);
router.post('/reset-password', authRateLimiter, resetPassword);

export default router;
