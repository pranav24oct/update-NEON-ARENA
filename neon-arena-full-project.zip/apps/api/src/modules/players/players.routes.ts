import { Router } from 'express';
import { getPlayerProfile, updateMyProfile, getPlayerStats } from './players.controller.js';
import { authenticateJwt } from '../../middleware/auth.js';

const router = Router();

router.patch('/me', authenticateJwt, updateMyProfile);
router.get('/:username', getPlayerProfile);
router.get('/:username/stats', getPlayerStats);

export default router;
