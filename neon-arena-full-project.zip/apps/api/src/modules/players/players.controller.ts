import { Request, Response, NextFunction } from 'express';
import { prisma } from '../../lib/prisma.js';
import { updateProfileSchema } from '@neon-arena/validation';

export async function getPlayerProfile(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { username } = req.params as { username: string };

    const user = await prisma.user.findUnique({
      where: { username },
      select: {
        id: true,
        username: true,
        role: true,
        createdAt: true,
        profile: true,
        statistics: true,
        ratings: {
          include: { game: true }
        },
        achievements: {
          include: { achievement: true }
        }
      }
    });

    if (!user) {
      res.status(404).json({ error: `Player '${username}' not found.` });
      return;
    }

    // Fetch personal high scores across games
    const topScores = await prisma.scoreRecord.findMany({
      where: { userId: user.id },
      orderBy: { score: 'desc' },
      take: 6,
      include: { game: true }
    });

    // Fetch recent match participations
    const recentMatches = await prisma.matchParticipant.findMany({
      where: { userId: user.id },
      orderBy: { joinedAt: 'desc' },
      take: 5,
      include: {
        match: {
          include: {
            game: true,
            participants: {
              include: {
                user: {
                  select: { id: true, username: true, profile: true }
                }
              }
            }
          }
        }
      }
    });

    res.json({
      player: {
        id: user.id,
        username: user.username,
        role: user.role,
        joinDate: user.createdAt,
        profile: user.profile,
        statistics: user.statistics,
        ratings: user.ratings,
        achievements: user.achievements.map((a) => ({
          ...a.achievement,
          unlockedAt: a.unlockedAt
        })),
        topScores,
        recentMatches: recentMatches.map((p) => ({
          matchId: p.matchId,
          game: p.match.game.title,
          gameSlug: p.match.game.slug,
          status: p.match.status,
          isWinner: p.isWinner,
          ratingDelta: p.ratingDelta,
          endedAt: p.match.endedAt || p.joinedAt,
          opponents: p.match.participants
            .filter((op) => op.userId !== user.id)
            .map((op) => ({
              username: op.user.username,
              avatar: op.user.profile?.avatar
            }))
        }))
      }
    });
  } catch (err) {
    next(err);
  }
}

export async function updateMyProfile(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    const data = updateProfileSchema.parse(req.body);

    const updatedProfile = await prisma.playerProfile.upsert({
      where: { userId: req.user.userId },
      update: {
        displayName: data.displayName,
        bio: data.bio,
        avatar: data.avatar,
        country: data.country,
        isProfilePublic: data.isProfilePublic,
        allowFriendRequests: data.allowFriendRequests
      },
      create: {
        userId: req.user.userId,
        displayName: data.displayName || req.user.username,
        bio: data.bio,
        avatar: data.avatar || 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80',
        country: data.country || 'US',
        isProfilePublic: data.isProfilePublic ?? true,
        allowFriendRequests: data.allowFriendRequests ?? true
      }
    });

    res.json({
      message: 'Profile updated successfully.',
      profile: updatedProfile
    });
  } catch (err) {
    next(err);
  }
}

export async function getPlayerStats(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { username } = req.params as { username: string };

    const user = await prisma.user.findUnique({
      where: { username },
      select: {
        id: true,
        username: true,
        statistics: true,
        ratings: { include: { game: true } }
      }
    });

    if (!user) {
      res.status(404).json({ error: 'Player not found.' });
      return;
    }

    const totalGames = user.statistics?.totalGamesPlayed || 0;
    const totalWins = user.statistics?.totalWins || 0;
    const winRate = totalGames > 0 ? Math.round((totalWins / totalGames) * 100) : 0;

    res.json({
      username: user.username,
      statistics: {
        ...user.statistics,
        winRate
      },
      ratings: user.ratings
    });
  } catch (err) {
    next(err);
  }
}
