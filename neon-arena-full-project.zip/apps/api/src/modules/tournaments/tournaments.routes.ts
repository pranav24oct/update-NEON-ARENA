import { Router } from 'express';
import {
  getAllTournaments,
  getTournamentById,
  registerForTournament,
  getTournamentBracket
} from './tournaments.controller.js';
import { authenticateJwt, optionalAuth } from '../../middleware/auth.js';

const router = Router();

router.get('/', optionalAuth, getAllTournaments);
router.get('/:id', optionalAuth, getTournamentById);
router.post('/:id/register', authenticateJwt, registerForTournament);
router.get('/:id/bracket', getTournamentBracket);

export default router;
