import { Request, Response, NextFunction } from 'express';
import { prisma } from '../../lib/prisma.js';

export async function getAllTournaments(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const tournaments = await prisma.tournament.findMany({
      orderBy: { startDate: 'asc' },
      include: {
        game: true,
        participants: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                profile: { select: { avatar: true, displayName: true } }
              }
            }
          }
        }
      }
    });

    const result = tournaments.map((t) => ({
      id: t.id,
      title: t.title,
      description: t.description,
      gameTitle: t.game.title,
      gameSlug: t.game.slug,
      status: t.status,
      maxParticipants: t.maxParticipants,
      registeredCount: t.participants.length,
      isFull: t.participants.length >= t.maxParticipants,
      isRegistered: req.user ? t.participants.some((p) => p.userId === req.user!.userId) : false,
      startDate: t.startDate,
      registrationDeadline: t.registrationDeadline,
      xpReward: t.xpReward,
      participants: t.participants.map((p) => ({
        userId: p.userId,
        username: p.user.username,
        displayName: p.user.profile?.displayName || p.user.username,
        avatar: p.user.profile?.avatar
      }))
    }));

    res.json({ tournaments: result });
  } catch (err) {
    next(err);
  }
}

export async function getTournamentById(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params as { id: string };

    const tournament = await prisma.tournament.findUnique({
      where: { id },
      include: {
        game: true,
        participants: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                profile: true,
                statistics: true
              }
            }
          }
        },
        matches: {
          orderBy: [{ round: 'asc' }, { matchOrder: 'asc' }]
        }
      }
    });

    if (!tournament) {
      res.status(404).json({ error: 'Tournament not found.' });
      return;
    }

    res.json({
      tournament: {
        ...tournament,
        registeredCount: tournament.participants.length,
        isRegistered: req.user
          ? tournament.participants.some((p) => p.userId === req.user!.userId)
          : false
      }
    });
  } catch (err) {
    next(err);
  }
}

export async function registerForTournament(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    const { id } = req.params as { id: string };

    const tournament = await prisma.tournament.findUnique({
      where: { id },
      include: { participants: true }
    });

    if (!tournament) {
      res.status(404).json({ error: 'Tournament not found.' });
      return;
    }

    if (tournament.status !== 'REGISTRATION' && tournament.status !== 'UPCOMING') {
      res.status(400).json({ error: 'Registration is not currently open for this tournament.' });
      return;
    }

    if (tournament.participants.length >= tournament.maxParticipants) {
      res.status(400).json({ error: 'Tournament participant limit has already been reached.' });
      return;
    }

    const alreadyRegistered = tournament.participants.some((p) => p.userId === req.user!.userId);
    if (alreadyRegistered) {
      res.status(400).json({ error: 'You are already registered for this tournament.' });
      return;
    }

    const participant = await prisma.tournamentParticipant.create({
      data: {
        tournamentId: tournament.id,
        userId: req.user.userId,
        seedNumber: tournament.participants.length + 1
      }
    });

    res.status(201).json({
      message: 'Successfully registered for tournament!',
      participant
    });
  } catch (err) {
    next(err);
  }
}

export async function getTournamentBracket(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { id } = req.params as { id: string };

    const tournament = await prisma.tournament.findUnique({
      where: { id },
      include: {
        participants: {
          include: {
            user: { select: { id: true, username: true, profile: true } }
          }
        },
        matches: {
          orderBy: [{ round: 'asc' }, { matchOrder: 'asc' }]
        }
      }
    });

    if (!tournament) {
      res.status(404).json({ error: 'Tournament not found.' });
      return;
    }

    // Single-elimination rounds construction
    const totalRounds = Math.ceil(Math.log2(tournament.maxParticipants));
    const rounds: any[] = [];

    // Map participants
    const participantMap = new Map<string, any>(
      tournament.participants.map((p: any) => [p.userId, p.user])
    );

    // Group matches by round or generate projected tree
    for (let r = 1; r <= totalRounds; r++) {
      const matchesInRound = tournament.matches.filter((m) => m.round === r);
      const expectedMatches = tournament.maxParticipants / Math.pow(2, r);

      const roundMatches: any[] = [];
      for (let i = 0; i < expectedMatches; i++) {
        const match = matchesInRound[i];
        if (match) {
          const p1 = match.player1Id ? participantMap.get(match.player1Id) : null;
          const p2 = match.player2Id ? participantMap.get(match.player2Id) : null;
          roundMatches.push({
            id: match.id,
            round: r,
            matchOrder: i,
            status: match.status,
            winnerId: match.winnerId,
            player1: p1 ? { id: p1.id, username: p1.username, avatar: p1.profile?.avatar } : null,
            player2: p2 ? { id: p2.id, username: p2.username, avatar: p2.profile?.avatar } : null
          });
        } else {
          // Placeholder node for upcoming round
          roundMatches.push({
            id: `placeholder_r${r}_m${i}`,
            round: r,
            matchOrder: i,
            status: 'PENDING',
            winnerId: null,
            player1: null,
            player2: null
          });
        }
      }

      rounds.push({
        roundNumber: r,
        roundName:
          r === totalRounds
            ? 'Grand Finals'
            : r === totalRounds - 1
            ? 'Semifinals'
            : r === totalRounds - 2
            ? 'Quarterfinals'
            : `Round ${r}`,
        matches: roundMatches
      });
    }

    res.json({
      tournamentId: tournament.id,
      tournamentTitle: tournament.title,
      totalRounds,
      rounds
    });
  } catch (err) {
    next(err);
  }
}
