import { Router } from 'express';
import {
  getGlobalLeaderboard,
  getGameLeaderboard,
  getCompetitiveLeaderboard,
  getFriendsLeaderboard
} from './leaderboards.controller.js';
import { authenticateJwt } from '../../middleware/auth.js';

const router = Router();

router.get('/global', getGlobalLeaderboard);
router.get('/competitive', getCompetitiveLeaderboard);
router.get('/games/:slug', getGameLeaderboard);
router.get('/friends', authenticateJwt, getFriendsLeaderboard);

export default router;
