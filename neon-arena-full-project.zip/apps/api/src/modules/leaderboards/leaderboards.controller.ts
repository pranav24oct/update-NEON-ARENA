import { Request, Response, NextFunction } from 'express';
import { prisma } from '../../lib/prisma.js';
import { getTierFromRating, COMPETITIVE_TIERS } from '@neon-arena/shared';

export async function getGlobalLeaderboard(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const page = parseInt(String(req.query.page || '1'), 10);
    const limit = Math.min(50, parseInt(String(req.query.limit || '20'), 10));
    const skip = (page - 1) * limit;

    const [total, stats] = await Promise.all([
      prisma.playerStatistics.count(),
      prisma.playerStatistics.findMany({
        orderBy: [{ totalXp: 'desc' }, { totalWins: 'desc' }],
        skip,
        take: limit,
        include: {
          user: {
            select: {
              id: true,
              username: true,
              profile: {
                select: {
                  displayName: true,
                  avatar: true,
                  selectedTitle: true,
                  selectedFrame: true,
                  country: true
                }
              }
            }
          }
        }
      })
    ]);

    const entries = stats.map((s, idx) => ({
      rank: skip + idx + 1,
      userId: s.userId,
      username: s.user.username,
      displayName: s.user.profile?.displayName || s.user.username,
      avatar: s.user.profile?.avatar,
      selectedTitle: s.user.profile?.selectedTitle,
      selectedFrame: s.user.profile?.selectedFrame,
      country: s.user.profile?.country,
      level: s.level,
      totalXp: s.totalXp,
      wins: s.totalWins,
      gamesPlayed: s.totalGamesPlayed,
      streak: s.currentStreak
    }));

    res.json({
      page,
      limit,
      total,
      entries
    });
  } catch (err) {
    next(err);
  }
}

export async function getGameLeaderboard(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { slug } = req.params as { slug: string };
    const page = parseInt(String(req.query.page || '1'), 10);
    const limit = Math.min(50, parseInt(String(req.query.limit || '20'), 10));
    const skip = (page - 1) * limit;

    const game = await prisma.game.findUnique({ where: { slug } });
    if (!game) {
      res.status(404).json({ error: `Game '${slug}' not found.` });
      return;
    }

    const [total, scores] = await Promise.all([
      prisma.scoreRecord.count({ where: { gameId: game.id } }),
      prisma.scoreRecord.findMany({
        where: { gameId: game.id },
        orderBy: { score: 'desc' },
        skip,
        take: limit,
        include: {
          user: {
            select: {
              id: true,
              username: true,
              profile: {
                select: {
                  displayName: true,
                  avatar: true,
                  country: true
                }
              }
            }
          }
        }
      })
    ]);

    const entries = scores.map((s, idx) => ({
      rank: skip + idx + 1,
      userId: s.userId,
      username: s.user.username,
      displayName: s.user.profile?.displayName || s.user.username,
      avatar: s.user.profile?.avatar,
      country: s.user.profile?.country,
      score: s.score,
      achievedAt: s.achievedAt
    }));

    res.json({
      game: {
        title: game.title,
        slug: game.slug
      },
      page,
      limit,
      total,
      entries
    });
  } catch (err) {
    next(err);
  }
}

export async function getCompetitiveLeaderboard(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const page = parseInt(String(req.query.page || '1'), 10);
    const limit = Math.min(50, parseInt(String(req.query.limit || '20'), 10));
    const skip = (page - 1) * limit;

    const [total, ratings] = await Promise.all([
      prisma.playerRating.count(),
      prisma.playerRating.findMany({
        orderBy: { rating: 'desc' },
        skip,
        take: limit,
        include: {
          game: true,
          user: {
            select: {
              id: true,
              username: true,
              profile: {
                select: {
                  displayName: true,
                  avatar: true,
                  country: true
                }
              }
            }
          }
        }
      })
    ]);

    const entries = ratings.map((r, idx) => {
      const tierEnum = getTierFromRating(r.rating);
      const tierInfo = COMPETITIVE_TIERS[tierEnum];
      return {
        rank: skip + idx + 1,
        userId: r.userId,
        username: r.user.username,
        displayName: r.user.profile?.displayName || r.user.username,
        avatar: r.user.profile?.avatar,
        country: r.user.profile?.country,
        rating: r.rating,
        peakRating: r.peakRating,
        matchesCount: r.matchesCount,
        tier: r.tier,
        tierLabel: tierInfo.label,
        tierColor: tierInfo.color,
        game: r.game.title
      };
    });

    res.json({
      page,
      limit,
      total,
      entries
    });
  } catch (err) {
    next(err);
  }
}

export async function getFriendsLeaderboard(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    // Find accepted friends
    const friendships = await prisma.friendship.findMany({
      where: {
        status: 'ACCEPTED',
        OR: [{ senderId: req.user.userId }, { receiverId: req.user.userId }]
      }
    });

    const friendUserIds = friendships.map((f) =>
      f.senderId === req.user!.userId ? f.receiverId : f.senderId
    );
    // Include current user in friends leaderboard
    friendUserIds.push(req.user.userId);

    const stats = await prisma.playerStatistics.findMany({
      where: { userId: { in: friendUserIds } },
      orderBy: { totalXp: 'desc' },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            profile: true
          }
        }
      }
    });

    const entries = stats.map((s, idx) => ({
      rank: idx + 1,
      userId: s.userId,
      username: s.user.username,
      displayName: s.user.profile?.displayName || s.user.username,
      avatar: s.user.profile?.avatar,
      level: s.level,
      totalXp: s.totalXp,
      wins: s.totalWins,
      isCurrentUser: s.userId === req.user!.userId
    }));

    res.json({ entries });
  } catch (err) {
    next(err);
  }
}
