import { Request, Response, NextFunction } from 'express';
import { prisma } from '../../lib/prisma.js';
import { completeGameSessionSchema } from '@neon-arena/validation';
import { ProgressionService } from '../../services/progressionService.js';
import { GAMES_CATALOGUE } from '@neon-arena/config';

export async function getAllGames(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { genre, multiplayer, competitive, search } = req.query;

    const dbGames = await prisma.game.findMany({
      where: {
        isActive: true,
        genre: genre ? { equals: String(genre) } : undefined,
        isMultiplayer: multiplayer !== undefined ? multiplayer === 'true' : undefined,
        isCompetitive: competitive !== undefined ? competitive === 'true' : undefined,
        OR: search
          ? [
              { title: { contains: String(search) } },
              { description: { contains: String(search) } }
            ]
          : undefined
      }
    });

    // Merge static richness (instructions, controls, tags) with db records
    const enrichedGames = dbGames.map((g) => {
      const configItem = GAMES_CATALOGUE.find((cfg) => cfg.slug === g.slug);
      return {
        ...g,
        tags: configItem?.tags || [g.genre],
        instructions: configItem?.instructions || [],
        controls: configItem?.controls || [],
        minPlayers: configItem?.minPlayers || 1,
        maxPlayers: configItem?.maxPlayers || 1
      };
    });

    res.json({ games: enrichedGames });
  } catch (err) {
    next(err);
  }
}

export async function getGameBySlug(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const { slug } = req.params as { slug: string };

    const game = await prisma.game.findUnique({
      where: { slug }
    });

    if (!game) {
      res.status(404).json({ error: `Game '${slug}' not found.` });
      return;
    }

    const configItem = GAMES_CATALOGUE.find((cfg) => cfg.slug === game.slug);

    let personalBest = 0;
    if (req.user) {
      const best = await prisma.scoreRecord.findFirst({
        where: { userId: req.user.userId, gameId: game.id },
        orderBy: { score: 'desc' }
      });
      personalBest = best?.score || 0;
    }

    // Top 5 leaderboard for this game
    const topScores = await prisma.scoreRecord.findMany({
      where: { gameId: game.id },
      orderBy: { score: 'desc' },
      take: 5,
      include: {
        user: {
          select: {
            username: true,
            profile: { select: { avatar: true, displayName: true } }
          }
        }
      }
    });

    res.json({
      game: {
        ...game,
        tags: configItem?.tags || [game.genre],
        instructions: configItem?.instructions || [],
        controls: configItem?.controls || [],
        minPlayers: configItem?.minPlayers || 1,
        maxPlayers: configItem?.maxPlayers || 1,
        personalBest,
        topScores: topScores.map((s, index) => ({
          rank: index + 1,
          score: s.score,
          achievedAt: s.achievedAt,
          username: s.user.username,
          displayName: s.user.profile?.displayName || s.user.username,
          avatar: s.user.profile?.avatar
        }))
      }
    });
  } catch (err) {
    next(err);
  }
}

export async function startGameSession(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    const { slug } = req.params as { slug: string };
    const game = await prisma.game.findUnique({ where: { slug } });
    if (!game) {
      res.status(404).json({ error: 'Game not found.' });
      return;
    }

    const session = await prisma.gameSession.create({
      data: {
        userId: req.user.userId,
        gameId: game.id,
        score: 0,
        durationSeconds: 0,
        verified: true
      }
    });

    res.status(201).json({
      sessionId: session.id,
      startedAt: session.completedAt
    });
  } catch (err) {
    next(err);
  }
}

export async function completeGameSession(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized.' });
      return;
    }

    const { slug, sessionId } = req.params as { slug: string; sessionId: string };
    const data = completeGameSessionSchema.parse(req.body);

    const game = await prisma.game.findUnique({ where: { slug } });
    if (!game) {
      res.status(404).json({ error: 'Game not found.' });
      return;
    }

    const session = await prisma.gameSession.findUnique({
      where: { id: sessionId }
    });

    if (!session || session.userId !== req.user.userId) {
      res.status(404).json({ error: 'Invalid game session.' });
      return;
    }

    // Update game session
    await prisma.gameSession.update({
      where: { id: sessionId },
      data: {
        score: data.score,
        durationSeconds: data.durationSeconds,
        metadata: data.metadata ? JSON.stringify(data.metadata) : null
      }
    });

    // Record high score if score > 0
    if (data.score > 0) {
      await prisma.scoreRecord.create({
        data: {
          userId: req.user.userId,
          gameId: game.id,
          score: data.score
        }
      });
    }

    // Run progression & quests
    const progression = await ProgressionService.processGameplayEvent({
      userId: req.user.userId,
      gameSlug: game.slug,
      score: data.score,
      durationSeconds: data.durationSeconds,
      isWin: data.score > 100, // Considered a winning benchmark for progression
      isMultiplayer: false,
      gameSessionId: session.id
    });

    res.json({
      message: 'Game session finalized successfully.',
      score: data.score,
      progression
    });
  } catch (err) {
    next(err);
  }
}
