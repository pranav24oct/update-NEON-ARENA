import { Router } from 'express';
import { getAllGames, getGameBySlug, startGameSession, completeGameSession } from './games.controller.js';
import { authenticateJwt, optionalAuth } from '../../middleware/auth.js';

const router = Router();

router.get('/', getAllGames);
router.get('/:slug', optionalAuth, getGameBySlug);
router.post('/:slug/sessions', authenticateJwt, startGameSession);
router.post('/:slug/sessions/:sessionId/complete', authenticateJwt, completeGameSession);

export default router;
