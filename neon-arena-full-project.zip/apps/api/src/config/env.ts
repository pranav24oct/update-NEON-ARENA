import dotenv from 'dotenv';
import path from 'path';

// Load .env from workspace root or current directory
dotenv.config({ path: path.resolve(process.cwd(), '.env') });
dotenv.config();

export const ENV = {
  NODE_ENV: process.env.NODE_ENV || 'development',
  PORT: parseInt(process.env.PORT || '4000', 10),
  CLIENT_URL: process.env.CLIENT_URL || 'http://localhost:5173',
  DATABASE_URL: process.env.DATABASE_URL || 'file:./dev.db',
  SQLITE_FALLBACK: process.env.SQLITE_FALLBACK === 'true' || true,
  REDIS_URL: process.env.REDIS_URL || 'redis://localhost:6379',
  JWT_ACCESS_SECRET: process.env.JWT_ACCESS_SECRET || 'neon_arena_jwt_access_super_secret_key_2026_xyz!',
  JWT_REFRESH_SECRET: process.env.JWT_REFRESH_SECRET || 'neon_arena_jwt_refresh_super_secret_key_2026_abc!',
  JWT_ACCESS_EXPIRES_IN: process.env.JWT_ACCESS_EXPIRES_IN || '15m',
  JWT_REFRESH_EXPIRES_IN: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
  COOKIE_SECRET: process.env.COOKIE_SECRET || 'neon_arena_cookie_secret_key_2026_qwe!',
  CORS_ORIGIN: process.env.CORS_ORIGIN || 'http://localhost:5173',
  ELO_INITIAL_RATING: parseInt(process.env.ELO_INITIAL_RATING || '1200', 10),
  ELO_K_FACTOR: parseInt(process.env.ELO_K_FACTOR || '32', 10)
};
