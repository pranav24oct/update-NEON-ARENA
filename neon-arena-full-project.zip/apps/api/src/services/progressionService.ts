import { prisma } from '../lib/prisma.js';
import { calculateLevelFromXp, NotificationType } from '@neon-arena/shared';

export interface RecordGameplayEventInput {
  userId: string;
  gameSlug: string;
  score: number;
  durationSeconds: number;
  isWin?: boolean;
  isMultiplayer?: boolean;
  gameSessionId?: string;
  matchId?: string;
}

export class ProgressionService {
  /**
   * Awards XP to a user with idempotency check and level-up detection.
   */
  static async awardXp(
    userId: string,
    amount: number,
    source: string,
    idempotencyKey: string,
    metadata?: { gameSessionId?: string; matchId?: string }
  ): Promise<{ newTotalXp: number; level: number; leveledUp: boolean }> {
    if (amount <= 0) {
      const stats = await prisma.playerStatistics.findUnique({ where: { userId } });
      return {
        newTotalXp: stats?.totalXp || 0,
        level: stats?.level || 1,
        leveledUp: false
      };
    }

    // Check idempotency
    const existingTx = await prisma.xPTransaction.findUnique({
      where: { idempotencyKey }
    });

    if (existingTx) {
      const stats = await prisma.playerStatistics.findUnique({ where: { userId } });
      return {
        newTotalXp: stats?.totalXp || 0,
        level: stats?.level || 1,
        leveledUp: false
      };
    }

    return await prisma.$transaction(async (tx) => {
      // Record transaction
      await tx.xPTransaction.create({
        data: {
          userId,
          amount,
          source,
          idempotencyKey,
          gameSessionId: metadata?.gameSessionId,
          matchId: metadata?.matchId
        }
      });

      // Update statistics
      let stats = await tx.playerStatistics.findUnique({ where: { userId } });
      if (!stats) {
        stats = await tx.playerStatistics.create({
          data: { userId, totalXp: 0, level: 1 }
        });
      }

      const previousLevel = stats.level;
      const newTotalXp = stats.totalXp + amount;
      const { level: newLevel } = calculateLevelFromXp(newTotalXp);
      const leveledUp = newLevel > previousLevel;

      await tx.playerStatistics.update({
        where: { userId },
        data: {
          totalXp: newTotalXp,
          level: newLevel
        }
      });

      // Send Level-up notification
      if (leveledUp) {
        await tx.notification.create({
          data: {
            userId,
            type: NotificationType.LEVEL_UP,
            title: `Level Up! Level ${newLevel}`,
            message: `Congratulations! You have reached level ${newLevel} in the Arena!`
          }
        });
      }

      return {
        newTotalXp,
        level: newLevel,
        leveledUp
      };
    });
  }

  /**
   * Process a completed gameplay session (singleplayer or multiplayer).
   * Updates stats, high score, quest progress, achievements, and awards XP.
   */
  static async processGameplayEvent(event: RecordGameplayEventInput): Promise<{
    xpAwarded: number;
    newTotalXp: number;
    level: number;
    leveledUp: boolean;
    achievementsUnlocked: string[];
  }> {
    const { userId, gameSlug, score, isWin = false, isMultiplayer = false, gameSessionId, matchId } = event;

    // 1. Calculate base XP: base 50 XP + score based (1 XP per 20 points, max 100) + win bonus (75 XP)
    let xpToAward = 50;
    if (score > 0) {
      xpToAward += Math.min(100, Math.floor(score / 20));
    }
    if (isWin) {
      xpToAward += 75;
    }
    if (isMultiplayer) {
      xpToAward += 50;
    }

    const idempotencyKey = gameSessionId
      ? `session_${gameSessionId}`
      : matchId
      ? `match_${matchId}_${userId}`
      : `gameplay_${userId}_${Date.now()}`;

    // 2. Award XP
    const xpResult = await this.awardXp(userId, xpToAward, 'GAMEPLAY_EVENT', idempotencyKey, {
      gameSessionId,
      matchId
    });

    // 3. Update Player Statistics (Games played, Wins/Losses, Streak)
    const currentStats = await prisma.playerStatistics.findUnique({ where: { userId } });
    const currentStreak = isWin ? (currentStats?.currentStreak || 0) + 1 : 0;
    const bestStreak = Math.max(currentStreak, currentStats?.bestStreak || 0);

    const updatedStats = await prisma.playerStatistics.upsert({
      where: { userId },
      update: {
        totalGamesPlayed: { increment: 1 },
        totalWins: isWin ? { increment: 1 } : undefined,
        totalLosses: !isWin && !isMultiplayer ? undefined : !isWin ? { increment: 1 } : undefined,
        currentStreak,
        bestStreak,
        multiplayerWins: isWin && isMultiplayer ? { increment: 1 } : undefined,
        lastPlayedAt: new Date()
      },
      create: {
        userId,
        totalGamesPlayed: 1,
        totalWins: isWin ? 1 : 0,
        totalLosses: !isWin ? 1 : 0,
        currentStreak,
        bestStreak,
        multiplayerWins: isWin && isMultiplayer ? 1 : 0,
        lastPlayedAt: new Date()
      }
    });

    // 4. Update Quest Progress
    await this.updateUserQuests(userId, gameSlug, score, isWin, isMultiplayer);

    // 5. Check and Unlock Achievements
    const unlockedAchievements = await this.checkAchievements(userId, updatedStats, score);

    return {
      xpAwarded: xpToAward,
      newTotalXp: xpResult.newTotalXp,
      level: xpResult.level,
      leveledUp: xpResult.leveledUp,
      achievementsUnlocked: unlockedAchievements
    };
  }

  /**
   * Update active player quests automatically based on gameplay events
   */
  private static async updateUserQuests(
    userId: string,
    gameSlug: string,
    score: number,
    isWin: boolean,
    isMultiplayer: boolean
  ): Promise<void> {
    // Find all incomplete active quests for this user
    const playerQuests = await prisma.playerQuest.findMany({
      where: {
        userId,
        completed: false
      },
      include: {
        quest: true
      }
    });

    for (const pq of playerQuests) {
      let increment = 0;
      const q = pq.quest;

      // Filter by game if quest is game-specific
      if (q.gameSlug && q.gameSlug !== gameSlug) {
        continue;
      }

      if (q.actionType === 'PLAY_GAME') {
        increment = 1;
      } else if (q.actionType === 'WIN_MATCH' && isWin) {
        increment = 1;
      } else if (q.actionType === 'SCORE_POINTS' && score >= q.targetCount) {
        // Met or progressed score target
        increment = score;
      } else if (q.actionType === 'MULTIPLAYER_MATCH' && isMultiplayer) {
        increment = 1;
      }

      if (increment > 0) {
        const newProgress = Math.min(q.targetCount, pq.progress + increment);
        const isCompleted = newProgress >= q.targetCount;

        await prisma.playerQuest.update({
          where: { id: pq.id },
          data: {
            progress: newProgress,
            completed: isCompleted
          }
        });

        if (isCompleted) {
          await prisma.notification.create({
            data: {
              userId,
              type: NotificationType.QUEST_COMPLETED,
              title: `Quest Completed: ${q.title}!`,
              message: `You completed "${q.title}" and can now claim ${q.xpReward} XP!`
            }
          });
        }
      }
    }
  }

  /**
   * Check if user qualified for any new achievements
   */
  private static async checkAchievements(
    userId: string,
    stats: any,
    currentScore: number
  ): Promise<string[]> {
    const allAchievements = await prisma.achievement.findMany();
    const existingUnlocks = await prisma.playerAchievement.findMany({
      where: { userId },
      select: { achievementId: true }
    });
    const unlockedIds = new Set(existingUnlocks.map((u) => u.achievementId));

    const newlyUnlocked: string[] = [];

    for (const ach of allAchievements) {
      if (unlockedIds.has(ach.id)) continue;

      let qualified = false;

      switch (ach.conditionType) {
        case 'MATCHES_PLAYED':
          qualified = stats.totalGamesPlayed >= ach.threshold;
          break;
        case 'WINS':
          qualified = stats.totalWins >= ach.threshold;
          break;
        case 'MULTIPLAYER_WINS':
          qualified = stats.multiplayerWins >= ach.threshold;
          break;
        case 'STREAK':
          qualified = stats.currentStreak >= ach.threshold || stats.bestStreak >= ach.threshold;
          break;
        case 'HIGH_SCORE':
          qualified = currentScore >= ach.threshold;
          break;
      }

      if (qualified) {
        await prisma.playerAchievement.create({
          data: {
            userId,
            achievementId: ach.id
          }
        });

        // Award achievement XP
        await this.awardXp(
          userId,
          ach.xpReward,
          'ACHIEVEMENT',
          `ach_${ach.id}_${userId}`
        );

        await prisma.notification.create({
          data: {
            userId,
            type: NotificationType.ACHIEVEMENT_UNLOCKED,
            title: `Achievement Unlocked: ${ach.name}!`,
            message: `${ach.description} (+${ach.xpReward} XP)`
          }
        });

        newlyUnlocked.push(ach.name);
      }
    }

    return newlyUnlocked;
  }
}
