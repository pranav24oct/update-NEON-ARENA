import express, { Express, Request, Response } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import { ENV } from './config/env.js';
import { standardRateLimiter } from './middleware/rateLimiter.js';
import { errorHandler } from './middleware/errorHandler.js';

// Route modules
import authRoutes from './modules/auth/auth.routes.js';
import playerRoutes from './modules/players/players.routes.js';
import gameRoutes from './modules/games/games.routes.js';
import questRoutes from './modules/quests/quests.routes.js';
import challengeRoutes from './modules/challenges/challenges.routes.js';
import leaderboardRoutes from './modules/leaderboards/leaderboards.routes.js';
import matchRoutes from './modules/matches/matches.routes.js';
import tournamentRoutes from './modules/tournaments/tournaments.routes.js';
import friendRoutes from './modules/friends/friends.routes.js';
import notificationRoutes from './modules/notifications/notifications.routes.js';
import adminRoutes from './modules/admin/admin.routes.js';

export function createApp(): Express {
  const app = express();

  // Security Headers
  app.use(
    helmet({
      contentSecurityPolicy: false, // Disabled for dev client asset flexibility
      crossOriginEmbedderPolicy: false
    })
  );

  // CORS Configuration
  app.use(
    cors({
      origin: [ENV.CLIENT_URL, 'http://localhost:5173', 'http://localhost:3000'],
      credentials: true,
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization']
    })
  );

  // Parsers & Rate limiting
  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ extended: true, limit: '2mb' }));
  app.use(cookieParser(ENV.COOKIE_SECRET));
  app.use(standardRateLimiter);

  // Health check endpoint
  app.get('/health', (req: Request, res: Response) => {
    res.json({
      status: 'UP',
      timestamp: new Date().toISOString(),
      service: 'NEON ARENA API',
      version: '1.0.0'
    });
  });

  // OpenAPI Documentation Spec Endpoint
  app.get('/api/v1/docs', (req: Request, res: Response) => {
    res.json({
      openapi: '3.0.0',
      info: {
        title: 'NEON ARENA REST API',
        version: '1.0.0',
        description: 'REST API for the NEON ARENA competitive gaming platform.'
      },
      servers: [{ url: `http://localhost:${ENV.PORT}/api/v1` }],
      paths: {
        '/auth/register': { post: { summary: 'Register a new player account' } },
        '/auth/login': { post: { summary: 'Authenticate user and issue tokens' } },
        '/auth/me': { get: { summary: 'Retrieve current authenticated player' } },
        '/games': { get: { summary: 'List all arcade games with filters' } },
        '/games/{slug}': { get: { summary: 'Get game details and personal best' } },
        '/quests/me': { get: { summary: 'Get current user assigned quests' } },
        '/quests/{questId}/claim': { post: { summary: 'Claim verified quest reward' } },
        '/leaderboards/global': { get: { summary: 'Top players by total XP' } },
        '/leaderboards/competitive': { get: { summary: 'Top players by competitive Elo rating' } },
        '/tournaments': { get: { summary: 'List tournaments' } },
        '/admin/overview': { get: { summary: 'Admin metrics and system health' } }
      }
    });
  });

  // Mount API v1 Routes
  app.use('/api/v1/auth', authRoutes);
  app.use('/api/v1/players', playerRoutes);
  app.use('/api/v1/games', gameRoutes);
  app.use('/api/v1/quests', questRoutes);
  app.use('/api/v1/challenges', challengeRoutes);
  app.use('/api/v1/leaderboards', leaderboardRoutes);
  app.use('/api/v1/matches', matchRoutes);
  app.use('/api/v1/tournaments', tournamentRoutes);
  app.use('/api/v1/friends', friendRoutes);
  app.use('/api/v1/notifications', notificationRoutes);
  app.use('/api/v1/admin', adminRoutes);

  // 404 Handler
  app.use((req: Request, res: Response) => {
    res.status(404).json({ error: `Cannot ${req.method} ${req.path}` });
  });

  // Global Centralized Error Handler
  app.use(errorHandler);

  return app;
}
