import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { ENV } from '../config/env.js';
import { prisma } from '../lib/prisma.js';
import { UserRole } from '@neon-arena/shared';

export interface AuthUserPayload {
  userId: string;
  username: string;
  role: string;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUserPayload;
    }
  }
}

export async function authenticateJwt(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    let token: string | undefined;

    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.split(' ')[1];
    } else if (req.cookies && req.cookies['access_token']) {
      token = req.cookies['access_token'];
    }

    if (!token) {
      res.status(401).json({ error: 'Authentication required. No token provided.' });
      return;
    }

    const decoded = jwt.verify(token, ENV.JWT_ACCESS_SECRET) as AuthUserPayload;

    // Verify user exists and is not banned
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: { id: true, username: true, role: true, isBanned: true, banReason: true }
    });

    if (!user) {
      res.status(401).json({ error: 'User account no longer exists.' });
      return;
    }

    if (user.isBanned) {
      res.status(403).json({ error: `Account suspended: ${user.banReason || 'Violation of terms.'}` });
      return;
    }

    req.user = {
      userId: user.id,
      username: user.username,
      role: user.role
    };

    next();
  } catch (err: any) {
    res.status(401).json({ error: 'Invalid or expired authentication token.' });
  }
}

export async function optionalAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    let token: string | undefined;

    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.split(' ')[1];
    } else if (req.cookies && req.cookies['access_token']) {
      token = req.cookies['access_token'];
    }

    if (token) {
      const decoded = jwt.verify(token, ENV.JWT_ACCESS_SECRET) as AuthUserPayload;
      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        select: { id: true, username: true, role: true, isBanned: true }
      });

      if (user && !user.isBanned) {
        req.user = {
          userId: user.id,
          username: user.username,
          role: user.role
        };
      }
    }
  } catch {
    // Ignore invalid token in optional auth
  }
  next();
}

export function requireRole(allowedRoles: UserRole[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }

    if (!allowedRoles.includes(req.user.role as UserRole)) {
      res.status(403).json({ error: 'Forbidden: Insufficient privileges.' });
      return;
    }

    next();
  };
}
