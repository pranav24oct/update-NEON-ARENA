import http from 'http';
import { createApp } from './app.js';
import { initSocketServer } from './sockets/socketServer.js';
import { ENV } from './config/env.js';
import { prisma } from './lib/prisma.js';

async function bootstrap() {
  const app = createApp();
  const server = http.createServer(app);

  // Initialize Socket.IO
  initSocketServer(server);

  server.listen(ENV.PORT, () => {
    console.log(`\n======================================================`);
    console.log(`🕹️  NEON ARENA API Server running on port ${ENV.PORT}`);
    console.log(`📡 REST API: http://localhost:${ENV.PORT}/api/v1`);
    console.log(`📖 OpenAPI Spec: http://localhost:${ENV.PORT}/api/v1/docs`);
    console.log(`❤️  Health Check: http://localhost:${ENV.PORT}/health`);
    console.log(`⚡ WebSocket Server: Ready for multiplayer & presence`);
    console.log(`======================================================\n`);
  });

  // Graceful shutdown
  const shutdown = async () => {
    console.log('🛑 Gracefully shutting down NEON ARENA API...');
    server.close(async () => {
      await prisma.$disconnect();
      console.log('✅ Prisma client disconnected. Server closed.');
      process.exit(0);
    });
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

bootstrap().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
