import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { prisma } from '../src/lib/prisma.js';
import { gameRoomManager } from '../src/sockets/gameRoomManager.js';

const app = createApp();

describe('End-to-End Full Competitive Gaming Scenario', () => {
  const timestamp = Date.now();
  const player1User = `p1_${timestamp}`;
  const player2User = `p2_${timestamp}`;
  const password = 'Password123!';

  let token1: string;
  let token2: string;
  let userId1: string;
  let userId2: string;
  let activeSessionId: string;
  let targetTournamentId: string;

  it('Step 1 & 2: Register two player accounts and log in', async () => {
    // Register Player 1
    const reg1 = await request(app)
      .post('/api/v1/auth/register')
      .send({
        username: player1User,
        email: `${player1User}@test.com`,
        password
      });

    expect(reg1.status).toBe(201);
    expect(reg1.body.accessToken).toBeDefined();
    token1 = reg1.body.accessToken;
    userId1 = reg1.body.user.id;

    // Register Player 2
    const reg2 = await request(app)
      .post('/api/v1/auth/register')
      .send({
        username: player2User,
        email: `${player2User}@test.com`,
        password
      });

    expect(reg2.status).toBe(201);
    expect(reg2.body.accessToken).toBeDefined();
    token2 = reg2.body.accessToken;
    userId2 = reg2.body.user.id;

    // Verify Login Player 1
    const login1 = await request(app)
      .post('/api/v1/auth/login')
      .send({
        identifier: player1User,
        password
      });
    expect(login1.status).toBe(200);
  });

  it('Step 3 & 4: Start a game session and save a verified score', async () => {
    // Start session in Snake
    const startRes = await request(app)
      .post('/api/v1/games/snake/sessions')
      .set('Authorization', `Bearer ${token1}`);

    expect(startRes.status).toBe(201);
    expect(startRes.body.sessionId).toBeDefined();
    activeSessionId = startRes.body.sessionId;

    // Complete session with score 250
    const completeRes = await request(app)
      .post(`/api/v1/games/snake/sessions/${activeSessionId}/complete`)
      .set('Authorization', `Bearer ${token1}`)
      .send({
        score: 250,
        durationSeconds: 45
      });

    expect(completeRes.status).toBe(200);
    expect(completeRes.body.score).toBe(250);
    expect(completeRes.body.progression.xpAwarded).toBeGreaterThan(0);
  });

  it('Step 5 & 6: Verify quest progress, claim reward, and check XP updates', async () => {
    // Get Player 1 quests
    const questsRes = await request(app)
      .get('/api/v1/quests/me')
      .set('Authorization', `Bearer ${token1}`);

    expect(questsRes.status).toBe(200);
    const quests = questsRes.body.quests;
    expect(quests.length).toBeGreaterThan(0);

    // Look for completed quest
    const completedQuest = quests.find((q: any) => q.completed && !q.claimed);
    if (completedQuest) {
      const claimRes = await request(app)
        .post(`/api/v1/quests/${completedQuest.id}/claim`)
        .set('Authorization', `Bearer ${token1}`);

      expect(claimRes.status).toBe(200);
      expect(claimRes.body.xpAwarded).toBe(completedQuest.xpReward);

      // Verify cannot claim twice (Idempotency / anti-duplication)
      const duplicateClaim = await request(app)
        .post(`/api/v1/quests/${completedQuest.id}/claim`)
        .set('Authorization', `Bearer ${token1}`);

      expect(duplicateClaim.status).toBe(400);
    }

    // Verify Player 1 Profile & Total XP
    const profileRes = await request(app).get(`/api/v1/players/${player1User}`);
    expect(profileRes.status).toBe(200);
    expect(profileRes.body.player.statistics.totalXp).toBeGreaterThan(0);
    expect(profileRes.body.player.statistics.totalGamesPlayed).toBeGreaterThanOrEqual(1);
  });

  it('Step 7, 8 & 9: Real-time match between 2 players, verified result, and leaderboard update', async () => {
    // Create room with Player 1
    const room = gameRoomManager.createRoom(
      {
        userId: userId1,
        username: player1User,
        socketId: 'mock_socket_1',
        rating: 1200
      },
      false
    );

    expect(room.players.length).toBe(1);

    // Player 2 Joins Room
    const joinResult = await gameRoomManager.joinRoom(room.roomId, {
      userId: userId2,
      username: player2User,
      socketId: 'mock_socket_2',
      rating: 1200
    });

    expect(joinResult.room?.status).toBe('PLAYING');
    expect(joinResult.room?.players.length).toBe(2);

    const activeRoom = joinResult.room!;
    const playerX = activeRoom.players.find((p) => p.marker === 'X')!;
    const playerO = activeRoom.players.find((p) => p.marker === 'O')!;

    // Play legal sequence where X wins top row: (0, 3, 1, 4, 2)
    await gameRoomManager.makeMove(activeRoom.roomId, playerX.userId, 0); // X moves 0
    await gameRoomManager.makeMove(activeRoom.roomId, playerO.userId, 3); // O moves 3
    await gameRoomManager.makeMove(activeRoom.roomId, playerX.userId, 1); // X moves 1
    await gameRoomManager.makeMove(activeRoom.roomId, playerO.userId, 4); // O moves 4
    const winMove = await gameRoomManager.makeMove(activeRoom.roomId, playerX.userId, 2); // X moves 2 (WIN!)

    expect(winMove.isGameOver).toBe(true);
    expect(activeRoom.status).toBe('FINISHED');
    expect(activeRoom.winner).toBe('X');
    expect(activeRoom.winningLine).toEqual([0, 1, 2]);

    // Check Player 1 match history via API
    const matchHistoryRes = await request(app)
      .get('/api/v1/matches/history')
      .set('Authorization', `Bearer ${token1}`);

    expect(matchHistoryRes.status).toBe(200);
    expect(matchHistoryRes.body.matches.length).toBeGreaterThan(0);

    // Verify Competitive Leaderboard includes ratings
    const compLb = await request(app).get('/api/v1/leaderboards/competitive');
    expect(compLb.status).toBe(200);
    expect(compLb.body.entries.length).toBeGreaterThan(0);
  });

  it('Step 10 & 11: Register for tournament and verify bracket progression', async () => {
    // Find a tournament in registration status
    const tourneysRes = await request(app).get('/api/v1/tournaments');
    expect(tourneysRes.status).toBe(200);
    expect(tourneysRes.body.tournaments.length).toBeGreaterThan(0);

    const tourney = tourneysRes.body.tournaments[0];
    targetTournamentId = tourney.id;

    // Register Player 1 for Tournament
    const regTourney = await request(app)
      .post(`/api/v1/tournaments/${targetTournamentId}/register`)
      .set('Authorization', `Bearer ${token1}`);

    expect([201, 400]).toContain(regTourney.status);

    // Inspect Bracket Tree
    const bracketRes = await request(app).get(`/api/v1/tournaments/${targetTournamentId}/bracket`);
    expect(bracketRes.status).toBe(200);
    expect(bracketRes.body.rounds.length).toBeGreaterThanOrEqual(1);
  });
});
