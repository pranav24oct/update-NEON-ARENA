import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';

const app = createApp();

describe('API Authentication & Authorization Tests', () => {
  it('GET /health returns status UP', async () => {
    const res = await request(app).get('/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('UP');
  });

  it('GET /api/v1/games returns seeded games catalog', async () => {
    const res = await request(app).get('/api/v1/games');
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body.games)).toBe(true);
    expect(res.body.games.length).toBeGreaterThanOrEqual(6);
  });

  it('POST /api/v1/auth/register rejects invalid inputs via Zod', async () => {
    const res = await request(app)
      .post('/api/v1/auth/register')
      .send({ username: 'ab', email: 'invalid-email', password: '123' });

    expect(res.status).toBe(400);
    expect(res.body.error).toBe('Validation failed');
  });

  it('POST /api/v1/auth/login authenticates demo admin user', async () => {
    const res = await request(app)
      .post('/api/v1/auth/login')
      .send({ identifier: 'admin', password: 'Admin2026!' });

    expect(res.status).toBe(200);
    expect(res.body.accessToken).toBeDefined();
    expect(res.body.user.role).toBe('ADMIN');
  });

  it('GET /api/v1/admin/overview blocks unauthenticated requests with 401', async () => {
    const res = await request(app).get('/api/v1/admin/overview');
    expect(res.status).toBe(401);
  });

  it('GET /api/v1/admin/overview blocks regular player role with 403 Forbidden', async () => {
    // Log in as player
    const loginRes = await request(app)
      .post('/api/v1/auth/login')
      .send({ identifier: 'cyber_ninja', password: 'NeonArena2026!' });

    const token = loginRes.body.accessToken;

    const res = await request(app)
      .get('/api/v1/admin/overview')
      .set('Authorization', `Bearer ${token}`);

    expect(res.status).toBe(403);
  });

  it('GET /api/v1/admin/overview allows ADMIN role', async () => {
    const loginRes = await request(app)
      .post('/api/v1/auth/login')
      .send({ identifier: 'admin', password: 'Admin2026!' });

    const token = loginRes.body.accessToken;

    const res = await request(app)
      .get('/api/v1/admin/overview')
      .set('Authorization', `Bearer ${token}`);

    expect(res.status).toBe(200);
    expect(res.body.metrics).toBeDefined();
    expect(res.body.systemHealth).toBeDefined();
  });
});
