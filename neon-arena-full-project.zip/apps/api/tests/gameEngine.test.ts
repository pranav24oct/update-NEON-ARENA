import { describe, it, expect } from 'vitest';
import {
  checkTTTResult,
  getTTTMinimaxMove,
  createInitialSnakeState,
  stepSnake,
  createEmptyBoard2048,
  addRandomTile2048,
  move2048,
  checkFlapCollision,
  lineIntersectsCircle,
  calculateTrajectory
} from '@neon-arena/game-engine';

describe('1. Tic-Tac-Toe Game Engine', () => {
  it('detects a horizontal winning line for X', () => {
    const board = ['X', 'X', 'X', null, 'O', null, 'O', null, null] as any;
    const res = checkTTTResult(board);
    expect(res.winner).toBe('X');
    expect(res.isGameOver).toBe(true);
    expect(res.winningLine).toEqual([0, 1, 2]);
  });

  it('detects a diagonal winning line for O', () => {
    const board = ['O', 'X', null, 'X', 'O', null, null, null, 'O'] as any;
    const res = checkTTTResult(board);
    expect(res.winner).toBe('O');
    expect(res.isGameOver).toBe(true);
    expect(res.winningLine).toEqual([0, 4, 8]);
  });

  it('detects a draw when board is full with no winner', () => {
    const board = ['X', 'O', 'X', 'X', 'O', 'O', 'O', 'X', 'X'] as any;
    const res = checkTTTResult(board);
    expect(res.winner).toBeNull();
    expect(res.isDraw).toBe(true);
    expect(res.isGameOver).toBe(true);
  });

  it('minimax AI blocks an immediate winning move by human', () => {
    // Human is 'X', AI is 'O'. Human has 0, 1. AI should pick 2 to block!
    const board = ['X', 'X', null, 'O', null, null, null, null, null] as any;
    const move = getTTTMinimaxMove(board, 'O', 'HARD');
    expect(move).toBe(2);
  });
});

describe('2. Snake Game Engine', () => {
  it('steps snake forward in current direction', () => {
    const initial = createInitialSnakeState(20);
    const stepped = stepSnake(initial);
    expect(stepped.snake[0].x).toBe(initial.snake[0].x + 1);
    expect(stepped.isGameOver).toBe(false);
  });

  it('detects wall collision', () => {
    const state = createInitialSnakeState(20);
    state.snake[0] = { x: 19, y: 10 };
    state.direction = 'RIGHT';
    state.nextDirection = 'RIGHT';

    const stepped = stepSnake(state);
    expect(stepped.isGameOver).toBe(true);
  });
});

describe('3. 2048 Game Engine', () => {
  it('slides and merges identical adjacent tiles', () => {
    const board = [
      [2, 2, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0]
    ];
    const { board: newBoard, scoreGained, moved } = move2048(board, 'LEFT');
    expect(moved).toBe(true);
    expect(newBoard[0][0]).toBe(4);
    expect(newBoard[0][1]).toBe(0);
    expect(scoreGained).toBe(4);
  });
});

describe('4. Flappy Collision Engine', () => {
  it('detects collision when drone hits a pipe barrier', () => {
    const pipes = [{ x: 100, gapY: 150, gapHeight: 100, passed: false }];
    // Drone is at x: 110, y: 100 (inside top barrier)
    const collided = checkFlapCollision(100, 12, 110, pipes, 40, 500);
    expect(collided).toBe(true);
  });

  it('allows safe clearance through the gap', () => {
    const pipes = [{ x: 100, gapY: 150, gapHeight: 100, passed: false }];
    // Drone is at x: 110, y: 200 (inside the 150-250 open gap)
    const collided = checkFlapCollision(200, 12, 110, pipes, 40, 500);
    expect(collided).toBe(false);
  });
});

describe('5. Fruit Slice Line Intersection', () => {
  it('detects when blade swipe crosses through a target circle', () => {
    const p1 = { x: 0, y: 100 };
    const p2 = { x: 200, y: 100 };
    const circle = { x: 100, y: 100 };
    const radius = 20;

    const hit = lineIntersectsCircle(p1, p2, circle, radius);
    expect(hit).toBe(true);
  });

  it('returns false when swipe misses target', () => {
    const p1 = { x: 0, y: 50 };
    const p2 = { x: 200, y: 50 };
    const circle = { x: 100, y: 150 };
    const radius = 20;

    const hit = lineIntersectsCircle(p1, p2, circle, radius);
    expect(hit).toBe(false);
  });
});

describe('6. Orbit Strike Slingshot Trajectory', () => {
  it('calculates parabolic arc points with gravity', () => {
    const origin = { x: 50, y: 300 };
    const drag = { x: 20, y: 330 }; // Pull down-left => launch up-right
    const trajectory = calculateTrajectory(origin, drag, 0.25, 20, 0.35);

    expect(trajectory.length).toBe(20);
    expect(trajectory[0]).toEqual(origin);
    // x should be increasing
    expect(trajectory[5].x).toBeGreaterThan(trajectory[0].x);
  });
});
