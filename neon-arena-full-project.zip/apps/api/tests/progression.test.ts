import { describe, it, expect } from 'vitest';
import {
  calculateLevelFromXp,
  getXpRequiredForLevel,
  calculateEloChange,
  getTierFromRating,
  CompetitiveTier
} from '@neon-arena/shared';

describe('Player Progression & Level Engine', () => {
  it('correctly calculates level 1 for 0 XP', () => {
    const res = calculateLevelFromXp(0);
    expect(res.level).toBe(1);
    expect(res.currentLevelXp).toBe(0);
    expect(res.progressPercent).toBe(0);
  });

  it('levels up when total XP exceeds level threshold', () => {
    const requiredForLvl1 = getXpRequiredForLevel(1); // 100
    const res = calculateLevelFromXp(requiredForLvl1 + 50);
    expect(res.level).toBe(2);
    expect(res.currentLevelXp).toBe(50);
    expect(res.progressPercent).toBeGreaterThan(0);
  });
});

describe('Competitive Elo Algorithm', () => {
  it('awards rating points to winner and deducts from loser', () => {
    const playerRating = 1200;
    const opponentRating = 1200;

    const winResult = calculateEloChange(playerRating, opponentRating, 1, 32);
    const lossResult = calculateEloChange(opponentRating, playerRating, 0, 32);

    expect(winResult.change).toBe(16);
    expect(winResult.newRating).toBe(1216);

    expect(lossResult.change).toBe(-16);
    expect(lossResult.newRating).toBe(1184);
  });

  it('awards larger gain when defeating a significantly higher rated opponent (upset)', () => {
    const underdog = 1100;
    const favored = 1400;

    const underdogWin = calculateEloChange(underdog, favored, 1, 32);
    expect(underdogWin.change).toBeGreaterThan(20);
  });

  it('correctly maps ratings to competitive division tiers', () => {
    expect(getTierFromRating(1050)).toBe(CompetitiveTier.BRONZE);
    expect(getTierFromRating(1250)).toBe(CompetitiveTier.SILVER);
    expect(getTierFromRating(1450)).toBe(CompetitiveTier.GOLD);
    expect(getTierFromRating(1650)).toBe(CompetitiveTier.PLATINUM);
    expect(getTierFromRating(1850)).toBe(CompetitiveTier.DIAMOND);
    expect(getTierFromRating(2050)).toBe(CompetitiveTier.MASTER);
    expect(getTierFromRating(2350)).toBe(CompetitiveTier.CHAMPION);
  });
});
