import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';
import { GAMES_CATALOGUE, INITIAL_QUESTS, ACHIEVEMENTS } from '../packages/config/src/index.js';
import { GameSlug } from '../packages/shared/src/index.js';

const prisma = new PrismaClient();

async function main() {
  console.log('🚀 Seeding NEON ARENA database...');

  // 1. Seed Games
  for (const gameDef of GAMES_CATALOGUE) {
    await prisma.game.upsert({
      where: { slug: gameDef.slug },
      update: {
        title: gameDef.title,
        description: gameDef.description,
        genre: gameDef.genre,
        thumbnail: gameDef.thumbnail,
        banner: gameDef.banner,
        isMultiplayer: gameDef.isMultiplayer,
        isCompetitive: gameDef.isCompetitive
      },
      create: {
        slug: gameDef.slug,
        title: gameDef.title,
        description: gameDef.description,
        genre: gameDef.genre,
        thumbnail: gameDef.thumbnail,
        banner: gameDef.banner,
        isMultiplayer: gameDef.isMultiplayer,
        isCompetitive: gameDef.isCompetitive
      }
    });
  }
  console.log(`✅ Seeded ${GAMES_CATALOGUE.length} games.`);

  // 2. Seed Quests
  for (const quest of INITIAL_QUESTS) {
    await prisma.questTemplate.upsert({
      where: { slug: quest.id },
      update: {
        title: quest.title,
        description: quest.description,
        type: quest.type,
        difficulty: quest.difficulty,
        targetCount: quest.targetCount,
        xpReward: quest.xpReward,
        actionType: quest.actionType,
        gameSlug: quest.gameSlug
      },
      create: {
        slug: quest.id,
        title: quest.title,
        description: quest.description,
        type: quest.type,
        difficulty: quest.difficulty,
        targetCount: quest.targetCount,
        xpReward: quest.xpReward,
        actionType: quest.actionType,
        gameSlug: quest.gameSlug
      }
    });
  }
  console.log(`✅ Seeded ${INITIAL_QUESTS.length} quest templates.`);

  // 3. Seed Achievements
  for (const ach of ACHIEVEMENTS) {
    await prisma.achievement.upsert({
      where: { slug: ach.id },
      update: {
        name: ach.name,
        description: ach.description,
        icon: ach.icon,
        rarity: ach.rarity,
        xpReward: ach.xpReward,
        conditionType: ach.conditionType,
        threshold: ach.threshold
      },
      create: {
        slug: ach.id,
        name: ach.name,
        description: ach.description,
        icon: ach.icon,
        rarity: ach.rarity,
        xpReward: ach.xpReward,
        conditionType: ach.conditionType,
        threshold: ach.threshold
      }
    });
  }
  console.log(`✅ Seeded ${ACHIEVEMENTS.length} achievements.`);

  // 4. Seed Season 1
  const season1 = await prisma.season.upsert({
    where: { number: 1 },
    update: {
      title: 'Season 1: Cyber Genesis',
      isActive: true
    },
    create: {
      number: 1,
      title: 'Season 1: Cyber Genesis',
      startDate: new Date('2026-01-01'),
      endDate: new Date('2026-12-31'),
      isActive: true
    }
  });
  console.log('✅ Seeded Season 1.');

  // 5. Seed Users
  const passwordHash = await bcrypt.hash('NeonArena2026!', 10);
  const adminPasswordHash = await bcrypt.hash('Admin2026!', 10);

  const demoUsers = [
    {
      username: 'admin',
      email: 'admin@neonarena.com',
      passwordHash: adminPasswordHash,
      role: 'ADMIN',
      displayName: 'System Admin',
      bio: 'Platform Administrator & Cyber Overseer',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
      totalXp: 8500,
      level: 14,
      totalGames: 120,
      totalWins: 85,
      totalLosses: 30,
      streak: 5,
      rating: 1850,
      tier: 'DIAMOND'
    },
    {
      username: 'cyber_ninja',
      email: 'ninja@neonarena.com',
      passwordHash,
      role: 'PLAYER',
      displayName: 'Cyber Ninja',
      bio: 'Fast reflexes, sharper blades. Dominating the leaderboards.',
      avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80',
      totalXp: 6200,
      level: 11,
      totalGames: 95,
      totalWins: 65,
      totalLosses: 28,
      streak: 4,
      rating: 1680,
      tier: 'PLATINUM'
    },
    {
      username: 'pixel_queen',
      email: 'queen@neonarena.com',
      passwordHash,
      role: 'PLAYER',
      displayName: 'Pixel Queen',
      bio: 'Puzzle architect. 2048 master.',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
      totalXp: 4900,
      level: 9,
      totalGames: 70,
      totalWins: 48,
      totalLosses: 20,
      streak: 2,
      rating: 1520,
      tier: 'GOLD'
    },
    {
      username: 'neon_reaper',
      email: 'reaper@neonarena.com',
      passwordHash,
      role: 'PLAYER',
      displayName: 'Neon Reaper',
      bio: 'Unstoppable in Tic-Tac-Toe duels. Challenge me if you dare.',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
      totalXp: 12400,
      level: 18,
      totalGames: 180,
      totalWins: 140,
      totalLosses: 35,
      streak: 9,
      rating: 2150,
      tier: 'MASTER'
    },
    {
      username: 'retro_samurai',
      email: 'samurai@neonarena.com',
      passwordHash,
      role: 'PLAYER',
      displayName: 'Retro Samurai',
      bio: 'Mastering the blade in Cyber Slice.',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
      totalXp: 3100,
      level: 6,
      totalGames: 45,
      totalWins: 28,
      totalLosses: 15,
      streak: 1,
      rating: 1350,
      tier: 'SILVER'
    }
  ];

  const tttGame = await prisma.game.findUnique({ where: { slug: GameSlug.TIC_TAC_TOE } });
  const snakeGame = await prisma.game.findUnique({ where: { slug: GameSlug.SNAKE } });
  const sliceGame = await prisma.game.findUnique({ where: { slug: GameSlug.CYBER_SLICE } });
  const puzzleGame = await prisma.game.findUnique({ where: { slug: GameSlug.GAME_2048 } });

  const createdUserRecords: Record<string, any> = {};

  for (const u of demoUsers) {
    const user = await prisma.user.upsert({
      where: { username: u.username },
      update: {
        role: u.role,
        isEmailVerified: true
      },
      create: {
        username: u.username,
        email: u.email,
        passwordHash: u.passwordHash,
        role: u.role,
        isEmailVerified: true
      }
    });

    createdUserRecords[u.username] = user;

    await prisma.playerProfile.upsert({
      where: { userId: user.id },
      update: {
        displayName: u.displayName,
        bio: u.bio,
        avatar: u.avatar
      },
      create: {
        userId: user.id,
        displayName: u.displayName,
        bio: u.bio,
        avatar: u.avatar
      }
    });

    await prisma.playerStatistics.upsert({
      where: { userId: user.id },
      update: {
        totalXp: u.totalXp,
        level: u.level,
        totalGamesPlayed: u.totalGames,
        totalWins: u.totalWins,
        totalLosses: u.totalLosses,
        currentStreak: u.streak,
        bestStreak: Math.max(u.streak, 5),
        multiplayerWins: Math.floor(u.totalWins * 0.6)
      },
      create: {
        userId: user.id,
        totalXp: u.totalXp,
        level: u.level,
        totalGamesPlayed: u.totalGames,
        totalWins: u.totalWins,
        totalLosses: u.totalLosses,
        currentStreak: u.streak,
        bestStreak: Math.max(u.streak, 5),
        multiplayerWins: Math.floor(u.totalWins * 0.6)
      }
    });

    // Rating for Tic-Tac-Toe
    if (tttGame) {
      await prisma.playerRating.upsert({
        where: {
          userId_gameId: {
            userId: user.id,
            gameId: tttGame.id
          }
        },
        update: {
          rating: u.rating,
          tier: u.tier,
          peakRating: u.rating + 50,
          matchesCount: u.totalGames
        },
        create: {
          userId: user.id,
          gameId: tttGame.id,
          seasonId: season1.id,
          rating: u.rating,
          tier: u.tier,
          peakRating: u.rating + 50,
          matchesCount: u.totalGames
        }
      });
    }

    // Seed some score records
    if (snakeGame) {
      await prisma.scoreRecord.create({
        data: {
          userId: user.id,
          gameId: snakeGame.id,
          score: Math.floor(Math.random() * 800) + 200
        }
      });
    }

    if (sliceGame) {
      await prisma.scoreRecord.create({
        data: {
          userId: user.id,
          gameId: sliceGame.id,
          score: Math.floor(Math.random() * 1200) + 400
        }
      });
    }
  }

  // 6. Seed Friendships between demo users
  if (createdUserRecords['cyber_ninja'] && createdUserRecords['pixel_queen']) {
    await prisma.friendship.upsert({
      where: {
        senderId_receiverId: {
          senderId: createdUserRecords['cyber_ninja'].id,
          receiverId: createdUserRecords['pixel_queen'].id
        }
      },
      update: { status: 'ACCEPTED' },
      create: {
        senderId: createdUserRecords['cyber_ninja'].id,
        receiverId: createdUserRecords['pixel_queen'].id,
        status: 'ACCEPTED'
      }
    });
  }

  if (createdUserRecords['cyber_ninja'] && createdUserRecords['neon_reaper']) {
    await prisma.friendship.upsert({
      where: {
        senderId_receiverId: {
          senderId: createdUserRecords['neon_reaper'].id,
          receiverId: createdUserRecords['cyber_ninja'].id
        }
      },
      update: { status: 'ACCEPTED' },
      create: {
        senderId: createdUserRecords['neon_reaper'].id,
        receiverId: createdUserRecords['cyber_ninja'].id,
        status: 'ACCEPTED'
      }
    });
  }

  // 7. Seed Tournament
  if (tttGame && createdUserRecords['admin']) {
    const existingTourney = await prisma.tournament.findFirst({
      where: { title: 'Neon Blitz Tic-Tac-Toe Invitational' }
    });

    if (!existingTourney) {
      const tourney = await prisma.tournament.create({
        data: {
          title: 'Neon Blitz Tic-Tac-Toe Invitational',
          description: 'Official Season 1 8-player bracket showdown. Top gladiators duel for the Cyber Crown and 2,500 XP.',
          gameId: tttGame.id,
          status: 'REGISTRATION',
          maxParticipants: 8,
          startDate: new Date(Date.now() + 86400000 * 2), // in 2 days
          registrationDeadline: new Date(Date.now() + 86400000), // in 1 day
          xpReward: 2500
        }
      });

      // Register 3 participants
      for (const uname of ['cyber_ninja', 'pixel_queen', 'neon_reaper']) {
        if (createdUserRecords[uname]) {
          await prisma.tournamentParticipant.create({
            data: {
              tournamentId: tourney.id,
              userId: createdUserRecords[uname].id
            }
          });
        }
      }
    }
  }

  console.log('🌟 Database seed completed successfully!');
}

main()
  .catch((e) => {
    console.error('❌ Error during seeding:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
