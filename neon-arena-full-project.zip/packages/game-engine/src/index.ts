// NEON ARENA - Pure Game Engine Logic & Physics

// -----------------------------------------------------------------------------
// 1. TIC-TAC-TOE ENGINE
// -----------------------------------------------------------------------------
export type TTTCell = 'X' | 'O' | null;
export type TTTBoard = TTTCell[];

export const TTT_WINNING_LINES = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
  [0, 4, 8], [2, 4, 6]             // Diagonals
];

export interface TTTGameResult {
  winner: 'X' | 'O' | null;
  isDraw: boolean;
  winningLine: number[] | null;
  isGameOver: boolean;
}

export function checkTTTResult(board: TTTBoard): TTTGameResult {
  for (const line of TTT_WINNING_LINES) {
    const [a, b, c] = line;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return {
        winner: board[a],
        isDraw: false,
        winningLine: line,
        isGameOver: true
      };
    }
  }

  const isFull = board.every((cell) => cell !== null);
  if (isFull) {
    return {
      winner: null,
      isDraw: true,
      winningLine: null,
      isGameOver: true
    };
  }

  return {
    winner: null,
    isDraw: false,
    winningLine: null,
    isGameOver: false
  };
}

export function getTTTMinimaxMove(board: TTTBoard, aiSymbol: 'X' | 'O', difficulty: 'EASY' | 'MEDIUM' | 'HARD'): number {
  const emptyIndices: number[] = [];
  board.forEach((cell, idx) => {
    if (cell === null) emptyIndices.push(idx);
  });

  if (emptyIndices.length === 0) return -1;

  // Easy: Random move
  if (difficulty === 'EASY') {
    return emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
  }

  // Medium: 50% random, 50% minimax
  if (difficulty === 'MEDIUM' && Math.random() < 0.5) {
    return emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
  }

  // Hard: Minimax optimal move
  const humanSymbol = aiSymbol === 'X' ? 'O' : 'X';

  function minimax(currentBoard: TTTBoard, isMaximizing: boolean, depth: number): number {
    const res = checkTTTResult(currentBoard);
    if (res.winner === aiSymbol) return 10 - depth;
    if (res.winner === humanSymbol) return depth - 10;
    if (res.isDraw) return 0;
    if (depth >= 6) return 0; // Performance cutoff

    if (isMaximizing) {
      let maxEval = -Infinity;
      for (let i = 0; i < currentBoard.length; i++) {
        if (currentBoard[i] === null) {
          currentBoard[i] = aiSymbol;
          const evaluation = minimax(currentBoard, false, depth + 1);
          currentBoard[i] = null;
          maxEval = Math.max(maxEval, evaluation);
        }
      }
      return maxEval;
    } else {
      let minEval = Infinity;
      for (let i = 0; i < currentBoard.length; i++) {
        if (currentBoard[i] === null) {
          currentBoard[i] = humanSymbol;
          const evaluation = minimax(currentBoard, true, depth + 1);
          currentBoard[i] = null;
          minEval = Math.min(minEval, evaluation);
        }
      }
      return minEval;
    }
  }

  let bestMove = emptyIndices[0];
  let bestScore = -Infinity;

  for (const idx of emptyIndices) {
    board[idx] = aiSymbol;
    const score = minimax(board, false, 0);
    board[idx] = null;
    if (score > bestScore) {
      bestScore = score;
      bestMove = idx;
    }
  }

  return bestMove;
}

// -----------------------------------------------------------------------------
// 2. SNAKE ENGINE
// -----------------------------------------------------------------------------
export interface Point {
  x: number;
  y: number;
}

export type SnakeDirection = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

export interface SnakeState {
  snake: Point[];
  food: Point;
  specialFood: Point | null;
  direction: SnakeDirection;
  nextDirection: SnakeDirection;
  score: number;
  isGameOver: boolean;
  gridSize: number;
}

export function createInitialSnakeState(gridSize: number = 20): SnakeState {
  const center = Math.floor(gridSize / 2);
  const snake = [
    { x: center, y: center },
    { x: center - 1, y: center },
    { x: center - 2, y: center }
  ];
  const food = spawnFood(snake, gridSize);
  return {
    snake,
    food,
    specialFood: null,
    direction: 'RIGHT',
    nextDirection: 'RIGHT',
    score: 0,
    isGameOver: false,
    gridSize
  };
}

export function spawnFood(snake: Point[], gridSize: number): Point {
  const occupied = new Set(snake.map((p) => `${p.x},${p.y}`));
  const available: Point[] = [];
  for (let x = 0; x < gridSize; x++) {
    for (let y = 0; y < gridSize; y++) {
      if (!occupied.has(`${x},${y}`)) {
        available.push({ x, y });
      }
    }
  }
  if (available.length === 0) return { x: 0, y: 0 };
  return available[Math.floor(Math.random() * available.length)];
}

export function stepSnake(state: SnakeState): SnakeState {
  if (state.isGameOver) return state;

  const currentDir = state.nextDirection;
  const head = { ...state.snake[0] };

  if (currentDir === 'UP') head.y -= 1;
  else if (currentDir === 'DOWN') head.y += 1;
  else if (currentDir === 'LEFT') head.x -= 1;
  else if (currentDir === 'RIGHT') head.x += 1;

  // Wall collision check
  if (head.x < 0 || head.x >= state.gridSize || head.y < 0 || head.y >= state.gridSize) {
    return { ...state, isGameOver: true };
  }

  // Self collision check
  for (const part of state.snake) {
    if (part.x === head.x && part.y === head.y) {
      return { ...state, isGameOver: true };
    }
  }

  const newSnake = [head, ...state.snake];
  let newScore = state.score;
  let newFood = state.food;
  let ateFood = false;

  // Ate regular food
  if (head.x === state.food.x && head.y === state.food.y) {
    newScore += 10;
    newFood = spawnFood(newSnake, state.gridSize);
    ateFood = true;
  }

  if (!ateFood) {
    newSnake.pop(); // Remove tail
  }

  return {
    ...state,
    snake: newSnake,
    food: newFood,
    direction: currentDir,
    score: newScore,
    isGameOver: false
  };
}

// -----------------------------------------------------------------------------
// 3. 2048 ENGINE
// -----------------------------------------------------------------------------
export type Board2048 = number[][];

export function createEmptyBoard2048(size: number = 4): Board2048 {
  return Array(size)
    .fill(0)
    .map(() => Array(size).fill(0));
}

export function addRandomTile2048(board: Board2048): Board2048 {
  const emptyPositions: Point[] = [];
  board.forEach((row, r) => {
    row.forEach((val, c) => {
      if (val === 0) emptyPositions.push({ x: c, y: r });
    });
  });

  if (emptyPositions.length === 0) return board;

  const chosen = emptyPositions[Math.floor(Math.random() * emptyPositions.length)];
  const value = Math.random() < 0.9 ? 2 : 4;

  const newBoard = board.map((r) => [...r]);
  newBoard[chosen.y][chosen.x] = value;
  return newBoard;
}

export function slideAndMergeRow2048(row: number[]): { newRow: number[]; scoreGained: number } {
  const filtered = row.filter((val) => val !== 0);
  const result: number[] = [];
  let scoreGained = 0;

  let i = 0;
  while (i < filtered.length) {
    if (i + 1 < filtered.length && filtered[i] === filtered[i + 1]) {
      const mergedVal = filtered[i] * 2;
      result.push(mergedVal);
      scoreGained += mergedVal;
      i += 2;
    } else {
      result.push(filtered[i]);
      i += 1;
    }
  }

  while (result.length < row.length) {
    result.push(0);
  }

  return { newRow: result, scoreGained };
}

export function move2048(
  board: Board2048,
  direction: 'LEFT' | 'RIGHT' | 'UP' | 'DOWN'
): { board: Board2048; scoreGained: number; moved: boolean } {
  const size = board.length;
  let scoreGained = 0;
  let newBoard: Board2048 = createEmptyBoard2048(size);

  if (direction === 'LEFT') {
    for (let r = 0; r < size; r++) {
      const { newRow, scoreGained: rowScore } = slideAndMergeRow2048(board[r]);
      newBoard[r] = newRow;
      scoreGained += rowScore;
    }
  } else if (direction === 'RIGHT') {
    for (let r = 0; r < size; r++) {
      const reversed = [...board[r]].reverse();
      const { newRow, scoreGained: rowScore } = slideAndMergeRow2048(reversed);
      newBoard[r] = newRow.reverse();
      scoreGained += rowScore;
    }
  } else if (direction === 'UP') {
    for (let c = 0; c < size; c++) {
      const col = [board[0][c], board[1][c], board[2][c], board[3][c]];
      const { newRow, scoreGained: colScore } = slideAndMergeRow2048(col);
      scoreGained += colScore;
      for (let r = 0; r < size; r++) {
        newBoard[r][c] = newRow[r];
      }
    }
  } else if (direction === 'DOWN') {
    for (let c = 0; c < size; c++) {
      const col = [board[3][c], board[2][c], board[1][c], board[0][c]];
      const { newRow, scoreGained: colScore } = slideAndMergeRow2048(col);
      scoreGained += colScore;
      for (let r = 0; r < size; r++) {
        newBoard[3 - r][c] = newRow[r];
      }
    }
  }

  // Check if board changed
  let moved = false;
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (newBoard[r][c] !== board[r][c]) {
        moved = true;
        break;
      }
    }
    if (moved) break;
  }

  return { board: newBoard, scoreGained, moved };
}

export function isGameOver2048(board: Board2048): boolean {
  const size = board.length;
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (board[r][c] === 0) return false;
      if (c + 1 < size && board[r][c] === board[r][c + 1]) return false;
      if (r + 1 < size && board[r][c] === board[r + 1][c]) return false;
    }
  }
  return true;
}

// -----------------------------------------------------------------------------
// 4. FLAPPY MECHANICS (NEON CYBER FLAP)
// -----------------------------------------------------------------------------
export interface FlapPipe {
  x: number;
  gapY: number;
  gapHeight: number;
  passed: boolean;
}

export function checkFlapCollision(
  droneY: number,
  droneRadius: number,
  droneX: number,
  pipes: FlapPipe[],
  pipeWidth: number,
  screenHeight: number
): boolean {
  // Ground or ceiling
  if (droneY - droneRadius <= 0 || droneY + droneRadius >= screenHeight) {
    return true;
  }

  for (const pipe of pipes) {
    const withinX = droneX + droneRadius > pipe.x && droneX - droneRadius < pipe.x + pipeWidth;
    if (withinX) {
      const topPipeBottom = pipe.gapY;
      const bottomPipeTop = pipe.gapY + pipe.gapHeight;
      if (droneY - droneRadius < topPipeBottom || droneY + droneRadius > bottomPipeTop) {
        return true;
      }
    }
  }
  return false;
}

// -----------------------------------------------------------------------------
// 5. FRUIT SLICING ARCADE MECHANICS (CYBER SLICE)
// -----------------------------------------------------------------------------
export function lineIntersectsCircle(
  p1: Point,
  p2: Point,
  circleCenter: Point,
  circleRadius: number
): boolean {
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const lenSq = dx * dx + dy * dy;

  if (lenSq === 0) {
    const distSq = (p1.x - circleCenter.x) ** 2 + (p1.y - circleCenter.y) ** 2;
    return distSq <= circleRadius * circleRadius;
  }

  // Projection scalar t of circleCenter onto segment p1-p2
  const t = Math.max(0, Math.min(1, ((circleCenter.x - p1.x) * dx + (circleCenter.y - p1.y) * dy) / lenSq));
  const closestX = p1.x + t * dx;
  const closestY = p1.y + t * dy;

  const distSq = (circleCenter.x - closestX) ** 2 + (circleCenter.y - closestY) ** 2;
  return distSq <= circleRadius * circleRadius;
}

// -----------------------------------------------------------------------------
// 6. SLINGSHOT PHYSICS MECHANICS (ORBIT STRIKE)
// -----------------------------------------------------------------------------
export function calculateTrajectory(
  origin: Point,
  dragPoint: Point,
  powerMultiplier: number = 0.25,
  steps: number = 30,
  gravity: number = 0.35
): Point[] {
  const vx = (origin.x - dragPoint.x) * powerMultiplier;
  const vy = (origin.y - dragPoint.y) * powerMultiplier;
  const points: Point[] = [];

  let currentX = origin.x;
  let currentY = origin.y;
  let curVx = vx;
  let curVy = vy;

  for (let i = 0; i < steps; i++) {
    points.push({ x: currentX, y: currentY });
    currentX += curVx;
    currentY += curVy;
    curVy += gravity;
  }

  return points;
}
