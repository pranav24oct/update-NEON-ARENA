import { GameSlug, GameGenre, GameDefinition, QuestType, QuestDifficulty } from '@neon-arena/shared';

// -----------------------------------------------------------------------------
// GAME CATALOGUE DEFINITIONS (ALL 6 PLAYABLE GAMES)
// -----------------------------------------------------------------------------
export const GAMES_CATALOGUE: GameDefinition[] = [
  {
    slug: GameSlug.TIC_TAC_TOE,
    title: 'Tic-Tac-Toe Neon',
    shortDescription: 'Classic 3x3 strategy with neon visuals, solo AI & real-time competitive multiplayer.',
    description: 'Enter the grid in this reimagined cyber Tic-Tac-Toe. Play solo against an adaptable minimax AI or match up in real-time online multiplayer against players worldwide with synchronized moves and competitive Elo rankings.',
    genre: GameGenre.STRATEGY,
    tags: ['Multiplayer', 'Competitive', 'Classic', 'Turn-Based'],
    thumbnail: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80',
    banner: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1200&auto=format&fit=crop&q=80',
    isMultiplayer: true,
    isCompetitive: true,
    minPlayers: 1,
    maxPlayers: 2,
    instructions: [
      'Take turns placing your neon marker (X or O) on an empty grid tile.',
      'Align three of your markers horizontally, vertically, or diagonally to win.',
      'If all 9 cells are occupied with no winner, the game results in a draw.',
      'Multiplayer matches award verified competitive Elo points and XP.'
    ],
    controls: [
      { action: 'Place Marker', key: 'Left Click / Tap' },
      { action: 'Restart / Rematch', key: 'R or Click Rematch' }
    ]
  },
  {
    slug: GameSlug.SNAKE,
    title: 'Neon Snake',
    shortDescription: 'High-speed arcade classic with pulsating energy orbs, glowing trails & speed progression.',
    description: 'Control a neon energy serpent navigating a digital grid. Consume energy cores to grow in length and boost your score multiplier. Avoid crashing into boundaries and your own radiant tail as your velocity accelerates.',
    genre: GameGenre.ARCADE,
    tags: ['Arcade', 'Retro', 'High Score', 'Fast-Paced'],
    thumbnail: 'https://images.unsplash.com/photo-1563089145-599997674d42?w=600&auto=format&fit=crop&q=80',
    banner: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=1200&auto=format&fit=crop&q=80',
    isMultiplayer: false,
    isCompetitive: false,
    minPlayers: 1,
    maxPlayers: 1,
    instructions: [
      'Guide your cyber snake to devour glowing energy food pellets.',
      'Each pellet consumed increases your length and score.',
      'Crashing into walls or your own body immediately ends the run.',
      'Survive longer to unlock progressive speed milestones and bonus XP.'
    ],
    controls: [
      { action: 'Move Up', key: 'W / Up Arrow' },
      { action: 'Move Down', key: 'S / Down Arrow' },
      { action: 'Move Left', key: 'A / Left Arrow' },
      { action: 'Move Right', key: 'D / Right Arrow' },
      { action: 'Pause / Resume', key: 'Spacebar / P' }
    ]
  },
  {
    slug: GameSlug.GAME_2048,
    title: 'Cyber 2048',
    shortDescription: 'Sleek geometric puzzle sliding numbers to synthesize the legendary 2048 Neon Core.',
    description: 'Immerse your mind in this cybernetic puzzle. Slide tiles across the 4x4 matrix. Identical numbers fuse together into higher tier energetic isotopes until you reach the 2048 core and beyond.',
    genre: GameGenre.PUZZLE,
    tags: ['Puzzle', 'Strategy', 'Brain', 'Math'],
    thumbnail: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&auto=format&fit=crop&q=80',
    banner: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=1200&auto=format&fit=crop&q=80',
    isMultiplayer: false,
    isCompetitive: false,
    minPlayers: 1,
    maxPlayers: 1,
    instructions: [
      'Slide all tiles on the board in one of four directions.',
      'When two tiles of equal value collide, they merge into one with double value.',
      'A new tile (2 or 4) spawns randomly on an empty spot after each move.',
      'Strategize carefully: the game ends when no legal moves remain.'
    ],
    controls: [
      { action: 'Slide Grid', key: 'Arrow Keys / WASD / Swipe' },
      { action: 'Restart Game', key: 'R' }
    ]
  },
  {
    slug: GameSlug.NEON_FLAP,
    title: 'Neon Cyber Flap',
    shortDescription: 'Precision flight through hazardous electric pillars and neon forcefields.',
    description: 'Pilot an agile neon drone through dense corridors of glowing hazard pillars. Master impulse thruster timing to thread through narrow energy gaps and claim top leaderboard positions.',
    genre: GameGenre.ARCADE,
    tags: ['Arcade', 'Action', 'Precision', 'High Score'],
    thumbnail: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=600&auto=format&fit=crop&q=80',
    banner: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1200&auto=format&fit=crop&q=80',
    isMultiplayer: false,
    isCompetitive: false,
    minPlayers: 1,
    maxPlayers: 1,
    instructions: [
      'Trigger thrusters to gain upward altitude against cybernetic gravity.',
      'Navigate precisely through the open gaps in electric beam columns.',
      'Each gate cleared increments your score and grants XP.',
      'Any collision with barriers, ceiling, or ground crashes your drone.'
    ],
    controls: [
      { action: 'Thrust / Jump', key: 'Spacebar / Left Click / Tap' },
      { action: 'Restart', key: 'R or Click Play Again' }
    ]
  },
  {
    slug: GameSlug.CYBER_SLICE,
    title: 'Cyber Slice',
    shortDescription: 'Fruit-slicing arcade action with neon blades, explosive combos & hazardous cyber bombs.',
    description: 'Draw luminous energy arcs with your cursor or finger to slice cyber fruit and plasma spheres launched into the arena. String together multi-slice combos for massive multipliers while avoiding explosive hazard bombs.',
    genre: GameGenre.ACTION,
    tags: ['Action', 'Arcade', 'Reflex', 'Combos'],
    thumbnail: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?w=600&auto=format&fit=crop&q=80',
    banner: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=1200&auto=format&fit=crop&q=80',
    isMultiplayer: false,
    isCompetitive: false,
    minPlayers: 1,
    maxPlayers: 1,
    instructions: [
      'Drag your blade across flying neon targets to cleave them in half.',
      'Slice 3 or more targets in a single stroke for bonus combo points.',
      'Avoid slicing red hazard bombs—they trigger instant damage.',
      'You have 3 energy lives. Dropping un-sliced targets depletes lives.'
    ],
    controls: [
      { action: 'Slice Blade', key: 'Click & Drag / Touch & Swipe' },
      { action: 'Restart', key: 'R' }
    ]
  },
  {
    slug: GameSlug.ORBIT_STRIKE,
    title: 'Orbit Strike',
    shortDescription: 'Physics-based slingshot puzzle to dismantle crystalline neon fortresses.',
    description: 'Harness gravitational sling physics to launch concentrated plasma projectiles at defensive crystal structures. Calculate angles, trajectories, and structural weak points to demolish target cores in minimal shots.',
    genre: GameGenre.PHYSICS,
    tags: ['Physics', 'Puzzle', 'Aim', 'Destruction'],
    thumbnail: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=600&auto=format&fit=crop&q=80',
    banner: 'https://images.unsplash.com/photo-1507499739999-097706ad8914?w=1200&auto=format&fit=crop&q=80',
    isMultiplayer: false,
    isCompetitive: false,
    minPlayers: 1,
    maxPlayers: 1,
    instructions: [
      'Click and pull back on the slingshot orb to aim and charge launch velocity.',
      'Follow the predicted trajectory line to target structural pillars.',
      'Release to fire the projectile and trigger cascading destruction physics.',
      'Obliterate all target crystals to clear the sector with highest stars.'
    ],
    controls: [
      { action: 'Aim Slingshot', key: 'Click & Drag Backwards' },
      { action: 'Release / Fire', key: 'Release Mouse / Touch' },
      { action: 'Reset Level', key: 'R' }
    ]
  }
];

// -----------------------------------------------------------------------------
// QUEST TEMPLATES
// -----------------------------------------------------------------------------
export interface QuestTemplateDef {
  id: string;
  title: string;
  description: string;
  type: QuestType;
  difficulty: QuestDifficulty;
  targetCount: number;
  xpReward: number;
  gameSlug?: GameSlug;
  actionType: 'PLAY_GAME' | 'WIN_MATCH' | 'SCORE_POINTS' | 'MULTIPLAYER_MATCH' | 'COMPLETE_CHALLENGE';
}

export const INITIAL_QUESTS: QuestTemplateDef[] = [
  // Daily Quests
  {
    id: 'daily_play_2',
    title: 'Arena Warmup',
    description: 'Play at least 2 game matches across the platform.',
    type: QuestType.DAILY,
    difficulty: QuestDifficulty.EASY,
    targetCount: 2,
    xpReward: 150,
    actionType: 'PLAY_GAME'
  },
  {
    id: 'daily_win_multiplayer',
    title: 'Duelist Victory',
    description: 'Win 1 real-time multiplayer match in Tic-Tac-Toe.',
    type: QuestType.DAILY,
    difficulty: QuestDifficulty.MEDIUM,
    targetCount: 1,
    xpReward: 250,
    gameSlug: GameSlug.TIC_TAC_TOE,
    actionType: 'WIN_MATCH'
  },
  {
    id: 'daily_snake_score',
    title: 'Serpent Feeder',
    description: 'Score at least 100 points in a single session of Neon Snake.',
    type: QuestType.DAILY,
    difficulty: QuestDifficulty.MEDIUM,
    targetCount: 100,
    xpReward: 200,
    gameSlug: GameSlug.SNAKE,
    actionType: 'SCORE_POINTS'
  },
  {
    id: 'daily_cyber_slice_score',
    title: 'Neon Katana',
    description: 'Slice up at least 300 points in Cyber Slice.',
    type: QuestType.DAILY,
    difficulty: QuestDifficulty.MEDIUM,
    targetCount: 300,
    xpReward: 220,
    gameSlug: GameSlug.CYBER_SLICE,
    actionType: 'SCORE_POINTS'
  },

  // Weekly Quests
  {
    id: 'weekly_win_10',
    title: 'Master Competitor',
    description: 'Win 10 matches across singleplayer or multiplayer modes.',
    type: QuestType.WEEKLY,
    difficulty: QuestDifficulty.HARD,
    targetCount: 10,
    xpReward: 1000,
    actionType: 'WIN_MATCH'
  },
  {
    id: 'weekly_variety',
    title: 'Hex Explorer',
    description: 'Play all 6 arcade games in the library.',
    type: QuestType.WEEKLY,
    difficulty: QuestDifficulty.MEDIUM,
    targetCount: 6,
    xpReward: 750,
    actionType: 'PLAY_GAME'
  },

  // Milestones
  {
    id: 'milestone_first_game',
    title: 'First Steps in the Arena',
    description: 'Complete your first ever match on Neon Arena.',
    type: QuestType.MILESTONE,
    difficulty: QuestDifficulty.EASY,
    targetCount: 1,
    xpReward: 300,
    actionType: 'PLAY_GAME'
  },
  {
    id: 'milestone_reach_1000_score',
    title: 'High Roller',
    description: 'Accumulate a high score of 1,000 points in any arcade game.',
    type: QuestType.MILESTONE,
    difficulty: QuestDifficulty.HARD,
    targetCount: 1000,
    xpReward: 1200,
    actionType: 'SCORE_POINTS'
  }
];

// -----------------------------------------------------------------------------
// ACHIEVEMENTS DEFINITION (TROPHY CABINET)
// -----------------------------------------------------------------------------
export interface AchievementDef {
  id: string;
  name: string;
  description: string;
  icon: string;
  rarity: 'COMMON' | 'RARE' | 'EPIC' | 'LEGENDARY';
  xpReward: number;
  conditionType: 'MATCHES_PLAYED' | 'WINS' | 'MULTIPLAYER_WINS' | 'HIGH_SCORE' | 'STREAK';
  threshold: number;
}

export const ACHIEVEMENTS: AchievementDef[] = [
  {
    id: 'ach_first_match',
    name: 'Initiation',
    description: 'Play your very first game match on Neon Arena.',
    icon: 'Gamepad2',
    rarity: 'COMMON',
    xpReward: 100,
    conditionType: 'MATCHES_PLAYED',
    threshold: 1
  },
  {
    id: 'ach_first_win',
    name: 'First Blood',
    description: 'Secure your first victory in any competitive or solo mode.',
    icon: 'Trophy',
    rarity: 'COMMON',
    xpReward: 150,
    conditionType: 'WINS',
    threshold: 1
  },
  {
    id: 'ach_win_streak_3',
    name: 'On Fire',
    description: 'Achieve a win streak of 3 consecutive matches.',
    icon: 'Flame',
    rarity: 'RARE',
    xpReward: 350,
    conditionType: 'STREAK',
    threshold: 3
  },
  {
    id: 'ach_multiplayer_5',
    name: 'Cyber Gladiator',
    description: 'Win 5 real-time multiplayer duels.',
    icon: 'Swords',
    rarity: 'RARE',
    xpReward: 500,
    conditionType: 'MULTIPLAYER_WINS',
    threshold: 5
  },
  {
    id: 'ach_arcade_master',
    name: 'Arcade Legend',
    description: 'Complete 25 total arcade game sessions.',
    icon: 'Crown',
    rarity: 'EPIC',
    xpReward: 800,
    conditionType: 'MATCHES_PLAYED',
    threshold: 25
  },
  {
    id: 'ach_score_master',
    name: 'Neon Overload',
    description: 'Reach a single game score exceeding 2000 points.',
    icon: 'Zap',
    rarity: 'LEGENDARY',
    xpReward: 1500,
    conditionType: 'HIGH_SCORE',
    threshold: 2000
  }
];

// -----------------------------------------------------------------------------
// AVATARS PRESETS
// -----------------------------------------------------------------------------
export const AVATAR_PRESETS = [
  'https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80'
];
