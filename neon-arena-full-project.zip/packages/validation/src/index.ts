import { z } from 'zod';
import { GameSlug, QuestType, QuestDifficulty, TournamentStatus, UserRole } from '@neon-arena/shared';

// Auth Validation Schemas
export const registerSchema = z.object({
  username: z
    .string()
    .min(3, 'Username must be at least 3 characters')
    .max(20, 'Username cannot exceed 20 characters')
    .regex(/^[a-zA-Z0-9_-]+$/, 'Username can only contain letters, numbers, underscores, and hyphens'),
  email: z.string().email('Please provide a valid email address'),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .max(100, 'Password is too long')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
  avatar: z.string().optional()
});

export const loginSchema = z.object({
  identifier: z.string().min(1, 'Username or email is required'),
  password: z.string().min(1, 'Password is required')
});

export const forgotPasswordSchema = z.object({
  email: z.string().email('Please provide a valid email address')
});

export const resetPasswordSchema = z.object({
  token: z.string().min(1, 'Token is required'),
  newPassword: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .max(100, 'Password is too long')
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number')
});

// Profile Validation Schemas
export const updateProfileSchema = z.object({
  displayName: z.string().min(1).max(30).optional(),
  bio: z.string().max(250, 'Bio cannot exceed 250 characters').optional(),
  avatar: z.string().optional(),
  country: z.string().max(3, 'Country code must be max 3 characters').optional(),
  isProfilePublic: z.boolean().optional(),
  allowFriendRequests: z.boolean().optional()
});

// Game Session Validation
export const startGameSessionSchema = z.object({
  gameSlug: z.nativeEnum(GameSlug)
});

export const completeGameSessionSchema = z.object({
  score: z.number().int().min(0, 'Score cannot be negative'),
  durationSeconds: z.number().int().min(0, 'Duration cannot be negative'),
  metadata: z.record(z.any()).optional()
});

// Quests
export const claimQuestSchema = z.object({
  questId: z.string().min(1, 'Quest ID is required')
});

// Tournaments
export const registerTournamentSchema = z.object({
  tournamentId: z.string().min(1, 'Tournament ID is required')
});

export const createTournamentSchema = z.object({
  title: z.string().min(3).max(100),
  description: z.string().min(10).max(1000),
  gameSlug: z.nativeEnum(GameSlug),
  maxParticipants: z.number().int().refine((n) => [4, 8, 16, 32].includes(n), {
    message: 'Max participants must be 4, 8, 16, or 32'
  }),
  startDate: z.string().datetime(),
  registrationDeadline: z.string().datetime(),
  xpReward: z.number().int().min(0)
});

// Social & Friends
export const sendFriendRequestSchema = z.object({
  targetUsername: z.string().min(1, 'Target username is required')
});

export const respondFriendRequestSchema = z.object({
  requestId: z.string().min(1),
  action: z.enum(['ACCEPT', 'DECLINE'])
});

export const reportUserSchema = z.object({
  targetUserId: z.string().min(1),
  reason: z.string().min(5).max(500),
  context: z.string().optional()
});

export const blockUserSchema = z.object({
  targetUserId: z.string().min(1)
});

// Admin Schemas
export const adminUpdateUserRoleSchema = z.object({
  userId: z.string().min(1),
  role: z.nativeEnum(UserRole)
});

export const adminBanUserSchema = z.object({
  userId: z.string().min(1),
  reason: z.string().min(3).max(500),
  durationDays: z.number().int().min(1).max(365).optional()
});

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;
export type CompleteGameSessionInput = z.infer<typeof completeGameSessionSchema>;
export type CreateTournamentInput = z.infer<typeof createTournamentSchema>;
