// NEON ARENA - Shared Core Types & Enums

export enum UserRole {
  PLAYER = 'PLAYER',
  MODERATOR = 'MODERATOR',
  ADMIN = 'ADMIN'
}

export enum CompetitiveTier {
  BRONZE = 'BRONZE',
  SILVER = 'SILVER',
  GOLD = 'GOLD',
  PLATINUM = 'PLATINUM',
  DIAMOND = 'DIAMOND',
  MASTER = 'MASTER',
  CHAMPION = 'CHAMPION'
}

export interface TierInfo {
  tier: CompetitiveTier;
  minRating: number;
  maxRating: number;
  label: string;
  color: string;
  badgeBg: string;
}

export const COMPETITIVE_TIERS: Record<CompetitiveTier, TierInfo> = {
  [CompetitiveTier.BRONZE]: {
    tier: CompetitiveTier.BRONZE,
    minRating: 0,
    maxRating: 1199,
    label: 'Bronze',
    color: '#cd7f32',
    badgeBg: 'rgba(205, 127, 50, 0.2)'
  },
  [CompetitiveTier.SILVER]: {
    tier: CompetitiveTier.SILVER,
    minRating: 1200,
    maxRating: 1399,
    label: 'Silver',
    color: '#c0c0c0',
    badgeBg: 'rgba(192, 192, 192, 0.2)'
  },
  [CompetitiveTier.GOLD]: {
    tier: CompetitiveTier.GOLD,
    minRating: 1400,
    maxRating: 1599,
    label: 'Gold',
    color: '#ffd700',
    badgeBg: 'rgba(255, 215, 0, 0.2)'
  },
  [CompetitiveTier.PLATINUM]: {
    tier: CompetitiveTier.PLATINUM,
    minRating: 1600,
    maxRating: 1799,
    label: 'Platinum',
    color: '#00e5ff',
    badgeBg: 'rgba(0, 229, 255, 0.2)'
  },
  [CompetitiveTier.DIAMOND]: {
    tier: CompetitiveTier.DIAMOND,
    minRating: 1800,
    maxRating: 1999,
    label: 'Diamond',
    color: '#a855f7',
    badgeBg: 'rgba(168, 85, 247, 0.2)'
  },
  [CompetitiveTier.MASTER]: {
    tier: CompetitiveTier.MASTER,
    minRating: 2000,
    maxRating: 2299,
    label: 'Master',
    color: '#ec4899',
    badgeBg: 'rgba(236, 72, 153, 0.2)'
  },
  [CompetitiveTier.CHAMPION]: {
    tier: CompetitiveTier.CHAMPION,
    minRating: 2300,
    maxRating: 9999,
    label: 'Champion',
    color: '#f43f5e',
    badgeBg: 'rgba(244, 63, 94, 0.2)'
  }
};

export enum GameSlug {
  TIC_TAC_TOE = 'tic-tac-toe',
  SNAKE = 'snake',
  GAME_2048 = '2048',
  NEON_FLAP = 'neon-flap',
  CYBER_SLICE = 'cyber-slice',
  ORBIT_STRIKE = 'orbit-strike'
}

export enum GameGenre {
  ARCADE = 'Arcade',
  PUZZLE = 'Puzzle',
  CLASSIC = 'Classic',
  ACTION = 'Action',
  STRATEGY = 'Strategy',
  PHYSICS = 'Physics'
}

export interface GameDefinition {
  slug: GameSlug;
  title: string;
  shortDescription: string;
  description: string;
  genre: GameGenre;
  tags: string[];
  thumbnail: string;
  banner: string;
  isMultiplayer: boolean;
  isCompetitive: boolean;
  minPlayers: number;
  maxPlayers: number;
  instructions: string[];
  controls: { action: string; key: string }[];
}

export enum QuestType {
  DAILY = 'DAILY',
  WEEKLY = 'WEEKLY',
  MILESTONE = 'MILESTONE'
}

export enum QuestDifficulty {
  EASY = 'EASY',
  MEDIUM = 'MEDIUM',
  HARD = 'HARD'
}

export enum TournamentStatus {
  UPCOMING = 'UPCOMING',
  REGISTRATION = 'REGISTRATION',
  ACTIVE = 'ACTIVE',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED'
}

export enum MatchStatus {
  PENDING = 'PENDING',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  ABANDONED = 'ABANDONED',
  DRAW = 'DRAW'
}

export enum PresenceStatus {
  ONLINE = 'ONLINE',
  IN_MATCH = 'IN_MATCH',
  IN_QUEUE = 'IN_QUEUE',
  OFFLINE = 'OFFLINE'
}

export enum FriendshipStatus {
  PENDING = 'PENDING',
  ACCEPTED = 'ACCEPTED',
  DECLINED = 'DECLINED',
  BLOCKED = 'BLOCKED'
}

export enum NotificationType {
  FRIEND_REQUEST = 'FRIEND_REQUEST',
  FRIEND_ACCEPTED = 'FRIEND_ACCEPTED',
  GAME_INVITE = 'GAME_INVITE',
  TOURNAMENT_ALERT = 'TOURNAMENT_ALERT',
  QUEST_COMPLETED = 'QUEST_COMPLETED',
  LEVEL_UP = 'LEVEL_UP',
  ACHIEVEMENT_UNLOCKED = 'ACHIEVEMENT_UNLOCKED',
  SYSTEM = 'SYSTEM'
}

// Socket Events
export const SOCKET_EVENTS = {
  // Connection & Auth
  CONNECT: 'connect',
  DISCONNECT: 'disconnect',
  AUTHENTICATE: 'authenticate',
  AUTHENTICATED: 'authenticated',

  // Presence
  PRESENCE_UPDATE: 'presence:update',
  GET_ONLINE_USERS: 'presence:get_online',

  // Matchmaking
  JOIN_QUEUE: 'matchmaking:join',
  LEAVE_QUEUE: 'matchmaking:leave',
  MATCH_FOUND: 'matchmaking:match_found',
  QUEUE_STATUS: 'matchmaking:queue_status',

  // Custom Rooms
  CREATE_ROOM: 'room:create',
  JOIN_ROOM: 'room:join',
  LEAVE_ROOM: 'room:leave',
  ROOM_DATA: 'room:data',
  PLAYER_READY: 'room:player_ready',
  ROOM_EXPIRED: 'room:expired',

  // Gameplay: Tic-Tac-Toe
  GAME_START: 'game:start',
  MAKE_MOVE: 'game:make_move',
  MOVE_MADE: 'game:move_made',
  GAME_OVER: 'game:game_over',
  REQUEST_REMATCH: 'game:request_rematch',
  REMATCH_ACCEPTED: 'game:rematch_accepted',

  // Social & Chat
  SEND_CHAT_MESSAGE: 'chat:send',
  NEW_CHAT_MESSAGE: 'chat:message',
  SEND_INVITE: 'social:send_invite',
  RECEIVE_INVITE: 'social:receive_invite',
  NEW_NOTIFICATION: 'notification:new'
} as const;

// Progression Calculations
export function getXpRequiredForLevel(level: number): number {
  if (level <= 1) return 100;
  return Math.floor(100 * Math.pow(level, 1.45));
}

export function calculateLevelFromXp(totalXp: number): { level: number; currentLevelXp: number; nextLevelXp: number; progressPercent: number } {
  let level = 1;
  let remainingXp = Math.max(0, totalXp);

  while (true) {
    const required = getXpRequiredForLevel(level);
    if (remainingXp < required) {
      const progressPercent = Math.min(100, Math.floor((remainingXp / required) * 100));
      return {
        level,
        currentLevelXp: remainingXp,
        nextLevelXp: required,
        progressPercent
      };
    }
    remainingXp -= required;
    level++;
  }
}

export function getTierFromRating(rating: number): CompetitiveTier {
  if (rating >= 2300) return CompetitiveTier.CHAMPION;
  if (rating >= 2000) return CompetitiveTier.MASTER;
  if (rating >= 1800) return CompetitiveTier.DIAMOND;
  if (rating >= 1600) return CompetitiveTier.PLATINUM;
  if (rating >= 1400) return CompetitiveTier.GOLD;
  if (rating >= 1200) return CompetitiveTier.SILVER;
  return CompetitiveTier.BRONZE;
}

// Elo Calculation Formula
export function calculateEloChange(playerRating: number, opponentRating: number, outcome: 1 | 0.5 | 0, kFactor: number = 32): { change: number; newRating: number } {
  const expectedScore = 1 / (1 + Math.pow(10, (opponentRating - playerRating) / 400));
  const change = Math.round(kFactor * (outcome - expectedScore));
  const newRating = Math.max(100, playerRating + change);
  return { change, newRating };
}
