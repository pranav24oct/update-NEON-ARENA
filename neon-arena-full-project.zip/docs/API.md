# NEON ARENA — REST API Specification (`/api/v1`)

All API routes are prefixed under `/api/v1`. JSON payloads are validated using shared Zod schemas.

## 1. Authentication (`/api/v1/auth`)

| Method | Endpoint | Description | Auth Required |
|---|---|---|---|
| `POST` | `/api/v1/auth/register` | Register new player account | None |
| `POST` | `/api/v1/auth/login` | Authenticate with username or email | None |
| `POST` | `/api/v1/auth/refresh` | Refresh expired access token | Refresh Token |
| `POST` | `/api/v1/auth/logout` | Revoke session refresh token | Bearer Token |
| `GET` | `/api/v1/auth/me` | Fetch authenticated user data & stats | Bearer Token |

### Sample: Register Request (`POST /api/v1/auth/register`)
```json
{
  "username": "cyber_ninja",
  "email": "ninja@neon.io",
  "password": "Password123!",
  "avatar": "https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150"
}
```

### Sample: Success Response (`201 Created`)
```json
{
  "message": "Registration successful.",
  "accessToken": "eyJhbGciOiJIUzI1NiIsIn...",
  "refreshToken": "48bf49a997d91...",
  "user": {
    "id": "usr_c48a7b9e",
    "username": "cyber_ninja",
    "email": "ninja@neon.io",
    "role": "PLAYER",
    "profile": {
      "displayName": "cyber_ninja",
      "avatar": "https://images.unsplash.com/photo-1566492031773-4f4e44671857?w=150"
    },
    "statistics": {
      "totalXp": 0,
      "level": 1,
      "totalGamesPlayed": 0,
      "totalWins": 0
    }
  }
}
```

---

## 2. Players (`/api/v1/players`)

| Method | Endpoint | Description | Auth Required |
|---|---|---|---|
| `GET` | `/api/v1/players/profile/:username` | Public profile & stats | Optional |
| `PUT` | `/api/v1/players/profile` | Update user display name, avatar, bio | Bearer Token |
| `GET` | `/api/v1/players/stats` | Detailed player statistics & records | Bearer Token |
| `GET` | `/api/v1/players/achievements` | Unlocked & available achievements | Bearer Token |
| `GET` | `/api/v1/players/transactions` | XP reward transaction history | Bearer Token |

---

## 3. Games & Sessions (`/api/v1/games`)

| Method | Endpoint | Description | Auth Required |
|---|---|---|---|
| `GET` | `/api/v1/games` | Retrieve all games with filters & metadata | Optional |
| `GET` | `/api/v1/games/:slug` | Get game details and personal best | Optional |
| `POST` | `/api/v1/games/:slug/start` | Start tracked game session | Bearer Token |
| `POST` | `/api/v1/games/:slug/end` | Submit score & award verified XP | Bearer Token |

### Sample: End Game Session (`POST /api/v1/games/neon-snake/end`)
```json
{
  "sessionId": "ses_089f2a",
  "score": 1450,
  "metrics": {
    "applesEaten": 29,
    "maxSpeedReached": 14,
    "elapsedSeconds": 185
  }
}
```

### Sample: End Session Response (`200 OK`)
```json
{
  "message": "Session completed.",
  "score": 1450,
  "isPersonalBest": true,
  "xpAwarded": 145,
  "newTotalXp": 1645,
  "newLevel": 4,
  "unlockedAchievements": []
}
```

---

## 4. Quests & Challenges (`/api/v1/quests`, `/api/v1/challenges`)

| Method | Endpoint | Description | Auth Required |
|---|---|---|---|
| `GET` | `/api/v1/quests` | Get daily & weekly quests with progress | Bearer Token |
| `POST` | `/api/v1/quests/:id/claim` | Claim completed quest XP reward | Bearer Token |
| `GET` | `/api/v1/challenges` | Get active rotating community challenges | Optional |

---

## 5. Leaderboards (`/api/v1/leaderboards`)

| Method | Endpoint | Description | Auth Required |
|---|---|---|---|
| `GET` | `/api/v1/leaderboards/global` | Global XP level rankings | Optional |
| `GET` | `/api/v1/leaderboards/game/:slug` | Game-specific high scores | Optional |
| `GET` | `/api/v1/leaderboards/competitive` | Competitive Elo rank ladder | Optional |
| `GET` | `/api/v1/leaderboards/friends` | Leaderboard among friends | Bearer Token |

---

## 6. Tournaments (`/api/v1/tournaments`)

| Method | Endpoint | Description | Auth Required |
|---|---|---|---|
| `GET` | `/api/v1/tournaments` | List active, upcoming & past tournaments | Optional |
| `GET` | `/api/v1/tournaments/:id` | Tournament detail with bracket tree | Optional |
| `POST` | `/api/v1/tournaments/:id/register` | Register for single-elimination tournament | Bearer Token |
| `POST` | `/api/v1/tournaments/:id/match/:matchId/report` | Report score or advance bracket node | Bearer Token |

---

## 7. Friends & Social (`/api/v1/friends`)

| Method | Endpoint | Description | Auth Required |
|---|---|---|---|
| `GET` | `/api/v1/friends` | List accepted friends & online status | Bearer Token |
| `GET` | `/api/v1/friends/requests` | List pending incoming/outgoing requests | Bearer Token |
| `POST` | `/api/v1/friends/request` | Send friend request by username | Bearer Token |
| `POST` | `/api/v1/friends/accept` | Accept pending friend request | Bearer Token |
| `POST` | `/api/v1/friends/remove` | Remove friend | Bearer Token |
| `POST` | `/api/v1/friends/report` | Report user for misconduct | Bearer Token |

---

## 8. Admin Operations (`/api/v1/admin`)

*(Requires `ADMIN` user role)*

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/v1/admin/metrics` | Platform overview metrics (users, sessions, matches) |
| `GET` | `/api/v1/admin/users` | Paginated user management table |
| `POST` | `/api/v1/admin/users/role` | Elevate or change user role |
| `POST` | `/api/v1/admin/users/ban` | Ban offending user with reason & duration |
| `POST` | `/api/v1/admin/users/:userId/unban` | Unban user |
| `GET` | `/api/v1/admin/reports` | List pending community moderation reports |
| `POST` | `/api/v1/admin/reports/:reportId/resolve` | Action or dismiss moderation report |
| `POST` | `/api/v1/admin/tournaments` | Generate new tournament & bracket |
| `GET` | `/api/v1/admin/audit-logs` | Security & administrative audit trail |
