# NEON ARENA — System Architecture & Design

## 1. System Overview

NEON ARENA is a modern, high-performance, real-time competitive gaming platform built with a modular TypeScript monorepo architecture. The platform combines fast-paced arcade gameplay with competitive progression, Elo-based matchmaking, automated tournaments, and social community infrastructure.

```
+-------------------------------------------------------------------------+
|                                CLIENTS                                  |
|  +--------------------+  +--------------------+  +-------------------+  |
|  |   Desktop Browser  |  |   Tablet Browser   |  |   Mobile Browser  |  |
|  +--------------------+  +--------------------+  +-------------------+  |
+------------------------------------+------------------------------------+
                                     |
               HTTPS (REST)          |          WSS (Socket.IO)
                                     v
+-------------------------------------------------------------------------+
|                        NGINX REVERSE PROXY                              |
|  - TLS Termination & Security Headers                                   |
|  - Static Assets Delivery (/assets/*) with aggressive caching           |
|  - Reverse proxy: /api/* -> Node.js Express                             |
|  - WebSocket proxy: /socket.io/* -> Socket.IO Gateway                   |
+------------------------------------+------------------------------------+
                                     |
                                     v
+-------------------------------------------------------------------------+
|                        APPLICATION SERVER (API)                         |
|  +--------------------------------+  +-------------------------------+  |
|  |     Express REST API (v1)      |  |    Socket.IO Gateway Server   |  |
|  | - Authentication & JWT Auth    |  | - JWT Handshake Authentication|  |
|  | - Player Profiles & Stats      |  | - Real-time Presence Engine   |  |
|  | - Game Sessions & Scores       |  | - Matchmaking Queue (1v1)     |  |
|  | - Quests & XP Engine           |  | - Server-authoritative TTT    |  |
|  | - Tournaments & Brackets       |  | - Private Rooms & Rematches   |  |
|  | - Leaderboards & Social        |  | - Instant Messaging & Invites |  |
|  | - Admin Operations & Audit     |  |                               |  |
|  +--------------------------------+  +-------------------------------+  |
+------------------------------------+------------------------------------+
                   |                                    |
                   v                                    v
+------------------------------------+  +---------------------------------+
|          DATABASE TIER             |  |           CACHE TIER            |
|  PostgreSQL 16 (or local SQLite)   |  |  Redis 7                        |
|  - 26 Prisma Relational Models     |  |  - Active Matchmaking Queue     |
|  - Player Profiles & Statistics    |  |  - Session Revocation List      |
|  - Verified XP & Transactions      |  |  - Distributed Socket Adapter   |
|  - Match History & Bracket Nodes   |  |                                 |
+------------------------------------+  +---------------------------------+
```

---

## 2. Monorepo Structure

```
neon-arena/
├── apps/
│   ├── api/                     # Backend API & WebSocket server
│   │   ├── src/
│   │   │   ├── modules/         # Domain-driven REST feature modules
│   │   │   │   ├── auth/        # Register, login, refresh, profile tokens
│   │   │   │   ├── players/     # Player profile, stats, avatar, streaks
│   │   │   │   ├── games/       # Catalog, sessions, server-verified scoring
│   │   │   │   ├── quests/      # Daily & weekly quest progression
│   │   │   │   ├── challenges/  # Global rotating community challenges
│   │   │   │   ├── leaderboards/# High scores, XP rankings, competitive Elo
│   │   │   │   ├── matches/     # Match history, participant stats
│   │   │   │   ├── tournaments/ # Bracket generation, registration, advance
│   │   │   │   ├── friends/     # Friend requests, accepts, remove
│   │   │   │   ├── notifications/# User inbox & transactional alerts
│   │   │   │   └── admin/       # Metrics, ban/unban, audit logs, brackets
│   │   │   ├── sockets/         # Real-time Socket.IO game servers
│   │   │   │   ├── socketServer.ts     # Connection, presence & event bus
│   │   │   │   └── gameRoomManager.ts  # Queue, room lifecycle, game logic
│   │   │   ├── middlewares/     # Auth, error handling, rate limiting
│   │   │   ├── config/          # Environment, Prisma client, Redis client
│   │   │   └── server.ts        # Express entry point
│   │   └── tests/               # API, auth, engine, and E2E scenario tests
│   │
│   └── web/                     # React 18 + Vite frontend SPA
│       ├── src/
│       │   ├── components/      # UI components, layout, navbar, sidebar, 3D
│       │   ├── games/           # 6 Playable Canvas & Interactive Games
│       │   │   ├── TicTacToeGame.tsx # Solo AI & Live Multiplayer
│       │   │   ├── SnakeGame.tsx     # Canvas arcade snake
│       │   │   ├── Game2048.tsx      # Smooth tile sliding & merge
│       │   │   ├── NeonFlapGame.tsx  # Canvas drone physics & obstacles
│       │   │   ├── CyberSliceGame.tsx# Blade slice trail & physics bombs
│       │   │   └── OrbitStrikeGame.tsx# 2D slingshot physics puzzle
│       │   ├── pages/           # 15 Complete functional platform pages
│       │   ├── stores/          # Zustand client state (auth, audio, ui)
│       │   ├── lib/             # API client, Socket client, SoundManager
│       │   └── tests/           # Web app unit tests
│
├── packages/
│   ├── shared/                  # Common TypeScript interfaces, enums, math
│   ├── validation/              # Zod schemas shared across API & Web
│   ├── game-engine/             # Pure deterministic game logic & math
│   └── config/                  # Game catalog, quest templates, avatars
│
├── prisma/
│   ├── schema.prisma            # Active Prisma schema (SQLite dev / PostgreSQL prod)
│   ├── schema.postgresql.prisma # Dedicated PostgreSQL schema for cloud/docker
│   └── seed.ts                  # Comprehensive database seeder
│
├── infrastructure/
│   ├── docker/                  # Multi-stage Dockerfiles (API & Web)
│   └── nginx/                   # Nginx reverse proxy configuration
│
└── docker-compose.yml           # Complete containerized local / staging stack
```

---

## 3. Database Architecture (26 Relational Models)

The database models user accounts, authentication identities, sessions, player progression, competitive ratings, game sessions, match history, quests, achievements, tournaments, friendships, and audit records:

1. **User & Identity**: `User`, `AuthenticationIdentity`, `RefreshToken`.
2. **Player Data**: `PlayerProfile`, `PlayerStatistics`, `PlayerRating`, `XPTransaction`.
3. **Gaming & Scoring**: `Game`, `GameSession`, `ScoreRecord`.
4. **Competitive & Multiplayer**: `Match`, `MatchParticipant`, `Tournament`, `TournamentParticipant`, `TournamentMatch`.
5. **Progression & Social**: `QuestTemplate`, `PlayerQuest`, `Challenge`, `PlayerChallenge`, `Achievement`, `PlayerAchievement`, `Season`, `Friendship`, `Notification`, `Report`, `BlockedUser`, `AuditLog`.

---

## 4. Security Architecture

1. **Password Hashing**: Passwords are saved with bcrypt using standard salt rounds. Plaintext passwords are never logged or stored.
2. **Dual-Token Authentication**:
   - Short-lived Access Token (15-minute JWT) containing `userId`, `username`, and `role`.
   - Long-lived Refresh Token (7-day opaque SHA-256 hash) stored in the database with client IP and User-Agent tracking, enabling instant remote session revocation.
3. **Server Authoritative Validation**:
   - Game scores are validated against session durations and maximum possible scoring velocities before XP is minted.
   - Multiplayer moves and win conditions are calculated strictly on the backend server.
   - Client-reported scores cannot arbitrarily elevate player ratings or claim tournament victories.
4. **Rate Limiting**:
   - Express rate limiter protects auth endpoints from brute-force attacks (5 requests/minute).
   - Standard API endpoints are limited to 100 requests/minute.
5. **Audit Logging**:
   - All administrative actions (user ban/unban, role elevation, report resolution, tournament generation) write immutable entries to `AuditLog`.
