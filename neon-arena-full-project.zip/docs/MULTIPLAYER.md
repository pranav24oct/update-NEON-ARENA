# NEON ARENA — Real-Time Multiplayer & Matchmaking

## 1. Socket.IO Protocol & Handshake

Real-time multiplayer in NEON ARENA operates over WebSockets with HTTP fallback powered by Socket.IO.
Authentication is established via JWT bearer token passed in the socket handshake `auth` object:

```typescript
const socket = io('http://localhost:4000', {
  auth: {
    token: localStorage.getItem('neon_access_token')
  },
  transports: ['websocket', 'polling']
});
```

The server decodes the token in the authentication middleware, attaches the `userId`, `username`, and `profile` to `socket.data`, and adds the user to the active presence map.

---

## 2. Real-Time Events Specification

### Presence Events
- `presence:update`: Emitted to subscribers whenever user connects/disconnects.
- `presence:get_online`: Request current online player list.

### Matchmaking Queue Events
- `matchmaking:join`: Client requests to join the 1v1 matchmaking queue for a specific game slug (e.g. `tic-tac-toe`).
- `matchmaking:queue_status`: Emitted back with `{ inQueue: boolean, position: number, queueLength: number }`.
- `matchmaking:leave`: Client cancels queue search.
- `matchmaking:match_found`: Server notifies both matched players:
  ```json
  {
    "roomId": "room_a19bf2e4",
    "opponent": {
      "id": "usr_2",
      "username": "pixel_queen",
      "rating": 1240,
      "avatar": "..."
    },
    "assignedSymbol": "X",
    "turn": "X"
  }
  ```

### Custom Game Rooms
- `room:create`: Create private custom match room, returns 6-character room code (e.g. `NEON-4X9B`).
- `room:join`: Join custom match room via code.
- `room:data`: Room state sync (participants, ready state, game status).
- `room:player_ready`: Player toggles ready state.

### Server-Authoritative Tic-Tac-Toe Game Events
- `game:start`: Sent to both players when both are connected and synchronized.
- `game:make_move`:
  ```json
  {
    "roomId": "room_a19bf2e4",
    "index": 4
  }
  ```
  The server verifies:
  1. Room exists and status is `'IN_PROGRESS'`.
  2. The move sender's `userId` matches the current active player's turn.
  3. Cell at `index` is empty (`null`).
  4. The move is recorded and checked for win or draw.
- `game:move_made`: Broadcast to room with `{ index, symbol, nextTurn, board }`.
- `game:game_over`: Emitted when win, draw, or forfeit occurs:
  ```json
  {
    "winnerId": "usr_1",
    "isDraw": false,
    "winningLine": [0, 4, 8],
    "eloUpdates": {
      "usr_1": { "oldRating": 1200, "newRating": 1216, "change": 16 },
      "usr_2": { "oldRating": 1200, "newRating": 1184, "change": -16 }
    },
    "xpAwards": {
      "usr_1": 120,
      "usr_2": 40
    }
  }
  ```
- `game:request_rematch`: Request immediate rematch without returning to lobby.
- `game:rematch_accepted`: Both players agreed; new board initialized.

---

## 3. Disconnect & Forfeit Resilience

When a player disconnects during an active competitive match:
1. The server flags the room with `disconnectGracePeriod: 15s`.
2. An event `opponent:disconnected` is broadcast to the opponent with a countdown.
3. If the disconnected player reconnects and provides their room code within 15 seconds, the match state is synced via `room:data` and gameplay resumes seamlessly.
4. If the timer expires without reconnection, the disconnected player forfeits the match:
   - Opponent receives a win by forfeit.
   - Elo changes and XP awards are settled and recorded in the database.
   - The match participant record is marked `FORFEIT`.

---

## 4. Elo Rating Algorithm

NEON ARENA uses the official Elo rating system adapted for casual and competitive matchmaking:

$$\text{Expected Score } E_A = \frac{1}{1 + 10^{(R_B - R_A)/400}}$$

$$\text{New Rating } R_A' = R_A + K \cdot (S_A - E_A)$$

Where:
- $K = 32$ for standard competitive matches.
- $S_A = 1$ for win, $0.5$ for draw, $0$ for loss.
- Ratings are bounded with a minimum floor of 100.
